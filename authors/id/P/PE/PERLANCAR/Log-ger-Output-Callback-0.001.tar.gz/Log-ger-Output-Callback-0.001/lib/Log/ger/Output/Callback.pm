package Log::ger::Output::Callback;

our $DATE = '2017-06-25'; # DATE
our $VERSION = '0.001'; # VERSION

use strict;
use warnings;

sub get_hooks {
    my %conf = @_;

    return {
        create_log_routine => [
            __PACKAGE__, 50,
            sub {
                my %args = @_;

                if ($conf{log_routine_callback}) {
                    [sub {goto &{$conf{log_routine_callback}}}];
                } else {
                    [undef];
                }
            }],
        create_is_routine => [
            __PACKAGE__, 50,
            sub {
                my %args = @_;

                if ($conf{is_routine_callback}) {
                    [sub {
                         push @_, {}, $args{level};
                         goto &{$conf{is_routine_callback}};
                     }];
                } else {
                    [undef];
                }
            }],
    };
}

1;
# ABSTRACT: Send logs to a subroutine

__END__

=pod

=encoding UTF-8

=head1 NAME

Log::ger::Output::Callback - Send logs to a subroutine

=head1 VERSION

This document describes version 0.001 of Log::ger::Output::Callback (from Perl distribution Log-ger-Output-Callback), released on 2017-06-25.

=head1 SYNOPSIS

 use Log::ger::Output Callback => (
     log_routine_callback => sub { ... }, # optional
     is_routine_callback  => sub { ... }, # optional
 );

=head1 DESCRIPTION

=for Pod::Coverage ^(.+)$

=head1 CONFIGURATION

=head2 log_routine_callback => code

=head2 is_routine_callback => code

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Log-ger-Output-Callback>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Log-ger-Output-Callback>.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Log-ger-Output-Callback>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=head1 SEE ALSO

L<Log::ger>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2017 by perlancar@cpan.org.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
