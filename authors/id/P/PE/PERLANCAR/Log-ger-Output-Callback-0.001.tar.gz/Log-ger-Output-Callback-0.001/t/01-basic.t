#!perl

use strict;
use warnings;
use Test::More 0.98;

use Log::ger::Util;

package My::P1;
use Log::ger;

package main;

subtest "basics" => sub {
    my $ary = [];
    require Log::ger::Output;
    Log::ger::Output->set(
        'Callback',
        log_routine_callback => sub { push @$ary, $_[1] },
        is_routine_callback => sub { if ($_[1] <= 3) { push @$ary, 1 }; $_[1] <= 3  },
    );
    my $h = {}; Log::ger::init_target(hash => $h);

    $h->{warn}("warn");
    $h->{debug}("debug");
    if ($h->{is_warn}()) {
        $h->{error}("error1");
    }
    if ($h->{is_debug}()) {
        $h->{error}("error2");
    }
    is_deeply($ary, ["warn", 1, "error1"]) or diag explain $ary;
};

done_testing;
