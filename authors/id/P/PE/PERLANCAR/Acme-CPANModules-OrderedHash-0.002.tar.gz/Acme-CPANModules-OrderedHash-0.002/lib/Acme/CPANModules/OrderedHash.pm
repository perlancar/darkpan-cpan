package Acme::CPANModules::OrderedHash;

use strict;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2025-04-15'; # DATE
our $DIST = 'Acme-CPANModules-OrderedHash'; # DIST
our $VERSION = '0.002'; # VERSION

our $LIST = {
    summary => "List of modules that provide ordered hash data type",
    description => <<'MARKDOWN',

When you ask a Perl's hash for the list of keys, the answer comes back
unordered. In fact, Perl explicitly randomizes the order of keys it returns
everytime. The random ordering is a (security) feature, not a bug. However,
sometimes you want to know the order of insertion. These modules provide you
with an ordered hash; most of them implement it by recording the order of
insertion of keys in an additional array.

Other related modules:

<pm:Tie::SortHash> - will automatically sort keys when you call `keys()`,
`values()`, `each()`. But this module does not maintain insertion order.

MARKDOWN
    entries => [

        {
            module => 'Tie::IxHash',
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                tie my %hash, "Tie::IxHash";
                for (1..$numkeys) { $hash{"key$_"} = $_ }

                if ($op eq 'delete') {
                    for (1..$numkeys) { delete $hash{"key$_"} }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = keys %hash }
                }
            },
        },

        {
            module => 'Hash::Ordered',
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                my $hash = Hash::Ordered->new;
                for (1..$numkeys) { $hash->set("key$_" => $_) }

                if ($op eq 'delete') {
                    for (1..$numkeys) { $hash->delete("key$_") }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = $hash->keys }
                }
            },
        },

        {
            module => 'Tie::Hash::Indexed',
            description => <<'MARKDOWN',

Provides two interfaces: tied hash and OO.

MARKDOWN
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                tie my %hash, "Tie::Hash::Indexed";
                for (1..$numkeys) { $hash{"key$_"} = $_ }

                if ($op eq 'delete') {
                    for (1..$numkeys) { delete $hash{"key$_"} }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = keys %hash }
                }
            },
        },

        {
            module => 'Tie::LLHash',
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                tie my %hash, "Tie::LLHash";
                for (1..$numkeys) { (tied %hash)->insert("key$_" => $_) }

                if ($op eq 'delete') {
                    for (1..$numkeys) { delete $hash{"key$_"} }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = keys %hash }
                }
            },
        },

        {
            module => 'Tie::StoredOrderHash',
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                tie my %hash, "Tie::StoredOrderHash";
                for (1..$numkeys) { $hash{"key$_"} = $_ }

                if ($op eq 'delete') {
                    for (1..$numkeys) { delete $hash{"key$_"} }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = keys %hash }
                }
            },
        },

        {
            module => 'Array::OrdHash',
            description => <<'MARKDOWN',

Provide something closest to PHP's associative array, where you can refer
elements by key or by numeric index, and insertion order is remembered.

MARKDOWN
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                my $hash = Array::OrdHash->new;
                for (1..$numkeys) { $hash->{"key$_"} = $_ }

                if ($op eq 'delete') {
                    for (1..$numkeys) { delete $hash->{"key$_"} }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = keys %$hash }
                }
            },
        },

        {
            module => 'List::Unique::DeterministicOrder',
            description => <<'MARKDOWN',

Provide a list, not hash.

MARKDOWN
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                my $hash = List::Unique::DeterministicOrder->new(data=>[]);
                for (1..$numkeys) { $hash->push("key$_") }

                if ($op eq 'delete') {
                    for (1..$numkeys) { $hash->delete("key$_") }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys = $hash->keys }
                }
            },
        },

        {
            module => 'Tree::RB::XS',
            description => <<'MARKDOWN',

Multi-purpose tree data structure which can record insertion order and act as an
ordered hash. Use `track_recent => 1, keys_in_recent_order => 1` options. Can
be used as a tied hash, or as an object (faster).

MARKDOWN
            bench_code => sub {
                my ($op, $numkeys, $numrep) = @_;

                my $tree= Tree::RB::XS->new(compare_fn => 'str', track_recent => 1, keys_in_recent_order => 1);
                for (1..$numkeys) { $tree->insert("key$_") }

                if ($op eq 'delete') {
                    for (1..$numkeys) { $tree->delete("key$_") }
                } elsif ($op eq 'keys') {
                    for (1..$numrep) { my @keys= $tree->keys }
                }
            },
        },
    ],

    bench_datasets => [
        {name=>'insert 1000 pairs', argv => ['insert', 1000]},
        {name=>'insert 1000 pairs + delete', argv => ['delete', 1000]},
        {name=>'insert 1000 pairs + return keys 100 times', argv => ['keys', 1000, 100]},
        # TODO: iterating
    ],
};

1;
# ABSTRACT: List of modules that provide ordered hash data type

__END__

=pod

=encoding UTF-8

=head1 NAME

Acme::CPANModules::OrderedHash - List of modules that provide ordered hash data type

=head1 VERSION

This document describes version 0.002 of Acme::CPANModules::OrderedHash (from Perl distribution Acme-CPANModules-OrderedHash), released on 2025-04-15.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher --cpanmodules-module OrderedHash

To run module startup overhead benchmark:

 % bencher --module-startup --cpanmodules-module OrderedHash

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

When you ask a Perl's hash for the list of keys, the answer comes back
unordered. In fact, Perl explicitly randomizes the order of keys it returns
everytime. The random ordering is a (security) feature, not a bug. However,
sometimes you want to know the order of insertion. These modules provide you
with an ordered hash; most of them implement it by recording the order of
insertion of keys in an additional array.

Other related modules:

L<Tie::SortHash> - will automatically sort keys when you call C<keys()>,
C<values()>, C<each()>. But this module does not maintain insertion order.

=head1 ACME::CPANMODULES ENTRIES

=over

=item L<Tie::IxHash>

=item L<Hash::Ordered>

=item L<Tie::Hash::Indexed>

Provides two interfaces: tied hash and OO.


=item L<Tie::LLHash>

=item L<Tie::StoredOrderHash>

=item L<Array::OrdHash>

Provide something closest to PHP's associative array, where you can refer
elements by key or by numeric index, and insertion order is remembered.


=item L<List::Unique::DeterministicOrder>

Provide a list, not hash.


=item L<Tree::RB::XS>

Multi-purpose tree data structure which can record insertion order and act as an
ordered hash. Use C<< track_recent =E<gt> 1, keys_in_recent_order =E<gt> 1 >> options. Can
be used as a tied hash, or as an object (faster).


=back

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Tie::IxHash> 1.23

L<Hash::Ordered> 0.014

L<Tie::Hash::Indexed> 0.08

L<Tie::LLHash> 1.004

L<Tie::StoredOrderHash> 0.22

L<Array::OrdHash> 1.03

L<List::Unique::DeterministicOrder> 0.004

L<Tree::RB::XS> 0.19

=head1 BENCHMARK PARTICIPANTS

=over

=item * Tie::IxHash (perl_code)

L<Tie::IxHash>



=item * Hash::Ordered (perl_code)

L<Hash::Ordered>



=item * Tie::Hash::Indexed (perl_code)

L<Tie::Hash::Indexed>



=item * Tie::LLHash (perl_code)

L<Tie::LLHash>



=item * Tie::StoredOrderHash (perl_code)

L<Tie::StoredOrderHash>



=item * Array::OrdHash (perl_code)

L<Array::OrdHash>



=item * List::Unique::DeterministicOrder (perl_code)

L<List::Unique::DeterministicOrder>



=item * Tree::RB::XS (perl_code)

L<Tree::RB::XS>



=back

=head1 BENCHMARK DATASETS

=over

=item * insert 1000 pairs

=item * insert 1000 pairs + delete

=item * insert 1000 pairs + return keys 100 times

=back

=head1 BENCHMARK SAMPLE RESULTS

=head2 Sample benchmark #1

Run on: perl: I<< v5.40.1 >>, CPU: I<< AMD Ryzen 5 7535HS with Radeon Graphics (6 cores) >>, OS: I<< GNU/Linux Ubuntu version 24.10 >>, OS kernel: I<< Linux version 6.11.0-8-generic >>.

Benchmark command (default options):

 % bencher --cpanmodules-module OrderedHash

Result formatted as table (split, part 1 of 3):

 #table1#
 {dataset=>"insert 1000 pairs"}
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | participant                      | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors | samples |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | Tie::StoredOrderHash             |       500 |      2    |                 0.00% |               563.14% | 2.7e-06 |      20 |
 | Tie::LLHash                      |       630 |      1.6  |                25.79% |               427.20% |   3e-06 |      23 |
 | Array::OrdHash                   |       890 |      1.1  |                75.77% |               277.28% | 1.3e-06 |      20 |
 | Tie::IxHash                      |      1100 |      0.95 |               108.21% |               218.50% | 1.4e-06 |      20 |
 | Hash::Ordered                    |      1400 |      0.7  |               181.91% |               135.23% | 1.6e-06 |      20 |
 | Tie::Hash::Indexed               |      1600 |      0.64 |               207.80% |               115.45% | 1.2e-06 |      20 |
 | List::Unique::DeterministicOrder |      1800 |      0.55 |               262.91% |                82.73% | 1.1e-06 |      21 |
 | Tree::RB::XS                     |      3300 |      0.3  |               563.14% |                 0.00% | 5.6e-07 |      20 |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+

The above result formatted in L<Benchmark.pm|Benchmark> style:

          Rate   T:S   T:L   A:O   T:I   H:O  TH:I  LU:D  TR:X 
  T:S    500/s    --  -19%  -44%  -52%  -65%  -68%  -72%  -85% 
  T:L    630/s   25%    --  -31%  -40%  -56%  -60%  -65%  -81% 
  A:O    890/s   81%   45%    --  -13%  -36%  -41%  -50%  -72% 
  T:I   1100/s  110%   68%   15%    --  -26%  -32%  -42%  -68% 
  H:O   1400/s  185%  128%   57%   35%    --   -8%  -21%  -57% 
  TH:I  1600/s  212%  150%   71%   48%    9%    --  -14%  -53% 
  LU:D  1800/s  263%  190%  100%   72%   27%   16%    --  -45% 
  TR:X  3300/s  566%  433%  266%  216%  133%  113%   83%    -- 
 
 Legends:
   A:O: participant=Array::OrdHash
   H:O: participant=Hash::Ordered
   LU:D: participant=List::Unique::DeterministicOrder
   T:I: participant=Tie::IxHash
   T:L: participant=Tie::LLHash
   T:S: participant=Tie::StoredOrderHash
   TH:I: participant=Tie::Hash::Indexed
   TR:X: participant=Tree::RB::XS

The above result presented as chart:

=begin html

<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtAAAAH4CAMAAABUnipoAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAADkUExURf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJUA1ZQA1JQA1JQA1JUA1QAAAAAAAJQA1JQA1JUA1ZQA1JQA1JQA1ZUA1ZUA1ZQA1JUA1pgA2pQA1JQA1JUA1TEAR0AAXD4AWRYAHyQANEIAXzkAUikAO0EAXg0AExsAJhsAJhgAIxoAJhQAHAYACAgACxkAJA8AFgsAEBUAHwAAAAAAAJQA1EUAY////9yMjMYAAABIdFJOUwARRDMiu1XMd2aI3Znuqo6j1c7H0j/s/Pbx+fR1jsej3+zk8Ijx9UQieqefEXUgM++E6/n41eD78uT68vj59/n17/D48/H2W7eRe+EAAAABYktHRACIBR1IAAAACXBIWXMAAABIAAAASABGyWs+AAAAB3RJTUUH6QQPBxcKsGUtcQAAE1xJREFUeNrt3A+fo8Z9gPEBgRADqHHsXu26Te04idu06d+k6f8kTdtM+v5fUGcGWFHE4oWBhfnd8/3cZ2d9Z3GM9AgNSHtKAQAAAAAAAAAAAAAAAAAAANhfknbfpMnRuwKsdXmpNzXdNyYd/HmWH72HwAL5S71TQWfXgqARkUtxy5QqtU5t0MlNu5Zd0KnW9vdVmRM0YlJWdaryStfmmpqqro32Qd8a+zul+x9SgkZM3JIjvyhlj9HmptTNJDbozB2kb437c4JGVNo19OVa6HYNbVM2aVmlaXo1tnOCRlxc0NrkdT4MWje5Q9CIjg362mTtkiNRKrGHZZNeK9VflyZoRCW/2hNDW29lg66Vqit3kE4ae0KoC/fnBI2o3KsyKaq8qps/KIqiai5+1VE2ReG+JWhEJknteiNNE9WP/W+nQZsFAAAAAAAAAAAAAHyXsjEmT9wHH61cqSQ37mctXkYgJklzU1lVK3Wv0zS9KJXfk8z+3ssIxMR/Fl3bI3Puf+5NZe6HK27FywhExX/2/G6P0KbU+tIFbr/0IxCbvKjsGtpU+m5K/xF1F3I/dr73iff9T4GdfOYT++wPg4NOb41WmU78Tyf7VYYNuR87H/7oc+eLDyH+OOjWG24kcB7b7cgXnzObF1/6xMyfbHCMvnbhJiZ9Zcnx4dMtXgo22MYmG9FbfOR+ix1Jt7iOJGs2oUG780EfsDsnzExmf7l/M0X1Y4egd9kRgn4SGnTqrmbUVTfaaRV2r3L9GFsEvcuOEPST4CVHbfKquvh/UcKPl6aoiuQxtgh6lx0h6Cfha+is+yHOfkxGo0fQu+wIQT/Z5KTwu20SdLnFnmyxEfdj2afYkWyLFmXNJqagge9E0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEjUP96Q8m/dna7RE0DvXV7yd9vXZ7BI1DETREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIcrpgi4bY/JEqSQ3RqvnsUXQmHa2oJPmprKqViq/J5n9/mlsETSmnS3o1NgvOleZuSh1K57GDkFj2tmCTlL75V63Ydsv47FD0Jh2tqCtvKgSVVbKBzweOx9+qJ306LsPZ7Nd0KVPbIOg01uj29WFDXg8dj58kjrZ0Xcfzma7oC8+sU0u210NSw6sc7Ylhz0f9OFmxh597TpjPHYIGtPOFnTqrmbUNtxC29W0fh5bBI1pZwta1SavKhv1pSmqInkeWwSNaacLWmVpe+0ieWX0CBrTzhf0mxA0phE0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BDldEFfKmPyi1LaWLlSSW6MVo+xRdCYdrqgm1ol90qpe52mqQ07vydZc3uMLYLGtLMFnZrEHqVNpvLS/3dmbNS34mXsEDSmnS3ozC0rrrZqU2p9cYEr/6UfOwSNaWcL2skKW7Wp9N2UqrSrDxdyP3YIGtPOF3Si3clfpu3S49a0qwwbcj92PvxQO+nRdx/OZrugS59Y+FWOwl3jaCUmfW3J8UnqZEfffTib7YK++MSCg65qP6TunDAzmf2l3HqjHzssOTDtbEuOq/HPC3swtsfpOlfKradz/RhbBI1pZwvav59ijPsmryob9aUpqiJ5jC2CxrSzBf2Qpe0pXzIaPYLGtPMGPYugMY2gIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIcFfTlErTbBI1pxwRdNiZPi4CmCRrTDgk6M7drnuhm/W4TNKYdErSuVZorVaSrd5ugMe2YoDVBYx+HBJ02Fxt02SSrd5ugMe2Yk8KbqZqqKdfvNkFj2kGX7bJSX6ePz5fKmPyiVJIbo9Xz2CJoTDvmKke7eC6ziT9rapXcK6Xye5I1t+exRdCYdkDQSXqrU+taTZwUpsYeuC8my4w9St8KNR47BI1pBwR9yYsqd+4Ti47MLSuuJkmNcnWr8dghaEw7ZMlxmT8dzAqtSrvqcAGPxw5BY9qRH06aXEOrRLuTP7+6sAGPx86Hb/wxPuA6CWTaLmjtE3tb0FftNFNvrFwKd41DseTAKse8sWJ0keuqnvqz7nczYw/fdp0xHjsEjWlHfZbjWqukmjgpvBp3AcQeuu06WuX6eWwRNKYd9VmOS277nFhyaOPZpUdTVEXyPLYIGtMOCbqsLsouIarZDyclaTo5egSNacdc5chzpZuqeMv/Oo2gMe24y3bXcv2H7QgarzjmKkfw9WOCxrRDgr4FLDZaBI1pxyw56rq7OLcWQWPaQW+s9Bfn1iJoTOMfmoEoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEjbP40Y+/nvKTb5dshKBxFj+abvH3BI0oETREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWicxrfT/nzJNggap/GT6Y5+sGQbBI3T+JqggxD0yRB0GII+GYIOQ9AnQ9BhCPpkCDoMQZ8MQYch6JMh6DAEfTIE/bosd1+1sex3SW6MVo+xRdAnQ9Cvya6FD/pep2l6USq/J1lze4wtgj4Zgn5NmbdB56X/z8zYqG/Fy9gh6JMh6NelPmhTam0bTo3yX/qxQ9AnQ9Cv64Ku9N2UqqyUD7kfOwR9MgT9Oh90phO7xGjaVYYNuR87H77JnTL4L8M2BAatfWKbHaGdxKQsOeIgMOjWVkGn7uCbmcz+Um690Y8dgj4Zgn5dG7S7qlHb7wqtVK4fY4ugT4agX5d2b6zkVWWjvjRFVSSPsUXQJ0PQ3ylLUz8mo9Ej6JMh6DAEfTIEHYagT4agwxD0yRB0GII+GYIOQ9AnQ9BhCPpkCDoMQZ8MQYch6JMh6DAEvZ2/+Omkv1y0EYIOQ9DbeSWBHy/aCEGHIejtbJIAQYch6O0Q9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIejoEPQcgo4OQc8h6OgQ9ByCjg5BzyHo6BD0HIKODkHPIej39Fc/m/bXSzZC0HMI+j19+0oCP1uyEYKeQ9DviaD3mc0AQb8ngt5nNgME/Z4Iep/ZDBD0eyLofWYzQNDviaD3mc0AQb8ngt5nNgME/Z4Iep/ZDBD0eyLofWYzsEHQWe6+JrkxemJsEbRH0PvMZiA46Oxa+KDze5I1t+exRdAeQe8zm4HgoMvcB52Zi1K34mnsELRH0PvMZmCDJUfqgk5N+2U8dgjaI+h9ZjOwVdBlpXzA47FD0B5B7zObga2C9qsLG/B47Hz4JnfK4L8sbgS9z2w87RNjyfGeCHqf2QxsFXRmMr/uGI8dgvYIep/ZDGwVtCq0Url+HlsE7RH0PrMZ2CzoS1NURfI8tgjaI+h9ZjOw3VvfSZpOjh5BewS9z2wG+CzHeyLofWYzQNDviaD3mc0AQb8ngt5nNgME/Z4Iep/ZDBD0eyLofWYzQNDviaD3mc0AQb8ngt5nNgME/Z4Iep/ZDBD0eyLofWYzQNBv9e20v1m0DYLeZTYDBP1Wfzt9z3+1ZBsEvc9sBgj6rV65579asg2C3mc2AwT9VgQ9RtBRI+gxgo4aQY8RdNQIeoygo0bQYwQdNYIeI+ioEfQYQUeNoMcIOmoEPUbQUSPoMYKOGkGPEXTUCHqMoKNG0GMEHTWCHiPoqBH0GEFHjaDHCDpqBD1G0FEj6DGCjhpBjxF01Ah6jKCjRtBjBB01gh4j6KgR9BhBR42gxwg6agQ9RtBRI+gxgo4aQY8RdNQIeoygo0bQYwQdNYIeI+ioEfQYQUeNoMcIOmoEPUbQUSPoMYKOGkGPEfRR/u7raYs2QtBjBH2Un75yzy/aCEGPEfRRCPoJQYchaI+g95nNAEG/FUGPEfRRCPoJQYchaI+g95nNAEG/FUGPEfRRCPoJQYchaI+g95nNAEG/FUGPEfRRCPoJQYfZJOjL2hsS9BOCDrNJ0PnaGxL0E4L+LtpYNrkkN0arx9giaI+g95nNwGZB3+s0Te2iIL8nWXN7jC2C9gh6n9kMbBZ0XvohMzbqW/EydgjaI+h9ZjOwWdCm1No2nBrlv/Rjh6A9gt5nNgPbBV3puylVWSkfcj92PnzxifP9T0N8s/aGf/+/0xZt5B+mt/HzJdv4xSs78o9LNvLz6W38ctFsfjm9kX9aso1/fmU2v9hgNv+yaDbeZz6xrYLOdGKXGE27yrAh92Pn08+9Lz6E+GbtDf/13x7+ffD9oo38x2Abv3p8/+sl2/jNKzvyn0s28uvH7X412MhvF83mt9Oz+a8l2/jvV2bzmw1m8z+LZuN96RP78ncbHaGdxKSvLDmAuKTunDAzmf2l3HqjH4Eope6qRm1P2wptz970YwTeIjl6B8a0yavKRn1piqpIHiPwBvp8x74sTf2YjMYtNl03zTkmnJVlFr6Vuj7JjmyxJ9v4qF7M06ZOr8316N2wz9G7KSpzD37dSU3gc32rHdlgT3Rlig0emqIM30YsEv8OeuCDl+ThrxdJkdujYloVwVvKV79HtPGOhO7JtSrKVJuQGi93d8U39IkVk20u/tXhV1x05Z9Vl4DlT1b7xz4LSmCLHVHdgiVsT+6Nv3UZkmOi7Xoy+ZiCdvd5qgsTtoxOwlfh/TpPN2v3QTf3TCV1ZjcR8ooTvCP2yWAufkfC9qS/8T3saFFWzccUtP9kaqHtK9uqSfuDon3swhpy+oPZ2sPJtWrcDZOqDHx6he6IY9cabkcC96RqTyr9R9FC2Ie43uIk99xciv4ockl9i2vOhNuDon/sqtAz+pe/f1VHl7wZPCVLs+bxy7bYkW53zHWDPbl2JRe35ZtISve89A+wOznNTR34rDi57vW5eqzxquX3WndQbL/3d36iVx2o3f1+647x6w6M2v7F+eM0rrgv34RbJ7g9CduR7oO+dZWE70l/UlksPta4pbMpVPcA3+xmbNIrnhbRGKaotL/7Fr9P8/8Piv7OL6ti2QEpufm/tV0ntMd4vXrFODgFS9ccGN0M7J6s3xH3oteeUmZ5/wNFIXtiy3YzuixeclyrIu1u7GfinxeCFx2jFHVT102++NA6OihmRufN0pP6uyleHqzU2NcMuxhf/9LYLeTdy8SaR69fJ6zcke5Fz66aE21q3WTt69WqJUffont6lIvX4ff2h5nu/e102NXD8xulqMpar1wuvtzz9rHTZvl6Qxf5o5tL5X5wMmCp152CLb9YNlonrNqR/kXv1twad1t7UrHiql23J92lQ/eytfwoYXfBPYuSl0VkLT1op7+zV656e/3VDbu5ZMWx6NqoevCod+enq3WnYMufV6N1wvIdGbzoVe2B3r1NuHw2/YtMf1S+LT5KuHWPW7in9lnpDlruUCN4tfHQ3XWB70K83PPrSrzYAnX7c+xhT6xOse5YNFwnrNuTwYte/4b3qg9Q9Pfnrd+ThS22657UlHc3JbexwAc4Hv1dF9jRuutSL+yDbw8l9Vb3e7rycvhgnbB+T/ob3kPeNO/vz2pVi/26527qRHVvMn40H8oMTLG38qDYyWt7BnNtiuTg+32wTli/Jy8vessvkD0+DdPdn/5EbvW6p38q1Bt8xCoeYSn21h4UW+2ZZNDnJjYRtE7o9S96a940f/k0TLcna3ZksO4Jf+c2QmEpbuPWPvbH70jQOqHXn5SueOl7vEnurrUk9drHpjs2J9XRh4iPVGqOb9lbs054FvCi93JMTYomN/nq5WC3nfIsd+zH5jQfBAv4cN1DyIve49Mw11v4xXjJbwye2mk+BrZmnbCpoE/DDGx0sg8EWvVpmAnbnOwDgVZ9GmbCGU72gf4aJiDE4ct4AIBA/wfa30+Q6dcTnQAAACF0RVh0cHM6SGlSZXNCb3VuZGluZ0JveAA1MDR4NzIwKzUwKzUw1uIiwwAAABV0RVh0cHM6TGV2ZWwAUFMtQWRvYmUtMi4wjYZxeAAAAABJRU5ErkJggg==" />

=end html


Result formatted as table (split, part 2 of 3):

 #table2#
 {dataset=>"insert 1000 pairs + delete"}
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | participant                      | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors | samples |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | Tie::IxHash                      |        30 |    34     |                 0.00% |              6121.61% | 4.4e-05 |      20 |
 | Tie::StoredOrderHash             |       290 |     3.5   |               866.25% |               543.89% | 6.7e-06 |      21 |
 | Tie::LLHash                      |       360 |     2.7   |              1124.54% |               408.08% | 8.2e-06 |      20 |
 | Array::OrdHash                   |       447 |     2.24  |              1399.96% |               314.78% |   1e-06 |      20 |
 | Hash::Ordered                    |       601 |     1.66  |              1917.47% |               208.39% | 1.2e-06 |      20 |
 | List::Unique::DeterministicOrder |      1020 |     0.976 |              3338.34% |                80.95% | 7.2e-07 |      20 |
 | Tie::Hash::Indexed               |      1100 |     0.95  |              3431.93% |                76.15% | 1.1e-06 |      20 |
 | Tree::RB::XS                     |      1900 |     0.54  |              6121.61% |                 0.00% | 1.3e-06 |      29 |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+

The above result formatted in L<Benchmark.pm|Benchmark> style:

          Rate    T:I   T:S   T:L   A:O   H:O  LU:D  TH:I  TR:X 
  T:I     30/s     --  -89%  -92%  -93%  -95%  -97%  -97%  -98% 
  T:S    290/s   871%    --  -22%  -36%  -52%  -72%  -72%  -84% 
  T:L    360/s  1159%   29%    --  -17%  -38%  -63%  -64%  -80% 
  A:O    447/s  1417%   56%   20%    --  -25%  -56%  -57%  -75% 
  H:O    601/s  1948%  110%   62%   34%    --  -41%  -42%  -67% 
  LU:D  1020/s  3383%  258%  176%  129%   70%    --   -2%  -44% 
  TH:I  1100/s  3478%  268%  184%  135%   74%    2%    --  -43% 
  TR:X  1900/s  6196%  548%  400%  314%  207%   80%   75%    -- 
 
 Legends:
   A:O: participant=Array::OrdHash
   H:O: participant=Hash::Ordered
   LU:D: participant=List::Unique::DeterministicOrder
   T:I: participant=Tie::IxHash
   T:L: participant=Tie::LLHash
   T:S: participant=Tie::StoredOrderHash
   TH:I: participant=Tie::Hash::Indexed
   TR:X: participant=Tree::RB::XS

The above result presented as chart:

=begin html

<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtAAAAH4CAMAAABUnipoAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAADeUExURf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJUA1ZQA1JQA1ZUA1QAAAAAAAJQA1JQA1JQA1JQA1JQA1JQA1JQA1JUA1pUA1pQA1JQA1ZQA1JAAzxYAHzEAR0AAXD4AWSQANEIAXzkAUikAO0EAXgYACBsAJhsAJg0AExgAIxoAJhQAHAgACxkAJA8AFgsAEBUAHwAAAAAAAJQA1EUAY////0BHjzkAAABGdFJOUwARRDPdu+6Zqsx3ImaIVY6j1c7H0j/s/Pbx+fR1p9+37OTwIkQRiPrH1j91zXoz5dXr+fjg+/Lk+u/4+fL3+fXw+PPx9lvHclExAAAAAWJLR0QAiAUdSAAAAAlwSFlzAAAASAAAAEgARslrPgAAAAd0SU1FB+kEDwcXCrBlLXEAABOhSURBVHja7d1rg+NIeUBh3WVZLpNlN8Mum5kMsFxyIUAIJCQEwk3k//8iVGW5WyPZsktVale9Ps8HupeZ0Vj2sVRy2/MmCQAAAAAAAAAAAAAAAAAAAIDtpdnwTZY++qYAa+Uv9Wbd8E2Xvf5q0XVl/ujbCNytfKn3UtBVnaS74tG3EbhX3uzbJDkolfVBp3ulW9ZBZ0q1uvH++J137aNvJXCnQ1FnSVmoujtmXVHXnTJB76v+/zkkbf9fybFjTY1o6CWHXiX3x+hunyT7vt4ua/VBel+Z39A26tG3EbjbaQ2dHxt1WkP3KXfZociy7Nj1naeqo2dERAeturIux0GrqtTyfonNaxyISh/0sWpPS45+rZz2h+UuO+oXNvTr0kX96NsHWCmP/YVhX2/RB93XWxf6IJ1Whz7xpr8ezLRH30bgbrvikDZFWdTVt5qmKarcrDoOVdP036rOePRtBO6WZvr15ixNzl/P/zfHZQAAAAAAAAAAAADY1vnDm2nZmffrTr8CUTl/eLPcpW21n38FYnL+8GarP1Sxb5LpVyAq5w9vmg9Z9P8z/QpER394U781XQc8/Tr4u8+Mb38ObOQLk9gXf++a8+nDm2Z10Qc8/Tp4950vta/eufiu05/2uBHH/fB3Q776kr158bVJrPsHx56HD2/eWHK8+9zDmaD0sA0vG1E+3nLv44ZkPl5HkrU3zkEPH95s9T/q068zpl8HBL3JDSHoGdegXz68qf8RlFLNv54Q9CY3hKBnXIN++fBmXjVFk86/nhD0JjeEoGeclxwvzh/mnH41CHqTG0LQM/6CXuQl6IOPW+JjI5mPfwTUxw1pfbQoa29iChq4iaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNB7q/YeL/nHt9ggaD/Xhrxd9XLs9gsZDETREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigBBt2af+zajEhOr41GJmhcFlzQ7bExQRd1kjb1tdHIBI3Lggv6UJ6C7rIkUeW10cgEjcuCCzpJMhO0Phrv6k3nFEKgYIPOqqZq0mujkd99Zqa/+ZjmAVH8BZ2bxHwFnTa77Nioq6ORv6c0H1NhIIq/oA8mMV9BD0fkliUHrIS65FD6iJx2+ZajkSFQqEHn+lUNVWw6GhkChRp0su+aoso3HY0MgQIMetBuPhoZAoUb9CKCxmUEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUOUAIM+jUZOa0Yjw15wQZ9HI6smTXc7RiPDTnBBD6ORUz00qFWMRoad4IIehgZlXZJnScJoZNgJNehjUVZVlV8djUzQuCjUoJW+AqyLq6ORv19qh0fffQiNv6CVSczjkiPRC2eWHLAS6hE6H4JmNDKshBp0UuzNkoPRyLASbNB6FDKjkWErwKAHKaORYS/coBcRNC4jaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1Rgg46v/orBI3LAgz6NBo50WOIEkYjw05wQZ9HI+uZV/obRiPDRnBBD6OR+0NysSsTRiPDTnBBn4cGJTullxzMKYSVYIM+NGYNzWhkWAk16LbITdCMRoaVUEcjq6ZfcRSqZckBK6EeoTN1CprRyLASatCaeR2a0ciwEXzQjEaGjQCDnmA0MiyEH/RFBI3LCBqiEDREIWiIQtAQhaAhCkFDFIKGKAQNUQgaohA0RCFoiELQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDREIWiIQtAQhaAhCkFDFIKGKAEGfRqNnBddV+aMRoad4II+j0au6iTdFYxGhp3ggh5GI2ednqvStYxGhpXggj4P3tTLi2OXMqcQVkINWmsbxWhk2Ak36FTpi0BGI8NKqKORk7zRr3EkLDlgJdgjdFGb/2A0MqyEGvSxyzRGI8NOqEGrzmA0MuwEGPQEo5FhIfygLyJoXEbQEIWgIQpBQxSChigEDVEIGqIQNEQhaIhC0BCFoCEKQUMUgoYoBA1RCBqiEDRC8YNvLvuhzUYIGqH40eUW//qNzUYIGqEgaIhC0BCFoCEKQUMUgoYoBA1RCBqiRB10njvtO0ELFHHQh6ors8ahaYIWKN6g225/LFNVrd93ghYo3qBVbf6J0Sa74/deRtACRRy0ImjMxBt0VuV90IcqveP3XkbQAsUbdLLviqqoHEb+ELRAEQedtAd1vHZ8Po1Gno5EZjSyePEG3Z4Wz4f20q8No5GnI5EZjRy0H1/u6Cc224g16DTb13og0LG4dFE4jEaejkRmNHLYPj5x0HnZFGam4e7yoiM7zfpOPplPyJzCsD1z0H3Si5eDJujpSGRGI4ftuYMeXFxDD0FPRyIzGjlsAoO2GY18VFp1+QcrLDkiJDDok/t+sNKpplTD8OP5r54uCj8dicxo5LA9d9CqTo51khYLF4WzkciMRg7akwetkryvtlxYcsxGIjMaOWjPHfShyJN+CVEsvjlpOhKZ0cghe+6gk7JMVFU09/zWywg6ME8etHY8rH+zHUGH5rmDzpxfPybowDx30HuHxcYJQQfmuYNOavPupPUfWCHo0Dx30Fl3sv7+I+jAPHfQ7gg6MATthqADQ9BuCDowBO2GoAND0G4IOjAE7YagA0PQbgg6MATthqADQ9BuCDowBO2GoAND0G4IOjAE7YagA0PQbgg6MATthqADQ9BuCDowBO2GoAND0G4IOjAE7YagA0PQbgg6MATthqADQ9BuCDowBO2GoAND0G4IOjAE7YagA0PQbgg6MATthqADQ9C35EXXlSmjkSNB0LcUdZI2NaORI0HQNzeU6UlxjEaOBEHfoo/Gu5o5hZEg6FuyqqmalNHIkSDoG9Jmlx0bdXU08vfMLFqHfzIdXgkM+mAS8xX0cERury05PjMjANrV24dfAoPOTWK+glb6iJx2OaOR4yAw6BNfQef6VQ1VMBo5EgR9y75riipnNHIkCPqmltHIESFoNwQdGIJ2Q9CBIWg3BB0YgnZD0IEhaDcEHRiCdkPQgSFoNwQdGIJ2Q9CBIWg3BB0YgnZD0IEhaDcEHRiCdkPQgSFoNwQdGIJ2Q9CBIWg3BB0YgnZD0IEhaDcEHRiCdkPQgSFoNwQdGIJ2Q9CBIWg3BB0YgnZD0IEhaDcEHRiCdkPQgSFoNwQdGIJ2Q9CBIWg3BB0YgnZD0IEhaDcEHRiCdkPQgSFoNwQdGIJ2Q9CBIWg3BB0Ygr4lrZn1HRGCvkU1abrbMes7EgR9Q6qnYLWKWd+RIOgbsi7JsyRh1nckCPqGY1FWVZVfnfXNaGRv3n+46J+sNiIwaL+jkZW+AqyLq7O+GY3sjZcEBAbtdzSyabdfOLPk2BxBL/E3GjkxQTPre3MEvcTby3bF3iw5mPW9OYJe4i1oPdubWd9vgaCX+PvRd8qs77dB0Et4L0d0CHoJQUeHoJcQdHQIeglBR4eglxB0dAh6CUFHh6CXEHR0CHoJQUeHoJcQdHQIeglBR4eglxB0dAh6CUFHh6CXEHR0CHoJQUeHoJcQdHQIeglBR4eglxB0dAh6CUFHh6CXEHR0CHoJQUeHoJcQdHQIeglBR4eglxB0dAh6CUFHh6CXEHR0CHoJQUeHoJcQ9Fv6wU8u+2ebjRD0EoJ+S99cSeBfbDZC0EsI+i0R9DZ7M0LQb4mgt9mbEYJ+SwS9zd6MeA06v/orBG0Q9DZ7M+IzaFUmjEZeRNDb7M2Ix6CzTgfNaOQFBL3N3ox4HElR7MqE0ciLCHqbvRnxF/RO6SUHcwqXEPQ2ezPiLehDY9bQ10YjM0lWI+ht9sbwO0m2LXIT9LXRyMz61gh6m70xPM/6bvoVR6FalhxLCHqbvRnxNutbnYJmNPISgt5mb0a8vw7NaOQFBL3N3ox4D5rRyAsIepu9GfH/Xg5GI19H0NvszQhvTnpLBL3N3owQ9Fsi6G32ZoSg7/WvHy56b7MNgt5mb0YI+l5X7vkPNtsg6G32ZoSg70XQUwQdNYKeIuioEfQUQUeNoKcIOmoEPUXQUSPoKYKOGkFPEXTUCHqKoKNG0FMEHTWCniLoqBH0FEFHjaCnCDpqBD1F0I/y08vv/LRqkaBnCPpR3l+55602QtBTBP0oBD1D0G4I2iDobfZmhKDvRdBTBP0oBD1D0G4I2iDobfZmhKDvRdBTBP0oBD1D0G4I2iDobfZmhKDvRdBTBP0oBD1D0G4I2iDobfZmhKDvRdBTBP0oBD1D0LfkRdeVeZijkQl6hqBvqeok3RVhjkYm6BmCviHr9FyVrg1yNDJBzxD0Da1eXhy7NMg5hQQ9Q9B3aBsV5mhkgp4RGLTf0cj9VaDSF4FBjkYm6BmBQfsdjZzkjX6NI2HJsYSgt9mbEW9BF7X5EuRoZIKeIegbjp1ZwYQ5GpmgZwj6BtUZYY5GJugZgr5bgKORCXqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN0QtEHQ2+zNCEHfi6CnCPpRCHqGoN2sDvrfPrz62ej7n9pshKBnCNrN6qCvJfDeZiMEPUPQtjyNRiboe2/IR6u9IWhbnkYjE/S9N+Sj1d4QtCVfo5EJ+t4b8tFqbwjakq85hQR97w35aLU3BG1pOhr5q8+0b39u6+f/f9kvbDbyiysbsbol/355G7/0sTf/YbORX17exq+s9uZXlzfya5tt/OeVvfm5h735L6u9Mb4wiW0V9GQ08udfGl+9s/Wb/371P6Pvf2uzkd9e2YjVLfnf0TZ+9/r9733szf/ZbOT3r3/ud6ON/MFqb/5weW/+aLONP13Zm9942Js/W+2N8bVJ7Ou/bBP0ZMkBxG0yGhmI3KejkYFlqfsmtvXpaGRgkQr/2PfJaGRnde26hbauqiDutfZwaMPYiB/uD03yhCfzrHN8emRVnR2r46P3I0l3XVN0O7dzl5+NqKJrPNwhzg+N1hzctxGXsnT646n5MbxjAaX7I5c2ZX9kzYrm4Rs5Fs0hU52HkNwemnyn+ofFx5MiDm19ustbt7veyyuItfurNqowT6rcafXjYyO7ytyfB5eShkWP20OTqn4pmD5L0P3e7tokrfu7TlUux1d9p2eq6ZxCSt0X4ee1oqoevJHz3blb/yTN9ft19GPj9tDol3erJwn6WFR6R9Pi4FyT6rquUf05dtU9p88T/UPn+sj1p9bhYOZ0SPKykeJ0LWfeRbaSXmvox8b9id4/OnUoF7nbyctq3N+hW7PLQ4r91jIT45rL6eE80T90hesV/ctfv6rF1uNGjkPJzX7FNk7ybrimXPXQpAf9vDSPjb6wLLt6/VMrDqq/WihHFz7NznoTrymeFfaP33CeMN+aClK17kDdP3j74Ri/6uB6Psd72cj5Wq5Zc3QtT3doXQx3hP1Do5fOXTOcfZN9f1v6pNc/t6IxvuDIrI8DoxT754d5IK1/2PPpeUJXcCgayxuS7s3f2j94aXU6xqtVS9fhHO9lI33Z+q7N7Zcc/UnvdFnalucPJVk/NMeiyYZbYPbEPLnkLzqSl4sXc1C03OHJkkVVdV2V1sfWT88TbafKyvqiftc152yyrj9l9IvxVafX8zneaSMvxwhd5cF6+WtOenrVnKquVlV7emwsH5rd6cNMu/NfrtxelI3JcMGx5qWh6ZLlUKuVF1Hnv71/6FS3Yr2hmvIlvrzoL09L2xQn53injQyv+vV3bW3/5BxOevtqX+m/X19UrHhs9vqJ0J8nzmuM+nmCPl9wrHx5YZSiy40YzhP91tI158VjldSvj/pweWp3Aybn+HUbGc5256Py3vrJ+XrSK04nC/NjQsuN6Ot0vejO+melPt7ow8RTrDYGjdOz9zVFl62cG1j5rMj7J6UyLa6+npye4132Yr9yoTA+6Z1/4G39qtHpOj3rDju9S/oWOT420cmcXvx1TPFs3WuGL/pHvz8erTs9nzie4z/di8Ilo+EP7tb94P18nb7r6jQZflLJmzJtOKZ45naeKOv+MuhYNen6B8/hHP/6LpRhL8w12OpbcjrptWteZHtdspyfT7XjW6yekFuKZ27nidOlpNObL1af47Xzu1CGjbi9WXM46a35wfvoOt39p67Pyi1FP/anB9/phqw8x5/+4vNTSb9Mktau770wJ71Vl8fJy7E5LZ7tLdCSZJ37k2rVOf7sfDxMm6rsStdFmJfr9IOH+wSP4uPdZE7v0Ht5F8px7/6WCT/X6c/0Up04Pt5LtvYcb7i9C8UvT9fpeGrr3oWyDT/X6Xhq696Fso0QrtMRu1XvQgFC5bQEBwBgM38DGqXG1MD/JRUAAAAhdEVYdHBzOkhpUmVzQm91bmRpbmdCb3gANTA0eDcyMCs1MCs1MNbiIsMAAAAVdEVYdHBzOkxldmVsAFBTLUFkb2JlLTIuMI2GcXgAAAAASUVORK5CYII=" />

=end html


Result formatted as table (split, part 3 of 3):

 #table3#
 {dataset=>"insert 1000 pairs + return keys 100 times"}
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | participant                      | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors | samples |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+
 | Tie::StoredOrderHash             |      17   |     60    |                 0.00% |              1556.89% |   8e-05 |      20 |
 | Tie::LLHash                      |      20   |     51    |                16.85% |              1317.94% | 5.9e-05 |      20 |
 | Array::OrdHash                   |      24.8 |     40.4  |                47.90% |              1020.29% | 1.8e-05 |      20 |
 | Tie::IxHash                      |      26.6 |     37.6  |                58.99% |               942.13% | 2.4e-05 |      22 |
 | Tie::Hash::Indexed               |      43.1 |     23.2  |               157.40% |               543.70% |   1e-05 |      22 |
 | Hash::Ordered                    |     132   |      7.58 |               688.61% |               110.10% | 4.8e-06 |      20 |
 | List::Unique::DeterministicOrder |     179   |      5.58 |               970.30% |                54.81% | 2.3e-06 |      20 |
 | Tree::RB::XS                     |     277   |      3.61 |              1556.89% |                 0.00% | 2.1e-06 |      22 |
 +----------------------------------+-----------+-----------+-----------------------+-----------------------+---------+---------+

The above result formatted in L<Benchmark.pm|Benchmark> style:

          Rate    T:S    T:L    A:O   T:I  TH:I   H:O  LU:D  TR:X 
  T:S     17/s     --   -15%   -32%  -37%  -61%  -87%  -90%  -93% 
  T:L     20/s    17%     --   -20%  -26%  -54%  -85%  -89%  -92% 
  A:O   24.8/s    48%    26%     --   -6%  -42%  -81%  -86%  -91% 
  T:I   26.6/s    59%    35%     7%    --  -38%  -79%  -85%  -90% 
  TH:I  43.1/s   158%   119%    74%   62%    --  -67%  -75%  -84% 
  H:O    132/s   691%   572%   432%  396%  206%    --  -26%  -52% 
  LU:D   179/s   975%   813%   624%  573%  315%   35%    --  -35% 
  TR:X   277/s  1562%  1312%  1019%  941%  542%  109%   54%    -- 
 
 Legends:
   A:O: participant=Array::OrdHash
   H:O: participant=Hash::Ordered
   LU:D: participant=List::Unique::DeterministicOrder
   T:I: participant=Tie::IxHash
   T:L: participant=Tie::LLHash
   T:S: participant=Tie::StoredOrderHash
   TH:I: participant=Tie::Hash::Indexed
   TR:X: participant=Tree::RB::XS

The above result presented as chart:

=begin html

<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtAAAAH4CAMAAABUnipoAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAADbUExURf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJQA1JQA1JQA1AAAAJQA1JUA1pUA1pQA1JQA1AAAAJUA1ZUA1ZUA1ZUA1pUA1ZQA1JQA1ZUA1QAAAD4AWRYAH0IAX0EAXjEARyQANCkAOzkAUkAAXBQAHBsAJhoAJhsAJgYACBkAJBUAHw0AEwgACwsAEA8AFhgAIwAAAAAAAJQA1EUAY////0hTpl0AAABFdFJOUwARRDNm7rt3It2ZzIhVqnDO1cfSP/r27PH59HVE79++InU/iMfa7KdpW/Uzt47h+NX7+uvg5PL59fj5+e/49vLw8fP3W9A4ri0AAAABYktHRACIBR1IAAAACXBIWXMAAABIAAAASABGyWs+AAAAB3RJTUUH6QQPBxcKsGUtcQAAEt9JREFUeNrt3Gtj48Z1gOHB4EJchmxju3Yau07cxk7btE3Sa5wmvU/7//9RARCkuGtK1ByMyIOj9/kgKCvvWRB8CQ4oMs4BAAAAAAAAAAAAAAAAAAAAeFuFX77xxaN3BZAqz/X6uHwT/fmnVR1jQ9/YjuZc75Wgi3rn2q5/9D4Cr1UOu9ZVIfgp6GI3beegfQjt0nhoHr2TwGtVXe+bLvRxP9bb9X0Mc9C7evyj6risPnCGxnaMS46mHE/DYQx659wuFmPQ7XSS3tXzz4eONTS2Y15Dl/shLGvoMeXoq857v49j6M6PJ+tH7yPwamPQITZ980HQoW4m5fxf7OOqfwC4p8bv63ZZcoxri2I8LUe/79z8uvR8PegJGtvR7Kux3qKbgh6v/vpuOkkXdTU2Pox/VB7/CNiIQ/dHQ9d0fV35YRi6upxXHVU9DNO3fWy6rnz0PgKvVvjWeV+4cePmb05/fPztSuu9eDQAAAAAAAAAAAAA4JbTBziLJk6fs1g2wDadP8DZHIp2/H7ZANt0+gBnO73FcTcsm0fvFSB0+gDnHLaPy+bRewXIzR/gnN6fPpa8bM4/++MfzT4B3tqnc2qffrY66PkDnPMyw8dlc/5Z/JPPJ1+s8uOVf//oT3MMyTPl8x+zKz+09m7+yZxa/DLDOXofn1tyZBnvs7xskuf/qCXLlJDl7frWdiXP3by2uNMHONvYTv9/Kcsm2/iMt5Sgle+KjqDPH+Acxt1pwmmTa3zGW0rQyndFR9DnD3CW9dANxWmTbXy+W0rQyndFSdDnD3AuH+gsPvg8J0Ffo6giRbuiJei3H99mOehVlhuUZcr82W525SN57uYtBA28GkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHjkb56hnggQeOR/ux/rxMPJGg80tcEDUsIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYp+oIuuxib0rkQR40rmhhDxvGwTV/Qde+KQ+fcoffel645FG29yzcetqkL2sdiPEvH1jXV9D/bOJ6sd0O28TBOXdDttL7Yj1XHKoRy7Nu545c842GcuqAn7TBWHbtwiFU1Lj4+CPqnYfLowwatMgZdzamtD7oI01VgG8alx66eVxuXQU8ra+8ffdigVcagyzm19a9yDNNrHEdF/JIlB1LoW3J0/bzx0zVhGz8bLw/dvO7INB62qQt6H49rCj+9vNE3blpON09rZoLGi9QFPf8+Jcbpm6brSlfWQzcU2cbDOHVBP2mP137FB5eABI0XKQ76EeOxdQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqYQNEzRF3TZxdiUzhVNjOG8yTYetukLuu5dceicaw5FW+9Om2zjYZu6oH0sxrN0bNs4nqV3w7LJNh7GqQu6ndYX+1j46Ka6l0228TBOXdCTdgiuGlcdY8nLJut4GKYw6CJMV4HzMsPHZfM0/qdh8ujDBq0yBl3Nqa1/lWOYXuNwzy05ej959GGDVhmDLufUVgfd9fOmje34GOmWzfmnLDnwInVLjn1cTsHjOto14bTJNR7GqQs6xNl4wq+HbihOm1zjYZy6oJ8Ux6Vy8cGKmaDxIsVBP2I8to6gYQpBwxSChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQUOJn31z350lTCBpK/MUzKf48aQpBQwmChikEDVMIGqYQNEwhaJhC0DCFoGEKQcMUgoYpBA1TCBqmEDRMIWiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDVMIGqZsPOiyfNPx2JxNB13VsfGDoGmCNmvLQbdxt2+KUL/ReGzRloMOvfONc4N/m/HYok0HHQgaH9ly0L4ux6Crunib8diiLQftdrGru7p6q/HYoE0H7doq7J87P7fN9DXEUeOKJsaQPB7bs+Wg2+PiuWqv/Ww/zEEfeu996ZpD0da7tPHYou0GXfjdFKvfd9cuCqvmGHQzL0jaWI4LlCFlPLZpu0GXzdA1k8P1RYefg45VCKXzcfqDmDIe27TdoMekX7wcXILuwiFWVecI+n3YctCLq2voJeg2jKfvXT2vNi6D/nY+t7/lgcVjqAs6zKm9Luh9mNTXf7Hiz70W8UuWHO+FuqCPXveLlRiGJnT9Mz+dgvbTqqSNn8XxLD6vOxLGY4u2HHTo3b53RffCRaGfXt7oGzcE55qQNh5btOmggyvHapuXlhwhNl1XurIeuqFIG48t2nLQ1VjquJboXnxzUuvnHxf+8r8iaLO2HLRrGhfqbnjNfyoZjw3adNCTfZX+ZjuCtmvLQXvB++wSxmOLthz0TrDYSBiPLdpy0K6f352U/oEVgrZry0H7ePRG47FFWw5ajqDNImiYQtAwhaBhCkHDFIKGKQQNUwgaphA0TCFomELQMIWgYQpBwxSChikEDS2+/u6qr5OGEDS0+O56RN8lDSFoaEHQWsdDhKC1jocIQWsdDxGC1joeIgStdTxECFrreIgQtNbxECForeMhQtBax0OEoLWOhwhBax0PEYLWOh4iBK11PEQIWut4iBC01vEQIWit4yFC0FrHQ4SgtY6HCEFrHQ8RgtY6HiIErXU8RAha63iIELTW8RAhaK3jIULQWsdDhKC1jocIQWsdDxGC1joeIgStdTxECFrreIgQtNbxECForeMhQtBax0OEoLWOhwhBax0PEYLWOh4iBK11PEQIWut4iBD0i9pm+lo0MYbzJuN4ZEfQL2j3wxx0cyjaenfaZBuPN0DQL6iaOeg2ls7thmWTbzzeAEG/yE9B+zh/WTY5xyM7gn7RHHTVTd/FZZNzPLIj6BfNQc/LDB+XzdP4b5vJ6n8DOdkMOsypseR4h2wGfZQr6Da207pj2eQcj+wI+kVz0G4IzjXhtMk4HtkR9IuOQZf10A3FaZNxPLIj6NcovL/YZB+PfAha63iIELTW8RAhaK3jIULQWsdDhKC1jocIQWsdDxGC1joeIgStdTxECFrreIgQtNbxECForeMhQtBax0OEoLWOhwhBax0PEYLWOh4iBK11PEQIWut4iBC01vEQIWit4yFC0FrHQ4SgtY6HCEFrHQ8RgtY6HiIErXU8RAha63iIELTW8RAhaK3jIULQWsdDhKC1jocIQWsdDxGC1joeIgStdTxECFrreIgQtNbxECForeMhQtBax0OEoLWOhwhBax0PEYLWOh4iBK11PEQIWut4iBC01vEQIWit4yFC0FrHQ4SgtY6HCEFrHQ8RgtY6HiIErXU8RAha63iIELTW8RAhaK3jIULQWsdDhKC1jocIQWsdDxGC1joeIgStdTxECFrreIgQtNbxECForeMhQtBax0OEoLWOhwhBv0KIo8YVTYzhDcYjI4J+hUPvvS9dcyjaepd/PDIi6FdoqulrG0vndkP+8ciIoF8zqAqhdD6O385fMo9HRgT9mkFdOMSq6hxBq0fQt7WhGNca9bzauAz622aS599AJjaDDnNqWU+hRfySJccG2Az6KFdxfrombONnsXVuXnfkHY+cCPo2P7280TduCM41Ty9EE7RGBP0KITZdV7qyHrqhyD8eGRH0a7TeT5viuMk+HvkQtNbxECForeMhQtBax0OEoLWOhwhBax3/7vzimfv/m6QpBK11/LtD0LcQ9KYQ9C0EvSkEfQtBbwpB30LQm0LQtxD0phD0LQS9KQR9C0FvCkHfQtCbQtC3EPSmEPQtBL0pBH0LQW8KQd9C0JtC0LcQ9KYQ9C0EvSkEfQtBbwpB30LQm0LQtxD0phD0LQS9KQR9C0FvCkHfQtCbQtC3EPSmEPQtBH0vf/nNVX+VNISgbyHoe/nrHBUR9C0EfS9ZKiLoWwj6tl98fd0vk6YQ9DUE/QDPHfSvkqYQdMqxTRpyiaBvI+hrCHqzCPoagt4sgr6GoDeLoK8h6M0i6GsI+gF++d11f5M0haCvIegH+OqZw/V10hSCvoagH4Cg325XCPoBCPrtdoWg0/ztz6/7WcoQgn67XSHoNFkqIui32xWCTkPQ1xD0LQR9p10h6KRjmzTkEkHfaVcIOunYJg25RNB32hWCTjq2SUMuEfSddoWgk45t0pBLBH2nXSHopGObNOQSQd9pVwg66dgmDblE0HfaFYJOOrZJQy4R9J12haCTjm3SkEsEfaddIeikY5s05BJB32lXCDrp2CYNuUTQd9oVgk46tklDLhH0nXaFoJOObdKQSwR9p10h6KRjmzTkEkHfaVcIOunYJg25RNB32hWCTjq2SUMuEfSddoWgk45t0pBLBH2nXSHopGObNORS7qCLJsaQYzxBX0PQt+QOujkUbb3LMJ6gryHoWzIH3cbSud2QYTxBX0PQt2QO2sfTl7XjCfoagr4lc9BV5z4M+u9+NPkk3a/+77pfpwz59TNDfnX/XfnkN9eH/H3SkH94Zlf+Mceu/CZpyD89syv/nDTlX56ZkjTk6NM5tcxBz6uNi6B//Pnsi3S//f7sd//69P33v08Z8vuLv3g55LfSXflevCtf/OFiyO+evv+3pCH//syu/EeOXflD0pD/fGZX/itpyn8/czcnDTn6yZzaT/4na9AfLzmATWtju6w7AAuG4FwT1s/B+1I8egeeU9ZDN6jdOygV9J4DC++zzWr7utZyS9uqanPM6XslQ3LdoCzex5O6r3u/r/eP3o1JcYhDFw8Znnp8zPCAXz8kzw0qQheHHHfQUGUYol0x/wp9bUNFkyGgYmjGs5nvhvWjXNMoGJLnBu27ofIhroqxPITxLs7xKFcv06t/fYbXXEI3P67KNQugtj/e8e2qAJZVwroheW6QO9TzTlSraizCuKws3kXQ053mwxBXLqOLDMvw0xIv1OK9CPWhdUXfTkPkzzrl9F6ZacqaIVlukHu6IYeVp4yqq99F0C7EGIcwPqcJb+10Thzv/JX3/eR0PhSfSfZdPf3NoqtWPsKmtcY0ZeXDdPUNmnXHa9P5HWmrjPd0r+cKNb+lRFf6OUXZJfByThzv/G71awLnPZDd/2VTXz4qqyi/88q4XzWkzXKDlin7peRhJ5hRVNODan7Omi5ym9ivfVho9VTiopMcr+WcOH87H/ciCE/U4zHfLSd54QktjP90c3H9NRwEQ5rj8ei7YsWQ05Jl3Q06L3yWa9Mh/YwzLZ3jsDxnud04Z0xacj/rd1GiC/OBE/yi5sNz4nTcq25IPaUVu/kfHo95UR9P8kG+Wry8jPPJZ9fxOet4Hdc2pw8EpQ85HYr1N+i08CnnG1WmLzn23eCXvz3vxvzAMLno+LDEUPd93QjOrB+eE9sYmjr9ZYFDHE73lI/jk8a4Gl/xrLgs5ecnisS7bn7OmlbNRYh9qNvjFNH9f1qyrLtB50fn9Cir0pfzh+OHmg6nvxhyvJSp00fPzlUfxFctp6M+3vkhStYbYWjOd3jZjVeozZpV3nIZJ3jBbXnO2tW7etqD6ZJAMOWjJYvwBi1Tlpf9xhvVS04Vu+lBOZ7jT2uM3m7Qk4sSV81ZzonjuEJ0NtvXrn8KZ7lClVsu41KnPD1ndcez6/xrwvR9+XjJIrtBp+eZ01l5l36qmC75pwsAPz6kplPXdMIxudp48lTiqjGnoy4NsRwLDPP9v/ahdTSIzkNPz1mnX3gLX/X5eMkicjqmO+nC53jJ72N1mPZnmrb2bt6AtSWerHl9bDIGNJ5GZM/wV3jxC+LLv39Y9ZvqlUuWxemYdrIUT5f8h9gXbvkt4zt4c+baEk9k58Szph+vXvb1UDz8mB+fs9p1L2ytWbI8vSVmOabzdZx8+XR6LPQ53vC1AStLPJGfE2fHa8l1b3jIY3nOWvWb6nVLlvNbYpYpoiEXl/wZfn+7JStLzGR37EfDrhyfs2QXt2drlixPv2ufXicp+rXLp6J7/Gni3fFRQ8tHOZ6zVi1ZzqfUYqib2MgfWsugStHBfTcUvQksy3PWqiXL01ti9rsML8jb/MWgctbeArZqybLyLTFPcl3yA6sI3xLzQ5ku+YFVhG+J+SEdl/x492RviQGUWvmqIQAAV/0/Miq1OZCFiNUAAAAhdEVYdHBzOkhpUmVzQm91bmRpbmdCb3gANTA0eDcyMCs1MCs1MNbiIsMAAAAVdEVYdHBzOkxldmVsAFBTLUFkb2JlLTIuMI2GcXgAAAAASUVORK5CYII=" />

=end html


=head2 Sample benchmark #2

Benchmark command (benchmarking module startup overhead):

 % bencher --cpanmodules-module OrderedHash --module-startup

Result formatted as table:

 #table4#
 +----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | participant                      | time (ms) | mod_overhead_time | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | List::Unique::DeterministicOrder |        13 |                 6 |                 0.00% |                89.60% | 7.8e-05   |      20 |
 | Tie::Hash::Indexed               |        10 |                 3 |                 3.73% |                82.78% |   0.00013 |      20 |
 | Hash::Ordered                    |        13 |                 6 |                 4.82% |                80.89% | 6.1e-05   |      20 |
 | Tie::IxHash                      |        12 |                 5 |                 8.03% |                75.51% |   0.00011 |      20 |
 | Array::OrdHash                   |        12 |                 5 |                 8.03% |                75.51% | 7.3e-05   |      20 |
 | Tree::RB::XS                     |        12 |                 5 |                10.47% |                71.62% | 1.9e-05   |      20 |
 | Tie::LLHash                      |        12 |                 5 |                11.87% |                69.49% | 2.5e-05   |      20 |
 | Tie::StoredOrderHash             |        10 |                 3 |                34.19% |                41.29% |   0.00015 |      20 |
 | perl -e1 (baseline)              |         7 |                 0 |                89.60% |                 0.00% | 8.1e-05   |      20 |
 +----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                          Rate  LU:D  H:O  T:I  A:O  TR:X  T:L  TH:I   T:S  perl -e1 (baseline) 
  LU:D                  76.9/s    --   0%  -7%  -7%   -7%  -7%  -23%  -23%                 -46% 
  H:O                   76.9/s    0%   --  -7%  -7%   -7%  -7%  -23%  -23%                 -46% 
  T:I                   83.3/s    8%   8%   --   0%    0%   0%  -16%  -16%                 -41% 
  A:O                   83.3/s    8%   8%   0%   --    0%   0%  -16%  -16%                 -41% 
  TR:X                  83.3/s    8%   8%   0%   0%    --   0%  -16%  -16%                 -41% 
  T:L                   83.3/s    8%   8%   0%   0%    0%   --  -16%  -16%                 -41% 
  TH:I                 100.0/s   30%  30%  19%  19%   19%  19%    --    0%                 -30% 
  T:S                  100.0/s   30%  30%  19%  19%   19%  19%    0%    --                 -30% 
  perl -e1 (baseline)  142.9/s   85%  85%  71%  71%   71%  71%   42%   42%                   -- 
 
 Legends:
   A:O: mod_overhead_time=5 participant=Array::OrdHash
   H:O: mod_overhead_time=6 participant=Hash::Ordered
   LU:D: mod_overhead_time=6 participant=List::Unique::DeterministicOrder
   T:I: mod_overhead_time=5 participant=Tie::IxHash
   T:L: mod_overhead_time=5 participant=Tie::LLHash
   T:S: mod_overhead_time=3 participant=Tie::StoredOrderHash
   TH:I: mod_overhead_time=3 participant=Tie::Hash::Indexed
   TR:X: mod_overhead_time=5 participant=Tree::RB::XS
   perl -e1 (baseline): mod_overhead_time=0 participant=perl -e1 (baseline)

The above result presented as chart:

=begin html

<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtAAAAH4CAMAAABUnipoAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAACiUExURf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYAHwYACBEAGAAAAAAAAAAAAAAAAAAAAAAAACYANwsAECMAMgAAAAAAAJUA1ZQA1JQA1JUA1ZQA1ZQA1JUA1ZQA1JQA1GkAlzAARWYAk1gAfgAAAAAAAAAAAAAAACcAOZQA1G0Am////yj+u9oAAAAxdFJOUwARRDOIu8x3ImbdqplV7nXVzsfVytLSP/728ez+8fz59OxE34S3M6ciEfSZ7c++IHoVb1iFAAAAAWJLR0QAiAUdSAAAAAlwSFlzAAAASAAAAEgARslrPgAAAAd0SU1FB+kEDwcXDS4BuNIAABT6SURBVHja7Z1/g6vGdYZhGBAghNvbNq2dtI7txEnzo+0k+f6frYAEu+td+wI6uuic8zx/7K60OwuvzsMwwAhlGQAAAAAAAAAAAAAAAAAAAAAAAAAAANxHHq7fQ/7m6eLo9QJYT/Fib0jX7ym8/oNYHr2KAOspX+z9UOiQEBr0UFSnOsuaGMPobn4av49Chxjr8fd5e0Zo0EPTdiEr29ilyyB023UpjkKf+uGZZvj9OTLkAE2MQ45yOO6LcRD6lGWnlKdQj530qR98rxhDgyquY+jiUsXbGDqFFJo2hHBJRd0WCA2qGIWOqezK10LHvhwpYjWMONrraBpAA4PQl76+DTny4SgwFSlc2mw6LT0cGiI0qKK8DAeG49mMUeguy7p26KPzfjggjNX0Bww5QBPntsmrtmy7vglVVbV9MZ7laPqq6q+XCBEaNJGHYUARQp6N36cfbk+Hu/4tAAAAAAAAAAAAAAAAAADIUE/TEJo+pTK/938BHEx9qUah8/6U1W139NoA3ElTTkJP09aZMgYGCFMPPU4bO9NDg37CrV8uq3YZQ3/1TxP//Gkt//IBqxr+6wcN/231YuH5+NWkzq/+/XChw6mP83Of/uPrkW9+vZbf/O0dv1nV8D/fN/zbf61e7JVvN/79wjdf72254aWRWlktMX87qZO+OlzoLLukRehfb/wn3/39Hd+tavj9+4Z//2HjwncP/UPc2zLuntm//zhFVcyjhY7LkeEEQn8GhP4MRwsdUjG99fMGQn8GhP4MRwuddals2+WesAj9GRD6Mxwo9I369Rs+EfozIPRnOF7oN+gSutkbs95dr7D7tjK7V1ZXTIS+Q2h4PhAaoU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCmwKhEdoUCI3QpkBohDYFQiO0KRAaoU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCmwKhEdoUCI3QpkBohDYFQiO0KQ4Uui7Hr0WbUlnMzyE03MdhQteXahK677L83M7PIjTcx2FCN+UkdEj50Eun+vYsQsN9HDjkCKPQdRy+XEarJxAa7uNooUfqKs7PITTcx/FC5zEtPmefvi1HmtX/5AChf/fde363quXvP2j546qWP7xvuG5lf/xgkb9f/eqqIk7qHC50Ub2c49DRQ//hg5Z/WNXyhw9afv+sMZVyuNBt9/o5hH6amEo5WuhLCiPzcwj9NDGVcrTQMU3MzyH008RUCpe+EdoUCI3QpkBohDYFQiO0KRAaoU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCmwKhEdoUCI3QpkBohDYFQiO0KRAaoU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCmwKhEdoUCI3QpkBohDbFgULX5dvvIwj9NDGVcpjQ9aUqX3+/gtBPE1MphwndlFeR5+9XEPppYirlwCFHKN9+H0Hop4mpFIRGaFM8m9Bfx5Gw+p8g9KNiqqOZ1Hk2ob8JI/Xqf4LQj4qpjmJS59mEZsjxLDGVgtAIbQqERmhTcOkboU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCmwKhEdoUCI3QpkBohDYFQiO0KRAaoU2B0AhtCoRGaFMgNEKbAqER2hQIjdCmQGiENgVCI7QpEBqhTYHQCG0KhEZoUyA0QpsCoRHaFAiN0KZAaIQ2BUIjtCkQGqFNgdAIbQqERmhTIDRCm+LhQhfFlr9G6KeJqZQHC930qQzVeqcR+mliKuWxQtfpdCnz2K9ugNBPE1MpjxU6dlkos6wKaxsg9NPEVMqDhY4I/QqEfjyPFTr0xSB00+drGyD008RUyoMPCk+p7du+Wf33CP00MZXy6NN2dRMvq/tnhH6imEp5dA9dTnz4u3p6Oi9TistzCP00MZXyWKGbPk588Kv6Uk1Cl+e87k/zswj9NDGV8vCzHD9HU05C16kY+vFqfhahnyamUh7cQ3e/8MvxhF4W0vxlAqGfJqZSHjyGLrufG3LchG7a7I3Q34SRevUCEPpRMf/4/Xv+uKrljx+0/O9VLe+imNR58HnoVP38QeEk9DTaeCX019MGsPpCDEKbinkXzaTOwy99/zwMORBanscKfYq/8MtwPSisb+OOCYR2HVOAxwqdl800sPnwl5PQWTU4Xy7eI7TrmAI8egx95eNfTkIXfdVWy7VEhHYdU4Dj34KVv+7AEdp1TAGOF/oNCO06pgAIraLSTmIK8EChQwq/OIb+CIR2HVOAB7+n8Do8blZf+UNo1zEFeKTQeTh140m7S8tbsCYQ+vE8UuiirNrpyveZt2BNIPTjeeyQo1j/5qsrCO06pgCc5VBRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBUBoFZV2ElMAhFZRaScxBThc6KJNKS6PENp1TAGOFjrvY1ZXi9EI7TqmAEcL3bTDl0s7P0Ro1zEFOFroWA1fQpofIrTrmAIcLXSRiiw7p/z2EKFdxxTgaKGzri+r6kXob8uRZnVzJ5V2EvMu4qTO4UJnRbww5CCmFEcLnYfhy6maHyK065gCHC50ClnenuaHCO06pgBHC501qey75RFCu44pwOFCZ3UoXh4gtOuYAhwv9BsQ2nVMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMARBaRaWdxBQAoVVU2klMAQ4XumhTKvP5EUK7jinA4UK3XZZX3fwIoV3HFOBwoVPIsljOjxDadUwBDhe6P2XZmR6amEIcLnToq756GUN/HUfC6uZOKu0k5l00kzpHC51X53Cp4vzw0zdhpF7d3kmlncS8i2JS52ihm3b4EtJsMEMO1zEFOFroWA1f8lTcHiK065gCHC10Mboc2/khQruOKcDRQmenVLX93EEjtO+YAhwudFaHV+c0ENp1TAGOF/oNCO06pgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIKgNAqKu0kpgAIraLSTmIuxLDt7184WuiQJub1R2jXMRf0Cp2HgVOf3x4itOuYC3qFnqgu808I7Trmgm6hT+flR4R2HXNBtdB5Xy8/f/rtV9v40z/e8adVDf/8vuE//rKq5V8/aPnXVS3/8kHLPxPzA/6n2/b3LzyB0LF7+flTAriLw4XO++LoVQCQo2mPXgMAQc7x6DVQQ37/v4CH01/u/x8+iGz68IvUTVPvbNp1+9rdscis/PJC74xZd32/c2WL3SfsrJDHNlV7evn8nKo2nfftx0Pa88Lftcisana/SHvZFzP0Xbjs3PPmsdy9xZvg0lZNiGl7rfNqfOVCW+1bbllub7N7kcU5DhvBvm2ovKvL2xWzP2V3DPgb16e9zv2kcrO92LGdXvJi676x7qYl1ju2ob2LHLqtYRee7xI66/adRbp1k3tihrRriQuujY63eU3nzWWbR6Sx39JqUOtcZ3lXL0t++CKvNG2/T+h812i2SINUO2OOG0GIVdo7jM5OrePzOe31sKVOW7fquevZ1PFd2n7867xt9oiya5ELMaVu0/Dyti/ZoWR2HWvsjDmuaariMBDcHPN0PcI44PD3cObSXm4mV6eNDZcXbf3LXpT9qyI1aevRy/ZF5s3oZD6JPByglalbvd2+7EvaPacqinTZHnPchMYlFiF/k3ctsb+EssqHo8oda6ybZZc4H7ZUK1+8peE8CXtDdxmHQ7Py5YiuOq9tOC2nq7cuchw6p+raUw691xB0UHrlhvtqX3Ld5vO4sqMur/uRbt7vr45524TaZdTdru1kZsYzI824JbX+Tt7Nu8TB0PEFLFYPOV72pdeOK24bfb86Sgrr+q78NJkxLHPjIi9tFW7xplbTlruuu3y7LxkjN221punQx14PXesyxU0x503ouq5Tr1FtGeuMbVMoyjIULq8hvYg1FqBZP9Jb9qUhDf1JHbceUt+GpGOHt67Q51TNi9i0yPN09utlakDccAbt7b6kTrHs15ytmPrYcdScx9TFcVrv6phvN6HYd11frvG57qa/aoZdUZ5V1dhFDX1T2LTzU85tlxjnXeLQ760r10/3pUU7HLyUWw8mb0dJ689nxapcDN6yyNM0Tzxf9tvdxlPCr9YwplXjjVsfe+pP/biO49h7dcyfDMeabu0c/XFJed2Gehg0TuP1Ig3b0I7T32qZu8ilUz6tK1f2031pNh+8bON2lLS65aXPuhctVi5yPLwaB69h2AJGTYaeMm49Bn3Zl+Rrmr70se11JzZdJtzyAs32rx6u1+MpjWHlujZehzZd25zGnzNPPfRs8mneJa7c9Wfv9qU7qbZ1H8VQqDhtRKuXeT28Cqk5j6s85t1zgWPjvuSlj50veO84S5FvWeL1UL7rsnpa0+48jqvKaWNydSJ6PpHUbi30rn3pe8LGE7uDHkNHu2GZ8+HVOU0DzGZrT/mTF2pD09sannfOB5j7mtVLHHvleog3HSbXvbNzG8u0hFsXOR0lbSr03n3pfZTdcHx36YeDnlXLfNn1zxtAt3s60+ah6LWPrdeeHPwpm8/Nn8deubp2Tln0NNAYmacl3HaJ268n7d6X3sX1kGz1DI5Xh1f7LvK9yru5/a2P3XNxfmLrJjT2ytO58nFNXY0zRpbjwPFERd7tqPbefeldnK527Di8ytsvfj722seuOor8iC2b0HSdexxsNEOjcucEc93MPVZe9WXaM2929770HkLavuXdkjY7mt7J9mHKTq7Xuf93PC057DELn7Ogl2kJl9O+KYa796X3sGMu0rwz+vJl3j5M2cntOvfYPTu1Ocu2Tkt4z+596T1smyR3ZfvUJ0U0ZZcv17k9Tq17YcO0BOV8sV3/l6erYtks17n9ds8jq6clqOeL7fq/fLL2dnxwu87tm5XTEuB5ufTh0lVVsVznds0hg2AQ4jRdMS1T213O5+U6N4BOYnW5zNe3G7vHCOCEehw1V+0wio5Zwx2zQCnFPE7O2zwvx6miRZ9afAaV1E0+jDKadnpfQ92fxtturH2zD8DTMQwvYhv6Szj3ddbF8TJConcGtQxCZ+30TvDyPM7hDy0nqkAxoRxnLIx9cpHycfDs+D5fYIHxWuB1cmgKWe7sTSlghuV67rnJprdZrb7BB8Dz8XKrmOlDdGIf4+6bNwIczumlOx7f2p335+hiThnYJK/Scmm7GC8KXhhugGK6WLy8T6dweO9FMMerW1IWm+9DCvBsXD9q5fazw9uJghFO8+d8ncy+5wYcMd+FP1t/E3qA52W5C3/m8ZMlwBzLXfgzh/f2Anssd+EHUEr9+u6o3J0A1PNy9He5ZNydALQzz6Mryipk3J0AlNOE8/VW5YH5R6CevE6Nu0+TALtMH2G18eNLAZ6W6SOscqYfgX6u0zam3rlh4gZoZ562MZ2k833fcrDAPG1j+ggr3/ctBwss0zZ8foQVGGK6V90ybYPeGVSTX+9V939M2wATVLd71TFtA0ww36uuZtoGmGC5Vx2ABeqxiy64Vx1YISbuVQeGyPuSe9WBIU4tZ+vAEtx0A0xh97PIwSec4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAvwP8DOxJn00x9LjkAAAAhdEVYdHBzOkhpUmVzQm91bmRpbmdCb3gANTA0eDcyMCs1MCs1MNbiIsMAAAAVdEVYdHBzOkxldmVsAFBTLUFkb2JlLTIuMI2GcXgAAAAASUVORK5CYII=" />

=end html


To display as an interactive HTML table on a browser, you can add option C<--format html+datatables>.

=head1 FAQ

=head2 What is an Acme::CPANModules::* module?

An Acme::CPANModules::* module, like this module, contains just a list of module
names that share a common characteristics. It is a way to categorize modules and
document CPAN. See L<Acme::CPANModules> for more details.

=head2 What are ways to use this Acme::CPANModules module?

Aside from reading this Acme::CPANModules module's POD documentation, you can
install all the listed modules (entries) using L<cpanm-cpanmodules> script (from
L<App::cpanm::cpanmodules> distribution):

 % cpanm-cpanmodules -n OrderedHash

Alternatively you can use the L<cpanmodules> CLI (from L<App::cpanmodules>
distribution):

    % cpanmodules ls-entries OrderedHash | cpanm -n

or L<Acme::CM::Get>:

    % perl -MAcme::CM::Get=OrderedHash -E'say $_->{module} for @{ $LIST->{entries} }' | cpanm -n

or directly:

    % perl -MAcme::CPANModules::OrderedHash -E'say $_->{module} for @{ $Acme::CPANModules::OrderedHash::LIST->{entries} }' | cpanm -n

This Acme::CPANModules module contains benchmark instructions. You can run a
benchmark for some/all the modules listed in this Acme::CPANModules module using
the L<bencher> CLI (from L<Bencher> distribution):

    % bencher --cpanmodules-module OrderedHash

This Acme::CPANModules module also helps L<lcpan> produce a more meaningful
result for C<lcpan related-mods> command when it comes to finding related
modules for the modules listed in this Acme::CPANModules module.
See L<App::lcpan::Cmd::related_mods> for more details on how "related modules"
are found.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Acme-CPANModules-OrderedHash>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Acme-CPANModules-OrderedHash>.

=head1 SEE ALSO

L<Acme::CPANModules::HashUtilities>

L<Acme::CPANModules> - about the Acme::CPANModules namespace

L<cpanmodules> - CLI tool to let you browse/view the lists

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTOR

=for stopwords Michael Conrad

Michael Conrad <mike@nrdvana.net>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2025 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Acme-CPANModules-OrderedHash>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
