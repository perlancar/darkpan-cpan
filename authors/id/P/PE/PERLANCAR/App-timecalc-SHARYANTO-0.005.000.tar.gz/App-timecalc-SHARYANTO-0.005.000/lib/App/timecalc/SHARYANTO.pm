package App::timecalc::SHARYANTO;

# xAUTHORITY
our $DATE = '2020-10-27'; # DATE
our $DIST = 'App-timecalc-SHARYANTO'; # DIST
our $VERSION = '0.005.000'; # VERSION

use 5.010001;
use strict;
use warnings;

use Exporter 'import';
our @EXPORT_OK = qw(eval_time_expr);

sub eval_time_expr {
    my $str = shift;

    my ($h, $m, $s) = (0, 0, 0);

    my @fragments;

    $str =~ s{
                 \s*
                 \[
                 (?:
                     (?:
                         (?<h1_colon>\d\d?):(?<m1_colon>\d\d?)(?: :(?<s1_colon>\d\d?))? |
                         (?<h1_nocolon>\d\d?)(?<m1_nocolon>\d\d)(?<s1_nocolon>\d\d)?
                     )
                     \s*-\s*
                     (?:
                         (?<h2_colon>\d\d?):(?<m2_colon>\d\d?)(?: :(?<s2_colon>\d\d?))? \s* |
                         (?<h2_nocolon>\d\d?)(?<m2_nocolon>\d\d)(?<s2_nocolon>\d\d)?
                     )
                 |
                     \+
                     (?:
                         (?<hplus_colon>\d\d?):(?<mplus_colon>\d\d?)(?: :(?<splus_colon>\d\d?))? |
                         (?<hplus_nocolon>\d\d?)(?<mplus_nocolon>\d\d)(?<splus_nocolon>\d\d)?
                     )
                 |
                     -
                     (?:
                         (?<hminus_colon>\d\d?):(?<mminus_colon>\d\d?)(?: :(?<sminus_colon>\d\d?))? \s* |
                         (?<hminus_nocolon>\d\d?)(?<mminus_nocolon>\d\d)(?<sminus_nocolon>\d\d)?
                     )
                 )
                 (?:
                     \s+ (?<note>[^\]]+)
                 )?
                 \]
                 \s*
         }{

             push @fragments, {note=>$+{note} // ""};

             if (defined $+{h1_colon} || defined $+{h1_nocolon}) {
                 my ($h1, $m1, $s1) = defined $+{h1_colon} ?
                     ($+{h1_colon}  , $+{m1_colon}  , $+{s1_colon}   // 0) :
                     ($+{h1_nocolon}, $+{m1_nocolon}, $+{s1_nocolon} // 0);
                 my ($h2, $m2, $s2) = defined $+{h2_colon} ?
                     ($+{h2_colon}  , $+{m2_colon}  , $+{s2_colon}   // 0) :
                     ($+{h2_nocolon}, $+{m2_nocolon}, $+{s2_nocolon} // 0);
                 if ($h1 > 24) { die "Hour cannot exceed 24: $h1" }
                 if ($h2 > 24) { die "Hour cannot exceed 24: $h2" }
                 if ($h2 < $h1 || $h2 <= $h1 && $m2 <= $m1) { $h2 += 24 }
                 $h += ($h2-$h1);
                 $m += ($m2-$m1);
                 $s += ($s2-$s1);
             } elsif (defined $+{hplus_colon} || defined $+{hplus_nocolon}) {
                 if (defined $+{hplus_colon}) {
                     $h += $+{hplus_colon};
                     $m += $+{mplus_colon};
                     $s += $+{splus_colon} // 0;
                 } else {
                     $h += $+{hplus_nocolon};
                     $m += $+{mplus_nocolon};
                     $s += $+{splus_nocolon} // 0;
                 }
             } elsif (defined $+{hminus_colon} || defined $+{hminus_nocolon}) {
                 if (defined $+{hminus_colon}) {
                     $h -= $+{hminus_colon};
                     $m -= $+{mminus_colon};
                     $s -= $+{sminus_colon} // 0;
                 } else {
                     $h -= $+{hminus_nocolon};
                     $m -= $+{mminus_nocolon};
                     $s -= $+{sminus_nocolon} // 0;
                 }
             }

             "";
         }egsx;

    die "Unexpected string near '$str'" if length $str;

    while ($s < 0) {
        $m--;
        $s += 60;
    }
    while ($s >= 60) {
        $m++;
        $s -= 60;
    }
    while ($m < 0) {
        $h--;
        $m += 60;
    }
    while ($m >= 60) {
        $h++;
        $m -= 60;
    }

    my $num_naps = 0; for (@fragments) { $num_naps++ if $_->{note} =~ /\bnap\b/i }

    sprintf "[total +%02d:%02d in %d fragment%s%s]",
        $h, $m,
        scalar(@fragments), (@fragments > 1 ? "s" : " "),
        ($num_naps ?
         sprintf(" incl %d nap%s", $num_naps, $num_naps > 1 ? "s" : " ") :
         sprintf("      %s    %s", " ", " "),
     );
}

1;
# ABSTRACT: Time calculator for my sleep journal

__END__

=pod

=encoding UTF-8

=head1 NAME

App::timecalc::SHARYANTO - Time calculator for my sleep journal

=head1 VERSION

This document describes version 0.005.000 of App::timecalc::SHARYANTO (from Perl distribution App-timecalc-SHARYANTO), released on 2020-10-27.

=head1 SYNOPSIS

See included script L<timecalc-for-my-sleep-journal>.

=head1 DESCRIPTION

=head1 FUNCTIONS

=head2 eval_time_expr

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=head1 SEE ALSO

L<timecalc> from L<App::timecalc>

=head1 AUTHOR

Steven Haryanto

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2020 by Steven Haryanto.  No
license is granted to other entities.

=cut
