# no code
## no critic: TestingAndDebugging::RequireUseStrict
package Sah::PSchemaBundle::Array;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2024-05-30'; # DATE
our $DIST = 'Sah-PSchemaBundle-Array'; # DIST
our $VERSION = '0.010'; # VERSION

1;
# ABSTRACT: Parameterized schemas related to array type

__END__

=pod

=encoding UTF-8

=head1 NAME

Sah::PSchemaBundle::Array - Parameterized schemas related to array type

=head1 VERSION

This document describes version 0.010 of Sah::PSchemaBundle::Array (from Perl distribution Sah-PSchemaBundle-Array), released on 2024-05-30.

=head1 DESCRIPTION

The L<Sah>'s C<array> type supports some basic constraint clauses: C<min_len>,
C<max_len>, C<len>, C<len_between> (for checking number of elements), C<uniq>
(for checking that elements are unique), C<has> (for checking that a specified
value is found in array).

Until L<Data::Sah> allows easier creation of custom clauses, this distribution
contains schemas that allow you to perform additional checks.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Sah-PSchemaBundle-Array>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Sah-PSchemaBundle-Array>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Sah-PSchemaBundle-Array>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
