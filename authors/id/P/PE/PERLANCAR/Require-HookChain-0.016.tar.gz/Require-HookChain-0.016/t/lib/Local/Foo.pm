package Local::Foo;
1;
