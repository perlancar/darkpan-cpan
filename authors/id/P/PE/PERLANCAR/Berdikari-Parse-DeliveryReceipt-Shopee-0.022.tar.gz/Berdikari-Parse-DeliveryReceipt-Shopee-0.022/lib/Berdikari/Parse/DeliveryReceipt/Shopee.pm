package Berdikari::Parse::DeliveryReceipt::Shopee;

use 5.014;
use strict;
use warnings;
use Log::ger;

use Berdikari::Parse::DeliveryReceipt::Common qw(
                                                    convert_skus_qtys_to_hashref
                                                    convert_receipt_items_to_warehouse_items
                                                    handle_special_codes
                                                    encode_items_str
                                                    receipt_filename
                                                    add_sku
                                                    %argspecopt_store
                                            );
use IPC::System::Options qw(system readpipe);
use Perinci::Object;

our $AUTHORITY = 'steven:STEVEN'; # AUTHORITY
our $DATE = '2026-02-09'; # DATE
our $DIST = 'Berdikari-Parse-DeliveryReceipt-Shopee'; # DIST
our $VERSION = '0.022'; # VERSION

our %SPEC;

$SPEC{parse_delivery_receipt} = {
    v => 1.1,
    summary => "Parse Berdikari's Shopee delivery receipt (resi pengiriman)",
    args => {
        filename => {
            schema => 'filename::exists*',
            req => 1,
            pos => 0,
        },
        %argspecopt_store,
    },
    deps => {
        all => [
            {prog => 'pdftotext'},
            {prog => 'pdfinfo'},
        ],
    },
};
sub parse_delivery_receipt {
    require Encode;

    my %args = @_;
    my $filename = $args{filename} or return [400, "Please specify filename"];
    my $store = $args{store};

    my $variant;

    my $info     = `pdfinfo '$filename'`;
    $info =~ /^Page size:\s+(.+)/m or return [500, "Can't extract page size from pdfinfo (info=$info)"];
    my $pagesize = $1;
    log_trace "Page size: $pagesize"; # XXX strange, why won't it show?
    if ($pagesize =~ /A4/) {
        $variant = "A4";
    } elsif ($pagesize =~ /(419\.04|420|334\.08) pts/) {
        $variant = "A6";
    } else {
        return [500, "Can't figure out receipt variant (1)"];
    }

    my $text     = `pdftotext      '$filename' - 2>/dev/null`; $text     = Encode::decode('UTF-8', $text    , Encode::FB_CROAK());
    my $text_raw = `pdftotext -raw '$filename' - 2>/dev/null`; $text_raw = Encode::decode('UTF-8', $text_raw, Encode::FB_CROAK());

    my $order_id;
    {
        $text =~ /Pesanan: (\d\w+)/ and do { $order_id = $1; last };
        $text =~ /^Pesan: \((\d\w+)\)/m and do { $order_id = $1; last };
    }
    $order_id or warn "Warning: Can't extract order ID from text";
    my $order_date; $order_id =~ /\A(\d\d)(\d\d)(\d\d)/ and $order_date = "20$1-$2-$3";

    my ($receipt_id) = $text =~ /\b(?:No\. Resi|Resi):\s*(\S+)/s;
    my ($is_instant, $is_sameday);
    if ($text_raw =~ /^(INSTANT|INT)$/m) {
        $is_instant = 1;
        $receipt_id //= $order_id;
    } if ($text_raw =~ /^(SAMEDAY|Same-day)$/m) {
        $is_sameday = 1;
        $receipt_id //= $order_id;
    } else {
        warn "Warning: Can't figure out receipt ID from text" unless $receipt_id;
    }

    my $courier;
    if ($receipt_id =~ /^JP/) {
        $courier = "J&T";
    } elsif ($receipt_id =~ /^SPX/ || $is_instant) {
        $courier = "SPX";
    } elsif ($receipt_id =~ /^(\d{2})(\d{2})(\d{2})\w{8}\z/ && $text =~ /\bINT\b/) {
        $courier = "SPX (Instant)";
    } elsif (!defined($receipt_id) && $text =~ /\bINT\b/) {
        $courier = "Shopee Express (Instant)";
        $receipt_id = $order_id;
    } elsif ($receipt_id =~ /\A\d{14}\z/) {
        $courier = "Anteraja";
    } elsif ($receipt_id =~ /^CM/) {
        $courier = "JNE";
    } elsif ($is_sameday) {
        $courier = "Sameday"; # dari pdftotext tidak bisa dibedakan jenis sameday (GrabExpress, SPX, etc) dari text, hanya dari icon
    }

    warn "Warning: Can't figure out courier from receipt ID '$receipt_id'" unless $courier;

    # assume page2 if can't get courier & receipt id
    my $is_first_page = 1;
    unless ($courier || $receipt_id) {
        warn "Can't get courier & receipt ID, probably page 2+?";
        $is_first_page = 0;
    }

    my ($customer_name)    = $text =~ /Penerima: (.+)/;
    $customer_name =~ s/\s*Pengirim:.*//;

    my ($customer_address) = $text_raw =~ /(?:6285871296352\R)?
                                           (?:[^\n]+)\R  # nama penerima
                                           (.+?)
                                         Berat: /msx;
    $customer_address =~ s/\R+/ /g;
    my  ($customer_regency, $customer_city, $customer_province) = $customer_address =~ /([^,]+), ([^,]+), ([^,]+)\z/;
    for ($customer_regency, $customer_city, $customer_province) { s/\A\s+|\s+\z//g }

    my (@skus, @qtys);
  FIND_ITEMS: {
        {
            log_trace "Finding items (method 1, deprecated)";
            my ($text_after_product_list_header) = $text_raw =~ /# Nama[^\n]+(.+)/s;
            log_trace "Text after product list header: <<<$1>>>";
            my %skus;
            while ($text_after_product_list_header =~ /\b([A-Z]{3,}[A-Z0-9x]+(?:\R+[A-Z0-9x]+)?(?:\.[A-Z0-9]+)?) # sku code
                                                       (?:
                                                           [ \t\r\n]
                                                           \w+     # variant, currently we only support one-word
                                                       )?
                                                       [ \t\r\n]
                                                       (\d+)  # quantity
                                                       \R/gmsx) {
                if ($2 > 1000) {
                    log_trace "This is probably not an item: $1 => $2 (too many), skipped";
                    next;
                }
                log_trace "This is probably an item: $1 => $2";
                add_sku(\%skus, $1, $2);
            }
            @skus = sort keys %skus; @qtys = map { $skus{$_} } @skus;
            do { log_trace "Found items using method 1: SKUs=%s, QTYs=%s", \@skus, \@qtys; last FIND_ITEMS } if @skus;
        } # method 1

        {
            log_trace "Finding items (method 2)";
            my ($skus) = $text =~ /^SKU\R((?:(?:\S+)\R)+)/ms;
            last unless $skus;
            @skus = grep {/\S/} split /\R+/, $skus;
            my ($qtys) = $text =~ /^Qty\R((?:(?:\d+)\R)+)/ms;
            last unless $qtys;
            @qtys = grep {/\d/} split /\R+/, $qtys;
            do { log_trace "Found items using method 2: SKUs=%s, QTYs=%s", \@skus, \@qtys; last FIND_ITEMS } if @skus;
        } # method 2

        # saat ini untuk resi instan, kode SKU tidak dicantumkan di resi
        if ($is_instant || $is_sameday) {
            @skus = ("?");
            @qtys = ("?");
            return [412, "Can't extract SKUs for instant receipts, please fix this manually (file: $filename)"];
            last FIND_ITEMS;
        }

        return [500, "Can't find SKUs (tried methods 1, 2) for first page"] if $is_first_page;
    } # FIND_ITEMS

    my $is_cod; $is_cod++ unless $text =~ /COD: Rp0\R/s;

    my $receipt_items = convert_skus_qtys_to_hashref(\@skus, \@qtys);

    my $wh_items = convert_receipt_items_to_warehouse_items(
        receipt_items => $receipt_items,
        store => $store,
    );

    my $gift_pcs = {};
    my $sample_pcs = {};
    my $etc_pcs = {};

    my $res_encode = encode_items_str(
        items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
    );
    die "Can't encode items: $res_encode->[0] - $res_encode->[1]" unless $res_encode->[0] == 200;

    my $res_sc = handle_special_codes(
        items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
        text => $text,
        text_raw => $text_raw,
    );
    die "Can't handle special codes: $res_sc->[0] - $res_sc->[1]" unless $res_sc->[0] == 200;
    my $promo_code = $res_sc->[2];

    my $res0 = {
        is_first_page => $is_first_page,
        variant => $variant,
        receipt_id => $receipt_id,
        courier => $courier,
        order_id => $order_id,
        order_date => $order_date,
        customer_name => $customer_name,
        customer_address => $customer_address,
        customer_regency => $customer_regency,
        customer_city => $customer_city,
        customer_province => $customer_province,
        is_cod => $is_cod,
        receipt_items => $receipt_items,
        wh_items => $wh_items,
        gift_pcs => $gift_pcs,
        sample_pcs => $sample_pcs,
        etc_pcs => $etc_pcs,
        promo_code => $promo_code,
        text => $text,
        text_raw => $text_raw,
    };

    [200, "OK", $res0];
}

my $argspecopt_overwrite = {
    overwrite => {
        schema => 'bool',
        default => 1,
    },
};

$SPEC{rename_delivery_receipt} = {
    v => 1.1,
    summary => "Rename Berdikari's Shopee delivery receipt to a standardized format",
    args => {
        filename => {
            schema => 'filename::exists*',
            req => 1,
            pos => 0,
        },
        %$argspecopt_overwrite,
        %argspecopt_store,
    },
    features => {
        dry_run => 1,
    },
};
sub rename_delivery_receipt {
    my %args = @_;
    my $filename = $args{filename};
    my $overwrite = $args{overwrite} // 1;
    my $store = $args{store} // 'berdikari';

    my $res = parse_delivery_receipt(filename => $filename);
    return [500, "Can't parse delivery receipt '$filename': $res->[0] - $res->[1]"]
        unless $res->[0] == 200;

    my $safe_courier = lc $res->[2]{courier}; $safe_courier =~ s/\W+/_/g;
    my $safe_customer_name = lc $res->[2]{customer_name}; $safe_customer_name =~ s/\W+/_/g;

    my $new_filename = receipt_filename(
        store => $store,
        marketplace => "shopee",
        is_first_page => $res->[2]{is_first_page},
        order_id => $res->[2]{order_id},
        number => $res->[2]{receipt_id},
        customer => $res->[2]{customer_name},
        courier => $res->[2]{courier},
        receipt_items => $res->[2]{receipt_items},
        wh_items => $res->[2]{wh_items},
        gift_pcs => $res->[2]{gift_pcs},
        sample_pcs => $res->[2]{sample_pcs},
        etc_pcs => $res->[2]{etc_pcs},
        promo_code => $res->[2]{promo_code},
    );

    my $new_filename_final;
    my $counter = 0;
    while (1) {
        $new_filename_final = $new_filename . ($counter ? ".$counter" : "");
        if (!$overwrite && (-e $new_filename_final)) {
            log_trace "File % exists, incrementing counter";
            $counter++;
            next;
        } else {
            log_info "Renaming %s to %s ...", $filename, $new_filename_final;
        }

        if ($args{-dry_run}) {
            log_info "[DRY RUN] Renaming %s to %s ...", $filename, $new_filename_final;
            return [200, "OK (dry-run)"];
        } else {
            rename $filename, $new_filename or return [500, "Can't rename $filename to $new_filename_final: $!"];
            return [200, "OK"];
        }
        # should not reach here
    }
}

$SPEC{rename_delivery_receipts} = {
    v => 1.1,
    summary => "Rename Berdikari's Shopee delivery receipts to a standardized format",
    args => {
        filenames => {
            schema => ['array*', of=>'filename::exists*'],
            req => 1,
            pos => 0,
            slurpy => 1,
        },
        %$argspecopt_overwrite,
    },
    features => {
        dry_run => 1,
    },
};
sub rename_delivery_receipts {
    my %args = @_;
    my $filenames = $args{filenames};
    my $overwrite = $args{overwrite} // 1;

    my $res = envresmulti();
    for my $filename (@$filenames) {
        log_info "Processing file %s ...", $filename;
        my $fres = rename_delivery_receipt(filename => $filename, overwrite => $overwrite, -dry_run => $args{-dry_run});
        $res->add_result($fres->[0], $fres->[1], {item_id => $filename});
    }
    $res->as_struct;
}

$SPEC{parse_delivery_receipts_to_csv} = {
    v => 1.1,
    summary => "Parse Berdikari's Shopee delivery receipts to CSV",
    args => {
        filenames => {
            schema => ['array*', of=>'filename::exists*'],
            req => 1,
            pos => 0,
            slurpy => 1,
        },
    },
    features => {
        dry_run => 1,
    },
};
sub parse_delivery_receipts_to_csv {
    my %args = @_;
    my $filenames = $args{filenames};

    print "tanggal,internal_order_id,order_id,customer_name,customer_province,customer_city,customer_regency,sku,quantity,is_self_order,is_cod\n";
    for my $filename (@$filenames) {
        log_info "Processing file %s ...", $filename;
        my $fres = parse_delivery_receipt(filename => $filename);
        die "FATAL: Can't parse receipt '$filename': $fres->[0] - $fres->[1]" unless $fres->[0] == 200;
        my $r = $fres->[2]; # r=receipt
        my $line = 0;
        for my $item (@{ $r->{items} }) {
            $line++;
            if ($line == 1) { print qq($r->{order_date},$r->{order_id},$r->{order_id},"$r->{customer_name}",$r->{customer_province},$r->{customer_city},$r->{customer_regency}) }
            else            { print qq($r->{order_date},$r->{order_id} (line $line),$r->{order_id},,,,) }
            print ",", $item->{sku}, ",", $item->{quantity}, ",no,", ($r->{is_cod} ? "yes":"no");
            print "\n";
        }
    }
    [200];
}

1;
# ABSTRACT: Rename Berdikari's Shopee delivery receipt to a standardized format

__END__

=pod

=encoding UTF-8

=head1 NAME

Berdikari::Parse::DeliveryReceipt::Shopee - Rename Berdikari's Shopee delivery receipt to a standardized format

=head1 VERSION

This document describes version 0.022 of Berdikari::Parse::DeliveryReceipt::Shopee (from Perl distribution Berdikari-Parse-DeliveryReceipt-Shopee), released on 2026-02-09.

=head1 FUNCTIONS


=head2 parse_delivery_receipt

Usage:

 parse_delivery_receipt(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse Berdikari's Shopee delivery receipt (resi pengiriman).

This function is not exported.

Arguments ('*' denotes required arguments):

=over 4

=item * B<filename>* => I<filename::exists>

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 parse_delivery_receipts_to_csv

Usage:

 parse_delivery_receipts_to_csv(%args) -> [$status_code, $reason, $payload, \%result_meta]

Parse Berdikari's Shopee delivery receipts to CSV.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<filenames>* => I<array[filename::exists]>

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 rename_delivery_receipt

Usage:

 rename_delivery_receipt(%args) -> [$status_code, $reason, $payload, \%result_meta]

Rename Berdikari's Shopee delivery receipt to a standardized format.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<filename>* => I<filename::exists>

(No description)

=item * B<overwrite> => I<bool> (default: 1)

(No description)

=item * B<store> => I<str> (default: "berdikari")

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)



=head2 rename_delivery_receipts

Usage:

 rename_delivery_receipts(%args) -> [$status_code, $reason, $payload, \%result_meta]

Rename Berdikari's Shopee delivery receipts to a standardized format.

This function is not exported.

This function supports dry-run operation.


Arguments ('*' denotes required arguments):

=over 4

=item * B<filenames>* => I<array[filename::exists]>

(No description)

=item * B<overwrite> => I<bool> (default: 1)

(No description)


=back

Special arguments:

=over 4

=item * B<-dry_run> => I<bool>

Pass -dry_run=E<gt>1 to enable simulation mode.

=back

Returns an enveloped result (an array).

First element ($status_code) is an integer containing HTTP-like status code
(200 means OK, 4xx caller error, 5xx function error). Second element
($reason) is a string containing error message, or something like "OK" if status is
200. Third element ($payload) is the actual result, but usually not present when enveloped result is an error response ($status_code is not 2xx). Fourth
element (%result_meta) is called result metadata and is optional, a hash
that contains extra information, much like how HTTP response headers provide additional metadata.

Return value:  (any)

=head1 AUTHOR

Steven Haryanto

=head1 CONTRIBUTORS

=for stopwords Steven Haryanto

=over 4

=item *

Steven Haryanto <stevenharyanto@gmail.com>

=item *

Steven Haryanto <stevenptbtc@gmail.com>

=back

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2026, 2025 by Steven Haryanto.  No
license is granted to other entities.

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=cut
