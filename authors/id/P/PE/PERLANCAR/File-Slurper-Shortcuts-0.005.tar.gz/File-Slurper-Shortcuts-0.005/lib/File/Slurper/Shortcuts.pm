package File::Slurper::Shortcuts;

use strict 'subs', 'vars';
use warnings;
no warnings 'once';
use Carp;

use File::Slurper ();

use Exporter qw(import);

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2023-07-09'; # DATE
our $DIST = 'File-Slurper-Shortcuts'; # DIST
our $VERSION = '0.005'; # VERSION

our @EXPORT_OK = qw(
                       modify_text
                       modify_binary
                       replace_text
                       replace_binary
                       read_text_chomp_if_exists
               );

sub modify_text {
    my ($filename, $code, $encoding, $crlf) = @_;

    local $_ = File::Slurper::read_text($filename, $encoding, $crlf);
    my $orig = $_;

    my $res = $code->($_);
    croak "replace_text(): Code does not return true" unless $res;

    return if $orig eq $_;

    File::Slurper::write_text($filename, $_, $encoding, $crlf);
    $orig;
}

sub modify_binary {
    return modify_text(@_[0,1], 'latin-1');
}

# old names, deprecated and will be removed in the future
*replace_text = \&modify_text;
*replace_binary = \&modify_binary;

sub read_text_chomp_if_exists {
    my ($filename, $encoding, $crlf) = @_;
    return unless -e $filename;
    my $content = File::Slurper::read_text($filename, $encoding, $crlf);
    chomp $content;
    $content;
}

1;
# ABSTRACT: Some convenience additions for File::Slurper

__END__

=pod

=encoding UTF-8

=head1 NAME

File::Slurper::Shortcuts - Some convenience additions for File::Slurper

=head1 VERSION

This document describes version 0.005 of File::Slurper::Shortcuts (from Perl distribution File-Slurper-Shortcuts), released on 2023-07-09.

=head1 SYNOPSIS

 use File::Slurper::Shortcuts qw(
     modify_text
     modify_binary
     read_text_chomp_if_exists
 );
 modify_text("dist.ini", sub { s/One/Two/ });

=head1 DESCRIPTION

=for Pod::Coverage ^(replace_text|replace_binary)$

=head1 FUNCTIONS

=head2 modify_text

Usage:

 $orig_content = modify_text($filename, $code, $encoding, $crlf);

This is L<File::Slurper>'s C<read_text> and C<write_text> combined. First,
C<read_text> is performed then the content of file is put into C<$_>. Then
C<$code> will be called and should modify C<$_> to modify the content of file.
Finally, C<write_text> is called to write the new content. If content (C<$_>)
does not change, file will not be written.

If file can't be read with C<read_text()> an exception will be thrown by
File::Slurper.

This function will also die if code does not return true.

If file can't be written with C<write_text()> an exception will be thrown by
File::Slurper.

Return the original content of file.

Note that no locking is performed and file is opened twice, so there might be
race condition etc.

=head2 modify_binary

=head2 read_text_chomp_if_exists

Usage:

 my $line = read_text_chomp_if_exists($filename);

Shortcut for:

 return unless -e $filename;
 my $content = read_text($filename);
 chomp $content;
 $content;

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/File-Slurper-Shortcuts>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-File-Slurper-Shortcuts>.

=head1 SEE ALSO

L<File::Slurper>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2023, 2019, 2018 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=File-Slurper-Shortcuts>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
