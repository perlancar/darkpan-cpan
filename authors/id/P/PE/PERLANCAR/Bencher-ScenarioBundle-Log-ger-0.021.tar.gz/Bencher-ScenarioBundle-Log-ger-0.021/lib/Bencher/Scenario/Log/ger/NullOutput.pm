package Bencher::Scenario::Log::ger::NullOutput;

use 5.010001;
use strict;
use warnings;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2024-07-18'; # DATE
our $DIST = 'Bencher-ScenarioBundle-Log-ger'; # DIST
our $VERSION = '0.021'; # VERSION

our $scenario = {
    summary => 'Benchmark Log::ger logging speed with the default/null output',
    modules => {
        'Log::ger' => {},
        'Log::ger::Format::MultilevelLog' => {},
        'Log::ger::Plugin::OptAway' => {},
        'Log::Any' => {},
        'Log::Any::Simple' => {},
        'Log::Fast' => {},
        'Log::Log4perl' => {},
        'Log::Log4perl::Tiny' => {},
        'Log::Contextual' => {},
        'Log::Contextual::SimpleLogger' => {},
        'Log::Dispatch' => {},
        'Log::Dispatch::Null' => {},
        'Log::Dispatchouli' => {},
        'Mojo::Log' => {},
        'XLog' => {},
    },
    participants => [
        {
            name => 'Log::ger-100k_log_trace',
            perl_cmdline_template => ['-MLog::ger', '-e', 'for(1..100_000) { log_trace(q[]) }'],
        },
        {
            name => 'Log::ger-100k_log_is_trace',
            perl_cmdline_template => ['-MLog::ger', '-e', 'for(1..100_000) { log_is_trace() }'],
        },
        {
            name => 'Log::ger+LGP:OptAway-100k_log_trace',
            perl_cmdline_template => ['-MLog::ger::Plugin=OptAway', '-MLog::ger', '-e', 'for(1..100_000) { log_trace(q[]) }'],
        },
        {
            name => 'Log::ger+LGF:MutilevelLog-100k_log_trace',
            perl_cmdline_template => ['-MLog::ger::Format=MultilevelLog', '-MLog::ger', '-e', 'for(1..100_000) { log("trace", q[]) }'],
        },
        {
            name => 'Log::ger+LGP:MutilevelLog-100k_log_6',
            perl_cmdline_template => ['-MLog::ger::Format=MultilevelLog', '-MLog::ger', '-e', 'for(1..100_000) { log(6, q[]) }'],
        },

        {
            name => 'Log::Fast-100k_DEBUG',
            perl_cmdline_template => ['-MLog::Fast', '-e', '$LOG = Log::Fast->global; $LOG->level("INFO"); for(1..100_000) { $LOG->DEBUG(q()) }'],
        },
        {
            name => 'Log::Fast-100k_is_debug',
            perl_cmdline_template => ['-MLog::Fast', '-e', '$LOG = Log::Fast->global; for(1..100_000) { $LOG->level() eq "DEBUG" }'],
        },

        {
            name => 'Log::Any-no_adapter-100k_log_trace',
            perl_cmdline_template => ['-MLog::Any', '-e', 'my $log = Log::Any->get_logger; for(1..100_000) { $log->trace(q[]) }'],
        },
        {
            name => 'Log::Any-no_adapter-100k_is_trace' ,
            perl_cmdline_template => ['-MLog::Any', '-e', 'my $log = Log::Any->get_logger; for(1..100_000) { $log->is_trace }'],
        },
        {
            name => 'Log::Any-null_adapter-100k_log_trace',
            perl_cmdline_template => ['-MLog::Any', '-MLog::Any::Adapter', '-e', 'Log::Any::Adapter->set(q[Null]); my $log = Log::Any->get_logger; for(1..100_000) { $log->trace(q[]) }'],
        },
        {
            name => 'Log::Any-null_adapter-100k_is_trace' ,
            perl_cmdline_template => ['-MLog::Any', '-MLog::Any::Adapter', '-e', 'Log::Any::Adapter->set(q[Null]); my $log = Log::Any->get_logger; for(1..100_000) { $log->is_trace }'],
        },

        {
            name => 'Log::Any::Simple-no_adapter-100k_log_trace',
            perl_cmdline_template => ['-MLog::Any::Simple=:default', '-e', 'for(1..100_000) { trace(q[]) }'],
        },
        {
            name => 'Log::Any::Simple-null_adapter-100k_log_trace',
            perl_cmdline_template => ['-MLog::Any::Simple=:default', '-MLog::Any::Adapter', '-e', 'Log::Any::Adapter->set(q[Null]); for(1..100_000) { trace(q[]) }'],
        },

        {
            name => 'Log::Dispatch::Null-100k_debug' ,
            perl_cmdline_template => ['-MLog::Dispatch', '-e', 'my $null = Log::Dispatch->new(outputs=>[["Null", min_level=>"debug"]]); for(1..100_000) { $null->debug("") }'],
        },

        {
            name => 'Log::Log4perl-easy-100k_trace' ,
            perl_cmdline_template => ['-MLog::Log4perl=:easy', '-e', 'Log::Log4perl->easy_init($ERROR); for(1..100_000) { TRACE "" }'],
        },

        {
            name => 'Log::Log4perl::Tiny-100k_trace' ,
            perl_cmdline_template => ['-MLog::Log4perl::Tiny=:easy', '-e', 'for(1..100_000) { TRACE "" }'],
        },

        {
            name => 'Log::Contextual+Log4perl-100k_trace' ,
            perl_cmdline_template => ['-e', 'use Log::Contextual ":log", "set_logger"; use Log::Log4perl ":easy"; Log::Log4perl->easy_init($DEBUG); my $logger = Log::Log4perl->get_logger; set_logger $logger; for(1..100_000) { log_trace {} }'],
        },
        {
            name => 'Log::Contextual+SimpleLogger-100k_trace' ,
            perl_cmdline_template => ['-MLog::Contextual::SimpleLogger', '-e', 'use Log::Contextual ":log", -logger=>Log::Contextual::SimpleLogger->new({levels=>["debug"]}); for(1..100_000) { log_trace {} }'],
        },

        {
            name => 'Log::Dispatchouli-100k_debug' ,
            perl_cmdline_template => ['-MLog::Dispatchouli', '-e', '$logger = Log::Dispatchouli->new({ident=>"ident", facility=>"facility", to_stdout=>1, debug=>0}); for(1..100_000) { $logger->log_debug("") }'],
        },

        {
            name => 'Mojo::Log-100k_debug' ,
            perl_cmdline_template => ['-MMojo::Log', '-e', '$log = Mojo::Log->new(level=>"warn"); for(1..100_000) { $log->debug("") }'],
        },

        {
            name => 'XLog-100k_debug' ,
            perl_cmdline_template => ['-MXLog', '-e', 'for(1..100_000) { XLog::debug("") }'],
        },
    ],
    precision => 6,
};

1;
# ABSTRACT: Benchmark Log::ger logging speed with the default/null output

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::Log::ger::NullOutput - Benchmark Log::ger logging speed with the default/null output

=head1 VERSION

This document describes version 0.021 of Bencher::Scenario::Log::ger::NullOutput (from Perl distribution Bencher-ScenarioBundle-Log-ger), released on 2024-07-18.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m Log::ger::NullOutput

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Log::Any> 1.717

L<Log::Any::Simple> 0.04

L<Log::Contextual> 0.008001

L<Log::Contextual::SimpleLogger> 0.008001

L<Log::Dispatch> 2.71

L<Log::Dispatch::Null> 2.71

L<Log::Dispatchouli> 3.007

L<Log::Fast> v2.0.1

L<Log::Log4perl> 1.57

L<Log::Log4perl::Tiny> 1.8.0

L<Log::ger> 0.042

L<Log::ger::Format::MultilevelLog> 0.042

L<Log::ger::Plugin::OptAway> 0.009

L<Mojo::Log>

L<XLog> 1.1.3

=head1 BENCHMARK PARTICIPANTS

=over

=item * Log::ger-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::ger -e for(1..100_000) { log_trace(q[]) }



=item * Log::ger-100k_log_is_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::ger -e for(1..100_000) { log_is_trace() }



=item * Log::ger+LGP:OptAway-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::ger::Plugin=OptAway -MLog::ger -e for(1..100_000) { log_trace(q[]) }



=item * Log::ger+LGF:MutilevelLog-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::ger::Format=MultilevelLog -MLog::ger -e for(1..100_000) { log("trace", q[]) }



=item * Log::ger+LGP:MutilevelLog-100k_log_6 (command)

Command line:

 #TEMPLATE: #perl -MLog::ger::Format=MultilevelLog -MLog::ger -e for(1..100_000) { log(6, q[]) }



=item * Log::Fast-100k_DEBUG (command)

Command line:

 #TEMPLATE: #perl -MLog::Fast -e $LOG = Log::Fast->global; $LOG->level("INFO"); for(1..100_000) { $LOG->DEBUG(q()) }



=item * Log::Fast-100k_is_debug (command)

Command line:

 #TEMPLATE: #perl -MLog::Fast -e $LOG = Log::Fast->global; for(1..100_000) { $LOG->level() eq "DEBUG" }



=item * Log::Any-no_adapter-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any -e my $log = Log::Any->get_logger; for(1..100_000) { $log->trace(q[]) }



=item * Log::Any-no_adapter-100k_is_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any -e my $log = Log::Any->get_logger; for(1..100_000) { $log->is_trace }



=item * Log::Any-null_adapter-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any -MLog::Any::Adapter -e Log::Any::Adapter->set(q[Null]); my $log = Log::Any->get_logger; for(1..100_000) { $log->trace(q[]) }



=item * Log::Any-null_adapter-100k_is_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any -MLog::Any::Adapter -e Log::Any::Adapter->set(q[Null]); my $log = Log::Any->get_logger; for(1..100_000) { $log->is_trace }



=item * Log::Any::Simple-no_adapter-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any::Simple=:default -e for(1..100_000) { trace(q[]) }



=item * Log::Any::Simple-null_adapter-100k_log_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Any::Simple=:default -MLog::Any::Adapter -e Log::Any::Adapter->set(q[Null]); for(1..100_000) { trace(q[]) }



=item * Log::Dispatch::Null-100k_debug (command)

Command line:

 #TEMPLATE: #perl -MLog::Dispatch -e my $null = Log::Dispatch->new(outputs=>[["Null", min_level=>"debug"]]); for(1..100_000) { $null->debug("") }



=item * Log::Log4perl-easy-100k_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Log4perl=:easy -e Log::Log4perl->easy_init($ERROR); for(1..100_000) { TRACE "" }



=item * Log::Log4perl::Tiny-100k_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Log4perl::Tiny=:easy -e for(1..100_000) { TRACE "" }



=item * Log::Contextual+Log4perl-100k_trace (command)

Command line:

 #TEMPLATE: #perl -e use Log::Contextual ":log", "set_logger"; use Log::Log4perl ":easy"; Log::Log4perl->easy_init($DEBUG); my $logger = Log::Log4perl->get_logger; set_logger $logger; for(1..100_000) { log_trace {} }



=item * Log::Contextual+SimpleLogger-100k_trace (command)

Command line:

 #TEMPLATE: #perl -MLog::Contextual::SimpleLogger -e use Log::Contextual ":log", -logger=>Log::Contextual::SimpleLogger->new({levels=>["debug"]}); for(1..100_000) { log_trace {} }



=item * Log::Dispatchouli-100k_debug (command)

Command line:

 #TEMPLATE: #perl -MLog::Dispatchouli -e $logger = Log::Dispatchouli->new({ident=>"ident", facility=>"facility", to_stdout=>1, debug=>0}); for(1..100_000) { $logger->log_debug("") }



=item * Mojo::Log-100k_debug (command)

Command line:

 #TEMPLATE: #perl -MMojo::Log -e $log = Mojo::Log->new(level=>"warn"); for(1..100_000) { $log->debug("") }



=item * XLog-100k_debug (command)

Command line:

 #TEMPLATE: #perl -MXLog -e for(1..100_000) { XLog::debug("") }



=back

=head1 BENCHMARK SAMPLE RESULTS

=head2 Sample benchmark #1

Run on: perl: I<< v5.38.2 >>, CPU: I<< Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz (2 cores) >>, OS: I<< GNU/Linux Ubuntu version 20.04 >>, OS kernel: I<< Linux version 5.4.0-164-generic >>.

Benchmark command (default options):

 % bencher -m Log::ger::NullOutput

Result formatted as table:

 #table1#
 +----------------------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | participant                                  | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +----------------------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | Log::Dispatch::Null-100k_debug               |       1.7 |     570   |                 0.00% |              4032.91% |   0.0056  |       6 |
 | Log::Contextual+Log4perl-100k_trace          |       2   |     500   |                13.98% |              3525.90% |   0.0058  |       7 |
 | Log::Contextual+SimpleLogger-100k_trace      |       2.1 |     470   |                22.66% |              3269.46% |   0.00087 |       8 |
 | Mojo::Log-100k_debug                         |       4   |     300   |               128.67% |              1707.34% |   0.0042  |       6 |
 | Log::Dispatchouli-100k_debug                 |       5.6 |     180   |               222.09% |              1183.17% |   0.0012  |       6 |
 | Log::Any::Simple-null_adapter-100k_log_trace |       8   |     100   |               334.79% |               850.54% |   0.0048  |       9 |
 | Log::Log4perl::Tiny-100k_trace               |       8.9 |     110   |               407.19% |               714.86% |   0.00041 |       6 |
 | Log::Fast-100k_is_debug                      |      14   |      70   |               716.80% |               405.99% |   0.00026 |       8 |
 | Log::Any::Simple-no_adapter-100k_log_trace   |      15   |      69   |               735.79% |               394.49% | 7.4e-05   |       6 |
 | Log::Any-null_adapter-100k_log_trace         |      15.5 |      64.3 |               790.84% |               363.93% | 4.7e-05   |       6 |
 | Log::Log4perl-easy-100k_trace                |      20   |      60   |               844.00% |               337.81% |   0.00071 |       7 |
 | Log::Any-null_adapter-100k_is_trace          |      20   |      50   |              1098.69% |               244.78% |   0.00086 |       6 |
 | Log::Any-no_adapter-100k_is_trace            |      23   |      44   |              1192.40% |               219.79% | 7.8e-05   |       6 |
 | Log::Fast-100k_DEBUG                         |      25   |      40   |              1321.61% |               190.72% | 6.5e-05   |       9 |
 | Log::ger+LGP:OptAway-100k_log_trace          |      30   |      40   |              1478.53% |               161.82% |   0.0013  |       6 |
 | XLog-100k_debug                              |      31   |      33   |              1654.61% |               135.55% |   0.00016 |       6 |
 | Log::ger+LGP:MutilevelLog-100k_log_6         |      40   |      30   |              2152.30% |                83.50% |   0.00063 |       9 |
 | Log::ger+LGF:MutilevelLog-100k_log_trace     |      40   |      20   |              2193.32% |                80.21% |   0.00076 |       7 |
 | Log::Any-no_adapter-100k_log_trace           |      40   |      25   |              2195.23% |                80.07% | 9.5e-05   |       6 |
 | Log::ger-100k_log_is_trace                   |      66   |      15   |              3669.15% |                 9.65% | 2.3e-05   |       6 |
 | Log::ger-100k_log_trace                      |      72   |      14   |              4032.91% |                 0.00% | 4.7e-05   |       6 |
 +----------------------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                                                  Rate  Log::Dispatch::Null-100k_debug  Log::Contextual+Log4perl-100k_trace  Log::Contextual+SimpleLogger-100k_trace  Mojo::Log-100k_debug  Log::Dispatchouli-100k_debug  Log::Log4perl::Tiny-100k_trace  Log::Any::Simple-null_adapter-100k_log_trace  Log::Fast-100k_is_debug  Log::Any::Simple-no_adapter-100k_log_trace  Log::Any-null_adapter-100k_log_trace  Log::Log4perl-easy-100k_trace  Log::Any-null_adapter-100k_is_trace  Log::Any-no_adapter-100k_is_trace  Log::Fast-100k_DEBUG  Log::ger+LGP:OptAway-100k_log_trace  XLog-100k_debug  Log::ger+LGP:MutilevelLog-100k_log_6  Log::Any-no_adapter-100k_log_trace  Log::ger+LGF:MutilevelLog-100k_log_trace  Log::ger-100k_log_is_trace  Log::ger-100k_log_trace 
  Log::Dispatch::Null-100k_debug                 1.7/s                              --                                 -12%                                     -17%                  -47%                          -68%                            -80%                                          -82%                     -87%                                        -87%                                  -88%                           -89%                                 -91%                               -92%                  -92%                                 -92%             -94%                                  -94%                                -95%                                      -96%                        -97%                     -97% 
  Log::Contextual+Log4perl-100k_trace              2/s                             13%                                   --                                      -6%                  -40%                          -64%                            -78%                                          -80%                     -86%                                        -86%                                  -87%                           -88%                                 -90%                               -91%                  -92%                                 -92%             -93%                                  -94%                                -95%                                      -96%                        -97%                     -97% 
  Log::Contextual+SimpleLogger-100k_trace        2.1/s                             21%                                   6%                                       --                  -36%                          -61%                            -76%                                          -78%                     -85%                                        -85%                                  -86%                           -87%                                 -89%                               -90%                  -91%                                 -91%             -92%                                  -93%                                -94%                                      -95%                        -96%                     -97% 
  Mojo::Log-100k_debug                             4/s                             89%                                  66%                                      56%                    --                          -40%                            -63%                                          -66%                     -76%                                        -77%                                  -78%                           -80%                                 -83%                               -85%                  -86%                                 -86%             -89%                                  -90%                                -91%                                      -93%                        -95%                     -95% 
  Log::Dispatchouli-100k_debug                   5.6/s                            216%                                 177%                                     161%                   66%                            --                            -38%                                          -44%                     -61%                                        -61%                                  -64%                           -66%                                 -72%                               -75%                  -77%                                 -77%             -81%                                  -83%                                -86%                                      -88%                        -91%                     -92% 
  Log::Log4perl::Tiny-100k_trace                 8.9/s                            418%                                 354%                                     327%                  172%                           63%                              --                                           -9%                     -36%                                        -37%                                  -41%                           -45%                                 -54%                               -60%                  -63%                                 -63%             -70%                                  -72%                                -77%                                      -81%                        -86%                     -87% 
  Log::Any::Simple-null_adapter-100k_log_trace     8/s                            470%                                 400%                                     370%                  200%                           80%                             10%                                            --                     -30%                                        -31%                                  -35%                           -40%                                 -50%                               -56%                  -60%                                 -60%             -67%                                  -70%                                -75%                                      -80%                        -85%                     -86% 
  Log::Fast-100k_is_debug                         14/s                            714%                                 614%                                     571%                  328%                          157%                             57%                                           42%                       --                                         -1%                                   -8%                           -14%                                 -28%                               -37%                  -42%                                 -42%             -52%                                  -57%                                -64%                                      -71%                        -78%                     -80% 
  Log::Any::Simple-no_adapter-100k_log_trace      15/s                            726%                                 624%                                     581%                  334%                          160%                             59%                                           44%                       1%                                          --                                   -6%                           -13%                                 -27%                               -36%                  -42%                                 -42%             -52%                                  -56%                                -63%                                      -71%                        -78%                     -79% 
  Log::Any-null_adapter-100k_log_trace          15.5/s                            786%                                 677%                                     630%                  366%                          179%                             71%                                           55%                       8%                                          7%                                    --                            -6%                                 -22%                               -31%                  -37%                                 -37%             -48%                                  -53%                                -61%                                      -68%                        -76%                     -78% 
  Log::Log4perl-easy-100k_trace                   20/s                            850%                                 733%                                     683%                  400%                          200%                             83%                                           66%                      16%                                         14%                                    7%                             --                                 -16%                               -26%                  -33%                                 -33%             -44%                                  -50%                                -58%                                      -66%                        -75%                     -76% 
  Log::Any-null_adapter-100k_is_trace             20/s                           1040%                                 900%                                     840%                  500%                          260%                            120%                                          100%                      39%                                         37%                                   28%                            19%                                   --                               -12%                  -19%                                 -19%             -34%                                  -40%                                -50%                                      -60%                        -70%                     -72% 
  Log::Any-no_adapter-100k_is_trace               23/s                           1195%                                1036%                                     968%                  581%                          309%                            150%                                          127%                      59%                                         56%                                   46%                            36%                                  13%                                 --                   -9%                                  -9%             -25%                                  -31%                                -43%                                      -54%                        -65%                     -68% 
  Log::Fast-100k_DEBUG                            25/s                           1325%                                1150%                                    1075%                  650%                          350%                            175%                                          150%                      75%                                         72%                                   60%                            50%                                  25%                                10%                    --                                   0%             -17%                                  -25%                                -37%                                      -50%                        -62%                     -65% 
  Log::ger+LGP:OptAway-100k_log_trace             30/s                           1325%                                1150%                                    1075%                  650%                          350%                            175%                                          150%                      75%                                         72%                                   60%                            50%                                  25%                                10%                    0%                                   --             -17%                                  -25%                                -37%                                      -50%                        -62%                     -65% 
  XLog-100k_debug                                 31/s                           1627%                                1415%                                    1324%                  809%                          445%                            233%                                          203%                     112%                                        109%                                   94%                            81%                                  51%                                33%                   21%                                  21%               --                                   -9%                                -24%                                      -39%                        -54%                     -57% 
  Log::ger+LGP:MutilevelLog-100k_log_6            40/s                           1800%                                1566%                                    1466%                  900%                          500%                            266%                                          233%                     133%                                        129%                                  114%                           100%                                  66%                                46%                   33%                                  33%              10%                                    --                                -16%                                      -33%                        -50%                     -53% 
  Log::Any-no_adapter-100k_log_trace              40/s                           2180%                                1900%                                    1780%                 1100%                          620%                            340%                                          300%                     179%                                        175%                                  157%                           140%                                 100%                                76%                   60%                                  60%              32%                                   19%                                  --                                      -19%                        -40%                     -43% 
  Log::ger+LGF:MutilevelLog-100k_log_trace        40/s                           2750%                                2400%                                    2250%                 1400%                          800%                            450%                                          400%                     250%                                        245%                                  221%                           200%                                 150%                               120%                  100%                                 100%              64%                                   50%                                 25%                                        --                        -25%                     -30% 
  Log::ger-100k_log_is_trace                      66/s                           3700%                                3233%                                    3033%                 1900%                         1100%                            633%                                          566%                     366%                                        359%                                  328%                           300%                                 233%                               193%                  166%                                 166%             120%                                  100%                                 66%                                       33%                          --                      -6% 
  Log::ger-100k_log_trace                         72/s                           3971%                                3471%                                    3257%                 2042%                         1185%                            685%                                          614%                     400%                                        392%                                  359%                           328%                                 257%                               214%                  185%                                 185%             135%                                  114%                                 78%                                       42%                          7%                       -- 
 
 Legends:
   Log::Any-no_adapter-100k_is_trace: participant=Log::Any-no_adapter-100k_is_trace
   Log::Any-no_adapter-100k_log_trace: participant=Log::Any-no_adapter-100k_log_trace
   Log::Any-null_adapter-100k_is_trace: participant=Log::Any-null_adapter-100k_is_trace
   Log::Any-null_adapter-100k_log_trace: participant=Log::Any-null_adapter-100k_log_trace
   Log::Any::Simple-no_adapter-100k_log_trace: participant=Log::Any::Simple-no_adapter-100k_log_trace
   Log::Any::Simple-null_adapter-100k_log_trace: participant=Log::Any::Simple-null_adapter-100k_log_trace
   Log::Contextual+Log4perl-100k_trace: participant=Log::Contextual+Log4perl-100k_trace
   Log::Contextual+SimpleLogger-100k_trace: participant=Log::Contextual+SimpleLogger-100k_trace
   Log::Dispatch::Null-100k_debug: participant=Log::Dispatch::Null-100k_debug
   Log::Dispatchouli-100k_debug: participant=Log::Dispatchouli-100k_debug
   Log::Fast-100k_DEBUG: participant=Log::Fast-100k_DEBUG
   Log::Fast-100k_is_debug: participant=Log::Fast-100k_is_debug
   Log::Log4perl-easy-100k_trace: participant=Log::Log4perl-easy-100k_trace
   Log::Log4perl::Tiny-100k_trace: participant=Log::Log4perl::Tiny-100k_trace
   Log::ger+LGF:MutilevelLog-100k_log_trace: participant=Log::ger+LGF:MutilevelLog-100k_log_trace
   Log::ger+LGP:MutilevelLog-100k_log_6: participant=Log::ger+LGP:MutilevelLog-100k_log_6
   Log::ger+LGP:OptAway-100k_log_trace: participant=Log::ger+LGP:OptAway-100k_log_trace
   Log::ger-100k_log_is_trace: participant=Log::ger-100k_log_is_trace
   Log::ger-100k_log_trace: participant=Log::ger-100k_log_trace
   Mojo::Log-100k_debug: participant=Mojo::Log-100k_debug
   XLog-100k_debug: participant=XLog-100k_debug

To display as an interactive HTML table on a browser, you can add option C<--format html+datatables>.

=head1 BENCHMARK NOTES

Not included here:

=over

=item * L<Log::Tiny>

Cannot do null output, must log to a file. (Technically you can use F</dev/null>, but.)

=back

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-ScenarioBundle-Log-ger>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-ScenarioBundle-Log-ger>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024, 2023, 2021, 2020, 2018, 2017 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-ScenarioBundle-Log-ger>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
