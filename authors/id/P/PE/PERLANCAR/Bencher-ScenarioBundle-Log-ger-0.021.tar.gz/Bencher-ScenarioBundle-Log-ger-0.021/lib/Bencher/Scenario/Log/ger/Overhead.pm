package Bencher::Scenario::Log::ger::Overhead;

use 5.010001;
use strict;
use warnings;

use File::Temp qw(tempfile);

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2024-07-18'; # DATE
our $DIST = 'Bencher-ScenarioBundle-Log-ger'; # DIST
our $VERSION = '0.021'; # VERSION

my ($fh, $fname) = tempfile();

our $scenario = {
    summary => 'Measure startup overhead of various codes',
    modules => {
        'Log::Any' => {},
        'Log::ger' => {version=>'0.019'},
        'Log::ger::App' => {version=>'0.002'},
        'Log::ger::Output' => {version=>'0.005'},
        'Log::ger::Layout::Pattern' => {version=>'0'},
        'Log::Contextual' => {version=>'0'},
        'Log::Dispatch' => {version=>'0'},
        'Log::Dispatch::Null' => {version=>'0'},
        'Log::Log4perl' => {version=>'0'},
        'Log::Log4perl::Tiny' => {version=>'0'},
        'Log::Dispatchouli' => {version=>'0'},
        'Mojo::Log' => {version=>'0'},
        'XLog' => {},
    },
    code_startup => 1,
    participants => [
        # a benchmark for Log::ger: strict/warnings
        {code_template=>'use strict;'},
        {code_template=>'use warnings;'},
        {code_template=>'use strict; use warnings;'},

        {code_template=>'use Log::ger ();'},
        {code_template=>'use Log::ger;'},
        {code_template=>'use Log::ger; Log::ger->get_logger;'},
        {code_template=>'use Log::ger::App;'},
        {code_template=>'use Log::ger::App; use Log::ger;'},
        {code_template=>'use Log::ger::Plugin::OptAway; use Log::ger;'},
        {code_template=>'use Log::ger::Like::LogAny;'},
        {code_template=>'use Log::ger::Like::Log4perl;'},
        {code_template=>'use Log::ger::App;'},

        {code_template=>'use Log::Any;'},
        {code_template=>'use Log::Any q($log);'},

        {code_template=>'use Log::Contextual qw(:log);'},

        {code_template=>'use Log::Log4perl;'},

        {code_template=>'use Log::Log4perl::Tiny;'},

        {code_template=>'use Log::Dispatch;'},
        {code_template=>'use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Null", min_level=>"warn"] ])', tags=>['output']},

        {code_template=>'use Log::Dispatchouli;'},

        {code_template=>'use Log::ger::Output::Screen;', tags=>['output']},
        {code_template=>'use Log::ger::Output::Composite;', tags=>['output']},

        {code_template=>'use Mojo::Log;'},
        {code_template=>'use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")'},

        {code_template=>'use XLog;'},

        # TODO: Lg + Composite (2 outputs)
        # TODO: Lg + Composite (2 outputs + pattern layouts)
        # TODO: Log::Any + Screen
        # TODO: Log::Log4perl + easy_init
    ],
};

1;
# ABSTRACT: Measure startup overhead of various codes

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::Log::ger::Overhead - Measure startup overhead of various codes

=head1 VERSION

This document describes version 0.021 of Bencher::Scenario::Log::ger::Overhead (from Perl distribution Bencher-ScenarioBundle-Log-ger), released on 2024-07-18.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m Log::ger::Overhead

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Log::Any> 1.717

L<Log::Contextual> 0.008001

L<Log::Dispatch> 2.71

L<Log::Dispatch::Null> 2.71

L<Log::Dispatchouli> 3.007

L<Log::Log4perl> 1.57

L<Log::Log4perl::Tiny> 1.8.0

L<Log::ger> 0.042

L<Log::ger::App> 0.025

L<Log::ger::Layout::Pattern> 0.009

L<Log::ger::Output> 0.042

L<Mojo::Log>

L<XLog> 1.1.3

=head1 BENCHMARK PARTICIPANTS

=over

=item * use strict; (perl_code)

Code template:

 use strict;



=item * use warnings; (perl_code)

Code template:

 use warnings;



=item * use strict; use warnings; (perl_code)

Code template:

 use strict; use warnings;



=item * use Log::ger (); (perl_code)

Code template:

 use Log::ger ();



=item * use Log::ger; (perl_code)

Code template:

 use Log::ger;



=item * use Log::ger; Log::ger->get_logger; (perl_code)

Code template:

 use Log::ger; Log::ger->get_logger;



=item * use Log::ger::App; (perl_code)

Code template:

 use Log::ger::App;



=item * use Log::ger::App; use Log::ger; (perl_code)

Code template:

 use Log::ger::App; use Log::ger;



=item * use Log::ger::Plugin::OptAway; use Log::ger; (perl_code)

Code template:

 use Log::ger::Plugin::OptAway; use Log::ger;



=item * use Log::ger::Like::LogAny; (perl_code)

Code template:

 use Log::ger::Like::LogAny;



=item * use Log::ger::Like::Log4perl; (perl_code)

Code template:

 use Log::ger::Like::Log4perl;



=item * use Log::ger::App; (perl_code)

Code template:

 use Log::ger::App;



=item * use Log::Any; (perl_code)

Code template:

 use Log::Any;



=item * use Log::Any q($log); (perl_code)

Code template:

 use Log::Any q($log);



=item * use Log::Contextual qw(:log); (perl_code)

Code template:

 use Log::Contextual qw(:log);



=item * use Log::Log4perl; (perl_code)

Code template:

 use Log::Log4perl;



=item * use Log::Log4perl::Tiny; (perl_code)

Code template:

 use Log::Log4perl::Tiny;



=item * use Log::Dispatch; (perl_code)

Code template:

 use Log::Dispatch;



=item * use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu (perl_code) [output]

Code template:

 use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Null", min_level=>"warn"] ])



=item * use Log::Dispatchouli; (perl_code)

Code template:

 use Log::Dispatchouli;



=item * use Log::ger::Output::Screen; (perl_code) [output]

Code template:

 use Log::ger::Output::Screen;



=item * use Log::ger::Output::Composite; (perl_code) [output]

Code template:

 use Log::ger::Output::Composite;



=item * use Mojo::Log; (perl_code)

Code template:

 use Mojo::Log;



=item * use Mojo::Log; my $log=Mojo::Log->new(level=>"warn") (perl_code)

Code template:

 use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")



=item * use XLog; (perl_code)

Code template:

 use XLog;



=back

=head1 BENCHMARK SAMPLE RESULTS

=head2 Sample benchmark #1

Run on: perl: I<< v5.38.2 >>, CPU: I<< Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz (2 cores) >>, OS: I<< GNU/Linux Ubuntu version 20.04 >>, OS kernel: I<< Linux version 5.4.0-164-generic >>.

Benchmark command (default options):

 % bencher -m Log::ger::Overhead

Result formatted as table:

 #table1#
 +------------------------------------------------------------------+-----------+---------------------+-----------------------+-----------------------+-----------+---------+
 | participant                                                      | time (ms) | code_overhead_time  | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +------------------------------------------------------------------+-----------+---------------------+-----------------------+-----------------------+-----------+---------+
 | use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")             |    150    | 141                 |                 0.00% |              1787.81% |   0.00081 |      20 |
 | use Mojo::Log;                                                   |    150    | 141                 |                 0.31% |              1782.02% |   0.0011  |      20 |
 | use Log::Contextual qw(:log);                                    |    100    |  91                 |                41.38% |              1235.24% |   0.004   |      20 |
 | use Log::Dispatchouli;                                           |     90    |  81                 |                62.59% |              1061.05% |   0.00023 |      21 |
 | use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu |     88    |  79                 |                67.96% |              1023.98% |   0.00076 |      20 |
 | use Log::Dispatch;                                               |     90    |  81                 |                70.49% |              1007.31% |   0.00087 |      21 |
 | use Log::Log4perl;                                               |     37    |  28                 |               298.40% |               373.85% | 3.9e-05   |      20 |
 | use Log::ger::App; use Log::ger;                                 |     35    |  26                 |               315.44% |               354.41% | 9.7e-05   |      23 |
 | use Log::ger::Like::Log4perl;                                    |     30    |  21                 |               425.74% |               259.08% |   0.0012  |      20 |
 | use Log::ger::App;                                               |     25    |  16                 |               477.88% |               226.68% | 4.2e-05   |      20 |
 | use XLog;                                                        |     25    |  16                 |               482.15% |               224.28% | 4.3e-05   |      20 |
 | use Log::Any q($log);                                            |     20    |  11                 |               554.98% |               188.22% |   0.0011  |      22 |
 | use Log::Log4perl::Tiny;                                         |     20.1  |  11.1               |               633.47% |               157.38% |   2e-05   |      20 |
 | use Log::Any;                                                    |     20    |  11                 |               691.15% |               138.62% |   0.00054 |      20 |
 | use Log::ger::Like::LogAny;                                      |     10    |   1                 |               974.99% |                75.61% |   0.00039 |      22 |
 | use Log::ger::Output::Composite;                                 |     13.4  |   4.4               |               994.16% |                72.53% | 1.2e-05   |      20 |
 | use Log::ger::Output::Screen;                                    |     13    |   4                 |              1039.18% |                65.72% | 1.4e-05   |      20 |
 | use Log::ger::Plugin::OptAway; use Log::ger;                     |     10.3  |   1.3               |              1325.32% |                32.45% | 8.8e-06   |      20 |
 | use strict; use warnings;                                        |     10    |   1                 |              1365.79% |                28.79% |   0.0001  |      20 |
 | use strict;                                                      |      9    |   0                 |              1498.37% |                18.11% |   0.00012 |      20 |
 | use Log::ger; Log::ger->get_logger;                              |      9.2  |   0.199999999999999 |              1499.76% |                18.01% | 8.9e-05   |      22 |
 | use warnings;                                                    |      9    |   0                 |              1525.46% |                16.14% | 1.4e-05   |      20 |
 | use Log::ger;                                                    |      9    |   0                 |              1560.35% |                13.70% |   0.00018 |      20 |
 | perl -e1 (baseline)                                              |      9    |   0                 |              1604.82% |                10.73% |   0.00017 |      20 |
 | use Log::ger ();                                                 |      7.79 |  -1.21              |              1787.81% |                 0.00% | 7.2e-06   |      20 |
 +------------------------------------------------------------------+-----------+---------------------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                                                                       Rate  use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")  use Mojo::Log;  use Log::Contextual qw(:log);  use Log::Dispatchouli;  use Log::Dispatch;  use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu  use Log::Log4perl;  use Log::ger::App; use Log::ger;  use Log::ger::Like::Log4perl;  use Log::ger::App;  use XLog;  use Log::Log4perl::Tiny;  use Log::Any q($log);  use Log::Any;  use Log::ger::Output::Composite;  use Log::ger::Output::Screen;  use Log::ger::Plugin::OptAway; use Log::ger;  use Log::ger::Like::LogAny;  use strict; use warnings;  use Log::ger; Log::ger->get_logger;  use strict;  use warnings;  use Log::ger;  perl -e1 (baseline)  use Log::ger (); 
  use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")                6.7/s                                                    --              0%                           -33%                    -40%                -40%                                                              -41%                -75%                              -76%                           -80%                -83%       -83%                      -86%                   -86%           -86%                              -91%                           -91%                                          -93%                         -93%                       -93%                                 -93%         -94%           -94%           -94%                 -94%              -94% 
  use Mojo::Log;                                                      6.7/s                                                    0%              --                           -33%                    -40%                -40%                                                              -41%                -75%                              -76%                           -80%                -83%       -83%                      -86%                   -86%           -86%                              -91%                           -91%                                          -93%                         -93%                       -93%                                 -93%         -94%           -94%           -94%                 -94%              -94% 
  use Log::Contextual qw(:log);                                      10.0/s                                                   50%             50%                             --                     -9%                 -9%                                                              -12%                -63%                              -65%                           -70%                -75%       -75%                      -79%                   -80%           -80%                              -86%                           -87%                                          -89%                         -90%                       -90%                                 -90%         -91%           -91%           -91%                 -91%              -92% 
  use Log::Dispatchouli;                                             11.1/s                                                   66%             66%                            11%                      --                  0%                                                               -2%                -58%                              -61%                           -66%                -72%       -72%                      -77%                   -77%           -77%                              -85%                           -85%                                          -88%                         -88%                       -88%                                 -89%         -90%           -90%           -90%                 -90%              -91% 
  use Log::Dispatch;                                                 11.1/s                                                   66%             66%                            11%                      0%                  --                                                               -2%                -58%                              -61%                           -66%                -72%       -72%                      -77%                   -77%           -77%                              -85%                           -85%                                          -88%                         -88%                       -88%                                 -89%         -90%           -90%           -90%                 -90%              -91% 
  use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu   11.4/s                                                   70%             70%                            13%                      2%                  2%                                                                --                -57%                              -60%                           -65%                -71%       -71%                      -77%                   -77%           -77%                              -84%                           -85%                                          -88%                         -88%                       -88%                                 -89%         -89%           -89%           -89%                 -89%              -91% 
  use Log::Log4perl;                                                 27.0/s                                                  305%            305%                           170%                    143%                143%                                                              137%                  --                               -5%                           -18%                -32%       -32%                      -45%                   -45%           -45%                              -63%                           -64%                                          -72%                         -72%                       -72%                                 -75%         -75%           -75%           -75%                 -75%              -78% 
  use Log::ger::App; use Log::ger;                                   28.6/s                                                  328%            328%                           185%                    157%                157%                                                              151%                  5%                                --                           -14%                -28%       -28%                      -42%                   -42%           -42%                              -61%                           -62%                                          -70%                         -71%                       -71%                                 -73%         -74%           -74%           -74%                 -74%              -77% 
  use Log::ger::Like::Log4perl;                                      33.3/s                                                  400%            400%                           233%                    200%                200%                                                              193%                 23%                               16%                             --                -16%       -16%                      -32%                   -33%           -33%                              -55%                           -56%                                          -65%                         -66%                       -66%                                 -69%         -70%           -70%           -70%                 -70%              -74% 
  use Log::ger::App;                                                 40.0/s                                                  500%            500%                           300%                    260%                260%                                                              252%                 48%                               39%                            19%                  --         0%                      -19%                   -19%           -19%                              -46%                           -48%                                          -58%                         -60%                       -60%                                 -63%         -64%           -64%           -64%                 -64%              -68% 
  use XLog;                                                          40.0/s                                                  500%            500%                           300%                    260%                260%                                                              252%                 48%                               39%                            19%                  0%         --                      -19%                   -19%           -19%                              -46%                           -48%                                          -58%                         -60%                       -60%                                 -63%         -64%           -64%           -64%                 -64%              -68% 
  use Log::Log4perl::Tiny;                                           49.8/s                                                  646%            646%                           397%                    347%                347%                                                              337%                 84%                               74%                            49%                 24%        24%                        --                     0%             0%                              -33%                           -35%                                          -48%                         -50%                       -50%                                 -54%         -55%           -55%           -55%                 -55%              -61% 
  use Log::Any q($log);                                              50.0/s                                                  650%            650%                           400%                    350%                350%                                                              340%                 85%                               75%                            50%                 25%        25%                        0%                     --             0%                              -32%                           -35%                                          -48%                         -50%                       -50%                                 -54%         -55%           -55%           -55%                 -55%              -61% 
  use Log::Any;                                                      50.0/s                                                  650%            650%                           400%                    350%                350%                                                              340%                 85%                               75%                            50%                 25%        25%                        0%                     0%             --                              -32%                           -35%                                          -48%                         -50%                       -50%                                 -54%         -55%           -55%           -55%                 -55%              -61% 
  use Log::ger::Output::Composite;                                   74.6/s                                                 1019%           1019%                           646%                    571%                571%                                                              556%                176%                              161%                           123%                 86%        86%                       50%                    49%            49%                                --                            -2%                                          -23%                         -25%                       -25%                                 -31%         -32%           -32%           -32%                 -32%              -41% 
  use Log::ger::Output::Screen;                                      76.9/s                                                 1053%           1053%                           669%                    592%                592%                                                              576%                184%                              169%                           130%                 92%        92%                       54%                    53%            53%                                3%                             --                                          -20%                         -23%                       -23%                                 -29%         -30%           -30%           -30%                 -30%              -40% 
  use Log::ger::Plugin::OptAway; use Log::ger;                       97.1/s                                                 1356%           1356%                           870%                    773%                773%                                                              754%                259%                              239%                           191%                142%       142%                       95%                    94%            94%                               30%                            26%                                            --                          -2%                        -2%                                 -10%         -12%           -12%           -12%                 -12%              -24% 
  use Log::ger::Like::LogAny;                                       100.0/s                                                 1400%           1400%                           900%                    800%                800%                                                              780%                270%                              250%                           200%                150%       150%                      101%                   100%           100%                               34%                            30%                                            3%                           --                         0%                                  -8%          -9%            -9%            -9%                  -9%              -22% 
  use strict; use warnings;                                         100.0/s                                                 1400%           1400%                           900%                    800%                800%                                                              780%                270%                              250%                           200%                150%       150%                      101%                   100%           100%                               34%                            30%                                            3%                           0%                         --                                  -8%          -9%            -9%            -9%                  -9%              -22% 
  use Log::ger; Log::ger->get_logger;                               108.7/s                                                 1530%           1530%                           986%                    878%                878%                                                              856%                302%                              280%                           226%                171%       171%                      118%                   117%           117%                               45%                            41%                                           11%                           8%                         8%                                   --          -2%            -2%            -2%                  -2%              -15% 
  use strict;                                                       111.1/s                                                 1566%           1566%                          1011%                    900%                900%                                                              877%                311%                              288%                           233%                177%       177%                      123%                   122%           122%                               48%                            44%                                           14%                          11%                        11%                                   2%           --             0%             0%                   0%              -13% 
  use warnings;                                                     111.1/s                                                 1566%           1566%                          1011%                    900%                900%                                                              877%                311%                              288%                           233%                177%       177%                      123%                   122%           122%                               48%                            44%                                           14%                          11%                        11%                                   2%           0%             --             0%                   0%              -13% 
  use Log::ger;                                                     111.1/s                                                 1566%           1566%                          1011%                    900%                900%                                                              877%                311%                              288%                           233%                177%       177%                      123%                   122%           122%                               48%                            44%                                           14%                          11%                        11%                                   2%           0%             0%             --                   0%              -13% 
  perl -e1 (baseline)                                               111.1/s                                                 1566%           1566%                          1011%                    900%                900%                                                              877%                311%                              288%                           233%                177%       177%                      123%                   122%           122%                               48%                            44%                                           14%                          11%                        11%                                   2%           0%             0%             0%                   --              -13% 
  use Log::ger ();                                                  128.4/s                                                 1825%           1825%                          1183%                   1055%               1055%                                                             1029%                374%                              349%                           285%                220%       220%                      158%                   156%           156%                               72%                            66%                                           32%                          28%                        28%                                  18%          15%            15%            15%                  15%                -- 
 
 Legends:
   perl -e1 (baseline): code_overhead_time=0 participant=perl -e1 (baseline)
   use Log::Any q($log);: code_overhead_time=11 participant=use Log::Any q($log);
   use Log::Any;: code_overhead_time=11 participant=use Log::Any;
   use Log::Contextual qw(:log);: code_overhead_time=91 participant=use Log::Contextual qw(:log);
   use Log::Dispatch;: code_overhead_time=81 participant=use Log::Dispatch;
   use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu: code_overhead_time=79 participant=use Log::Dispatch; my $null = Log::Dispatch->new(outputs=>[ ["Nu
   use Log::Dispatchouli;: code_overhead_time=81 participant=use Log::Dispatchouli;
   use Log::Log4perl::Tiny;: code_overhead_time=11.1 participant=use Log::Log4perl::Tiny;
   use Log::Log4perl;: code_overhead_time=28 participant=use Log::Log4perl;
   use Log::ger ();: code_overhead_time=-1.21 participant=use Log::ger ();
   use Log::ger::App;: code_overhead_time=16 participant=use Log::ger::App;
   use Log::ger::App; use Log::ger;: code_overhead_time=26 participant=use Log::ger::App; use Log::ger;
   use Log::ger::Like::Log4perl;: code_overhead_time=21 participant=use Log::ger::Like::Log4perl;
   use Log::ger::Like::LogAny;: code_overhead_time=1 participant=use Log::ger::Like::LogAny;
   use Log::ger::Output::Composite;: code_overhead_time=4.4 participant=use Log::ger::Output::Composite;
   use Log::ger::Output::Screen;: code_overhead_time=4 participant=use Log::ger::Output::Screen;
   use Log::ger::Plugin::OptAway; use Log::ger;: code_overhead_time=1.3 participant=use Log::ger::Plugin::OptAway; use Log::ger;
   use Log::ger;: code_overhead_time=0 participant=use Log::ger;
   use Log::ger; Log::ger->get_logger;: code_overhead_time=0.199999999999999 participant=use Log::ger; Log::ger->get_logger;
   use Mojo::Log;: code_overhead_time=141 participant=use Mojo::Log;
   use Mojo::Log; my $log=Mojo::Log->new(level=>"warn"): code_overhead_time=141 participant=use Mojo::Log; my $log=Mojo::Log->new(level=>"warn")
   use XLog;: code_overhead_time=16 participant=use XLog;
   use strict;: code_overhead_time=0 participant=use strict;
   use strict; use warnings;: code_overhead_time=1 participant=use strict; use warnings;
   use warnings;: code_overhead_time=0 participant=use warnings;

To display as an interactive HTML table on a browser, you can add option C<--format html+datatables>.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-ScenarioBundle-Log-ger>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-ScenarioBundle-Log-ger>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024, 2023, 2021, 2020, 2018, 2017 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-ScenarioBundle-Log-ger>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
