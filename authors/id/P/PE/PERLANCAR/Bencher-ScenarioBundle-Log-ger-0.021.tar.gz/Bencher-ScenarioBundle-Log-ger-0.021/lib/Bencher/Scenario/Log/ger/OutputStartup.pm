package Bencher::Scenario::Log::ger::OutputStartup;

use 5.010001;
use strict;
use warnings;

use Data::Dmp;
use File::Temp qw(tempdir tempfile);

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2024-07-18'; # DATE
our $DIST = 'Bencher-ScenarioBundle-Log-ger'; # DIST
our $VERSION = '0.021'; # VERSION

my $str;
my $ary = [];
my ($fh, $fname) = tempfile();
my $dname = tempdir(CLEANUP => 1);

our %output_modules = (
    Null => {},
    String => { string => \$str },
    Array => { array => $ary },

    ArrayRotate => { array => $ary },
    File => { path => $fname },
    Screen => {},
    Callback => {},
    FileWriteRotate => { dir => $dname, prefix => 'prefix' },
    DirWriteRotate => { path => $dname },
    LogAny => {},
    #LogDispatchOutput => { output => 'ArrayWithLimits', args => {array => $ary} }, # Log::Dispatch::ArrayWithLimits already removed from CPAN
    Composite => { outputs => {Screen => {conf=>{}}, File => {conf=>{path=>$fname}}} },
    Syslog => { ident => 'test' },
);

our $scenario = {
    modules => {
        'Log::ger::Output::Composite' => {version=>'0.016'},
        'Log::ger::Output::File' => {version=>'0.002'},
        'Log::ger::Output::LogAny' => {version=>'0.003'},
        'Log::ger::Output::Screen' => {version=>'0.018'},
    },
    participants => [
        {name=>"baseline", perl_cmdline => ["-e1"]},

        map {
            (
                +{
                    name => "load-$_",
                    module => "Log::ger::Output::$_",
                    perl_cmdline => ["-mLog::ger::Output::$_", "-e1"],
                },
                +{
                    name => "init-with-$_",
                    module => "Log::ger::Output::$_",
                    #perl_cmdline => ["-e", "use Log::ger::Output '$_'; use Log::ger"],
                    perl_cmdline => ["-e", "use Log::ger::Output '$_' => %{ +".dmp($output_modules{$_})." }; use Log::ger"],
                },
            )
        } sort keys %output_modules,
    ],
};

1;
# ABSTRACT:

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::Log::ger::OutputStartup

=head1 VERSION

This document describes version 0.021 of Bencher::Scenario::Log::ger::OutputStartup (from Perl distribution Bencher-ScenarioBundle-Log-ger), released on 2024-07-18.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m Log::ger::OutputStartup

To run module startup overhead benchmark:

 % bencher --module-startup -m Log::ger::OutputStartup

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Log::ger::Output::Array> 0.042

L<Log::ger::Output::ArrayRotate> 0.004

L<Log::ger::Output::Callback> 0.009

L<Log::ger::Output::Composite> 0.018

L<Log::ger::Output::DirWriteRotate> 0.004

L<Log::ger::Output::File> 0.012

L<Log::ger::Output::FileWriteRotate> 0.005

L<Log::ger::Output::LogAny> 0.009

L<Log::ger::Output::Null> 0.042

L<Log::ger::Output::Screen> 0.019

L<Log::ger::Output::String> 0.042

L<Log::ger::Output::Syslog> 0.005

=head1 BENCHMARK PARTICIPANTS

=over

=item * baseline (command)



=item * load-Array (command)

L<Log::ger::Output::Array>



=item * init-with-Array (command)

L<Log::ger::Output::Array>



=item * load-ArrayRotate (command)

L<Log::ger::Output::ArrayRotate>



=item * init-with-ArrayRotate (command)

L<Log::ger::Output::ArrayRotate>



=item * load-Callback (command)

L<Log::ger::Output::Callback>



=item * init-with-Callback (command)

L<Log::ger::Output::Callback>



=item * load-Composite (command)

L<Log::ger::Output::Composite>



=item * init-with-Composite (command)

L<Log::ger::Output::Composite>



=item * load-DirWriteRotate (command)

L<Log::ger::Output::DirWriteRotate>



=item * init-with-DirWriteRotate (command)

L<Log::ger::Output::DirWriteRotate>



=item * load-File (command)

L<Log::ger::Output::File>



=item * init-with-File (command)

L<Log::ger::Output::File>



=item * load-FileWriteRotate (command)

L<Log::ger::Output::FileWriteRotate>



=item * init-with-FileWriteRotate (command)

L<Log::ger::Output::FileWriteRotate>



=item * load-LogAny (command)

L<Log::ger::Output::LogAny>



=item * init-with-LogAny (command)

L<Log::ger::Output::LogAny>



=item * load-Null (command)

L<Log::ger::Output::Null>



=item * init-with-Null (command)

L<Log::ger::Output::Null>



=item * load-Screen (command)

L<Log::ger::Output::Screen>



=item * init-with-Screen (command)

L<Log::ger::Output::Screen>



=item * load-String (command)

L<Log::ger::Output::String>



=item * init-with-String (command)

L<Log::ger::Output::String>



=item * load-Syslog (command)

L<Log::ger::Output::Syslog>



=item * init-with-Syslog (command)

L<Log::ger::Output::Syslog>



=back

=head1 BENCHMARK SAMPLE RESULTS

=head2 Sample benchmark #1

Run on: perl: I<< v5.38.2 >>, CPU: I<< Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz (2 cores) >>, OS: I<< GNU/Linux Ubuntu version 20.04 >>, OS kernel: I<< Linux version 5.4.0-164-generic >>.

Benchmark command (default options):

 % bencher -m Log::ger::OutputStartup

Result formatted as table:

 #table1#
 +---------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | participant               | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +---------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | init-with-FileWriteRotate |        21 |      48   |                 0.00% |               551.03% |   0.00026 |      22 |
 | init-with-Syslog          |        31 |      32   |                48.27% |               339.08% | 6.3e-05   |      20 |
 | init-with-Composite       |        36 |      28   |                71.30% |               280.05% | 7.2e-05   |      21 |
 | init-with-File            |        40 |      30   |                85.21% |               251.51% |   0.00031 |      23 |
 | init-with-DirWriteRotate  |        50 |      20   |               115.52% |               202.07% |   0.0005  |      20 |
 | init-with-LogAny          |        49 |      20   |               134.32% |               177.84% | 2.6e-05   |      20 |
 | init-with-Null            |        50 |      20   |               139.20% |               172.17% |   0.00046 |      20 |
 | load-File                 |        52 |      19   |               150.08% |               160.33% | 3.9e-05   |      20 |
 | init-with-Screen          |        50 |      20   |               153.18% |               157.14% |   0.00049 |      21 |
 | init-with-Array           |        66 |      15   |               216.38% |               105.77% | 8.6e-05   |      20 |
 | init-with-Callback        |        69 |      15   |               227.50% |                98.79% | 3.5e-05   |      20 |
 | init-with-String          |        69 |      14   |               229.17% |                97.78% | 2.4e-05   |      20 |
 | init-with-ArrayRotate     |        69 |      14   |               229.77% |                97.42% | 2.7e-05   |      21 |
 | load-Composite            |        73 |      14   |               249.93% |                86.05% | 1.9e-05   |      20 |
 | load-FileWriteRotate      |        70 |      10   |               253.51% |                84.16% |   0.00042 |      20 |
 | load-String               |        70 |      10   |               254.43% |                83.69% |   0.00033 |      20 |
 | load-LogAny               |        80 |      10   |               264.29% |                78.71% |   0.00024 |      20 |
 | load-Screen               |        77 |      13   |               268.45% |                76.69% | 2.3e-05   |      20 |
 | load-Syslog               |        78 |      13   |               273.60% |                74.26% | 2.3e-05   |      20 |
 | load-Array                |       100 |      10   |               374.89% |                37.09% | 3.4e-05   |      22 |
 | load-Callback             |       100 |       9.7 |               391.78% |                32.38% | 2.1e-05   |      20 |
 | load-DirWriteRotate       |       100 |       9.6 |               396.70% |                31.07% | 1.4e-05   |      20 |
 | load-ArrayRotate          |       100 |       9.6 |               398.61% |                30.57% | 1.2e-05   |      20 |
 | load-Null                 |       100 |       8   |               478.05% |                12.63% |   0.00014 |      20 |
 | baseline                  |       140 |       7.3 |               551.03% |                 0.00% | 3.1e-05   |      20 |
 +---------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                              Rate  init-with-FileWriteRotate  init-with-Syslog  init-with-File  init-with-Composite  init-with-DirWriteRotate  init-with-LogAny  init-with-Null  init-with-Screen  load-File  init-with-Array  init-with-Callback  init-with-String  init-with-ArrayRotate  load-Composite  load-Screen  load-Syslog  load-FileWriteRotate  load-String  load-LogAny  load-Array  load-Callback  load-DirWriteRotate  load-ArrayRotate  load-Null  baseline 
  init-with-FileWriteRotate   21/s                         --              -33%            -37%                 -41%                      -58%              -58%            -58%              -58%       -60%             -68%                -68%              -70%                   -70%            -70%         -72%         -72%                  -79%         -79%         -79%        -79%           -79%                 -80%              -80%       -83%      -84% 
  init-with-Syslog            31/s                        50%                --             -6%                 -12%                      -37%              -37%            -37%              -37%       -40%             -53%                -53%              -56%                   -56%            -56%         -59%         -59%                  -68%         -68%         -68%        -68%           -69%                 -70%              -70%       -75%      -77% 
  init-with-File              40/s                        60%                6%              --                  -6%                      -33%              -33%            -33%              -33%       -36%             -50%                -50%              -53%                   -53%            -53%         -56%         -56%                  -66%         -66%         -66%        -66%           -67%                 -68%              -68%       -73%      -75% 
  init-with-Composite         36/s                        71%               14%              7%                   --                      -28%              -28%            -28%              -28%       -32%             -46%                -46%              -50%                   -50%            -50%         -53%         -53%                  -64%         -64%         -64%        -64%           -65%                 -65%              -65%       -71%      -73% 
  init-with-DirWriteRotate    50/s                       140%               60%             50%                  39%                        --                0%              0%                0%        -5%             -25%                -25%              -30%                   -30%            -30%         -35%         -35%                  -50%         -50%         -50%        -50%           -51%                 -52%              -52%       -60%      -63% 
  init-with-LogAny            49/s                       140%               60%             50%                  39%                        0%                --              0%                0%        -5%             -25%                -25%              -30%                   -30%            -30%         -35%         -35%                  -50%         -50%         -50%        -50%           -51%                 -52%              -52%       -60%      -63% 
  init-with-Null              50/s                       140%               60%             50%                  39%                        0%                0%              --                0%        -5%             -25%                -25%              -30%                   -30%            -30%         -35%         -35%                  -50%         -50%         -50%        -50%           -51%                 -52%              -52%       -60%      -63% 
  init-with-Screen            50/s                       140%               60%             50%                  39%                        0%                0%              0%                --        -5%             -25%                -25%              -30%                   -30%            -30%         -35%         -35%                  -50%         -50%         -50%        -50%           -51%                 -52%              -52%       -60%      -63% 
  load-File                   52/s                       152%               68%             57%                  47%                        5%                5%              5%                5%         --             -21%                -21%              -26%                   -26%            -26%         -31%         -31%                  -47%         -47%         -47%        -47%           -48%                 -49%              -49%       -57%      -61% 
  init-with-Array             66/s                       220%              113%            100%                  86%                       33%               33%             33%               33%        26%               --                  0%               -6%                    -6%             -6%         -13%         -13%                  -33%         -33%         -33%        -33%           -35%                 -36%              -36%       -46%      -51% 
  init-with-Callback          69/s                       220%              113%            100%                  86%                       33%               33%             33%               33%        26%               0%                  --               -6%                    -6%             -6%         -13%         -13%                  -33%         -33%         -33%        -33%           -35%                 -36%              -36%       -46%      -51% 
  init-with-String            69/s                       242%              128%            114%                 100%                       42%               42%             42%               42%        35%               7%                  7%                --                     0%              0%          -7%          -7%                  -28%         -28%         -28%        -28%           -30%                 -31%              -31%       -42%      -47% 
  init-with-ArrayRotate       69/s                       242%              128%            114%                 100%                       42%               42%             42%               42%        35%               7%                  7%                0%                     --              0%          -7%          -7%                  -28%         -28%         -28%        -28%           -30%                 -31%              -31%       -42%      -47% 
  load-Composite              73/s                       242%              128%            114%                 100%                       42%               42%             42%               42%        35%               7%                  7%                0%                     0%              --          -7%          -7%                  -28%         -28%         -28%        -28%           -30%                 -31%              -31%       -42%      -47% 
  load-Screen                 77/s                       269%              146%            130%                 115%                       53%               53%             53%               53%        46%              15%                 15%                7%                     7%              7%           --           0%                  -23%         -23%         -23%        -23%           -25%                 -26%              -26%       -38%      -43% 
  load-Syslog                 78/s                       269%              146%            130%                 115%                       53%               53%             53%               53%        46%              15%                 15%                7%                     7%              7%           0%           --                  -23%         -23%         -23%        -23%           -25%                 -26%              -26%       -38%      -43% 
  load-FileWriteRotate        70/s                       380%              220%            200%                 179%                      100%              100%            100%              100%        89%              50%                 50%               39%                    39%             39%          30%          30%                    --           0%           0%          0%            -3%                  -4%               -4%       -19%      -27% 
  load-String                 70/s                       380%              220%            200%                 179%                      100%              100%            100%              100%        89%              50%                 50%               39%                    39%             39%          30%          30%                    0%           --           0%          0%            -3%                  -4%               -4%       -19%      -27% 
  load-LogAny                 80/s                       380%              220%            200%                 179%                      100%              100%            100%              100%        89%              50%                 50%               39%                    39%             39%          30%          30%                    0%           0%           --          0%            -3%                  -4%               -4%       -19%      -27% 
  load-Array                 100/s                       380%              220%            200%                 179%                      100%              100%            100%              100%        89%              50%                 50%               39%                    39%             39%          30%          30%                    0%           0%           0%          --            -3%                  -4%               -4%       -19%      -27% 
  load-Callback              100/s                       394%              229%            209%                 188%                      106%              106%            106%              106%        95%              54%                 54%               44%                    44%             44%          34%          34%                    3%           3%           3%          3%             --                  -1%               -1%       -17%      -24% 
  load-DirWriteRotate        100/s                       400%              233%            212%                 191%                      108%              108%            108%              108%        97%              56%                 56%               45%                    45%             45%          35%          35%                    4%           4%           4%          4%             1%                   --                0%       -16%      -23% 
  load-ArrayRotate           100/s                       400%              233%            212%                 191%                      108%              108%            108%              108%        97%              56%                 56%               45%                    45%             45%          35%          35%                    4%           4%           4%          4%             1%                   0%                --       -16%      -23% 
  load-Null                  100/s                       500%              300%            275%                 250%                      150%              150%            150%              150%       137%              87%                 87%               75%                    75%             75%          62%          62%                   25%          25%          25%         25%            21%                  19%               19%         --       -8% 
  baseline                   140/s                       557%              338%            310%                 283%                      173%              173%            173%              173%       160%             105%                105%               91%                    91%             91%          78%          78%                   36%          36%          36%         36%            32%                  31%               31%         9%        -- 
 
 Legends:
   baseline: participant=baseline
   init-with-Array: participant=init-with-Array
   init-with-ArrayRotate: participant=init-with-ArrayRotate
   init-with-Callback: participant=init-with-Callback
   init-with-Composite: participant=init-with-Composite
   init-with-DirWriteRotate: participant=init-with-DirWriteRotate
   init-with-File: participant=init-with-File
   init-with-FileWriteRotate: participant=init-with-FileWriteRotate
   init-with-LogAny: participant=init-with-LogAny
   init-with-Null: participant=init-with-Null
   init-with-Screen: participant=init-with-Screen
   init-with-String: participant=init-with-String
   init-with-Syslog: participant=init-with-Syslog
   load-Array: participant=load-Array
   load-ArrayRotate: participant=load-ArrayRotate
   load-Callback: participant=load-Callback
   load-Composite: participant=load-Composite
   load-DirWriteRotate: participant=load-DirWriteRotate
   load-File: participant=load-File
   load-FileWriteRotate: participant=load-FileWriteRotate
   load-LogAny: participant=load-LogAny
   load-Null: participant=load-Null
   load-Screen: participant=load-Screen
   load-String: participant=load-String
   load-Syslog: participant=load-Syslog

=head2 Sample benchmark #2

Benchmark command (benchmarking module startup overhead):

 % bencher -m Log::ger::OutputStartup --module-startup

Result formatted as table:

 #table2#
 +-----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | participant                       | time (ms) | mod_overhead_time | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +-----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | Log::ger::Output::File            |     20    |             12.9  |                 0.00% |               196.31% |   0.0003  |      20 |
 | Log::ger::Output::Composite       |     15    |              7.9  |                37.03% |               116.23% | 9.2e-05   |      20 |
 | Log::ger::Output::Syslog          |     13    |              5.9  |                57.91% |                87.64% | 5.9e-05   |      20 |
 | Log::ger::Output::Screen          |     13    |              5.9  |                62.86% |                81.94% | 2.1e-05   |      21 |
 | Log::ger::Output::ArrayRotate     |     10    |              2.9  |                80.12% |                64.51% |   0.00013 |      20 |
 | Log::ger::Output::FileWriteRotate |     10    |              2.9  |                80.21% |                64.43% |   0.00019 |      20 |
 | Log::ger::Output::DirWriteRotate  |     11    |              3.9  |                91.18% |                54.99% |   0.00011 |      20 |
 | Log::ger::Output::Callback        |     10    |              2.9  |               108.16% |                42.35% |   2e-05   |      20 |
 | Log::ger::Output::LogAny          |      9.9  |              2.8  |               114.44% |                38.18% | 1.4e-05   |      20 |
 | Log::ger::Output::String          |      9.57 |              2.47 |               121.28% |                33.91% | 6.3e-06   |      20 |
 | Log::ger::Output::Array           |      9.5  |              2.4  |               121.87% |                33.55% | 1.7e-05   |      20 |
 | Log::ger::Output::Null            |      7.5  |              0.4  |               184.03% |                 4.32% | 2.1e-05   |      21 |
 | perl -e1 (baseline)               |      7.1  |              0    |               196.31% |                 0.00% |   9e-06   |      20 |
 +-----------------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                                        Rate  Log::ger::Output::File  Log::ger::Output::Composite  Log::ger::Output::Syslog  Log::ger::Output::Screen  Log::ger::Output::DirWriteRotate  Log::ger::Output::ArrayRotate  Log::ger::Output::FileWriteRotate  Log::ger::Output::Callback  Log::ger::Output::LogAny  Log::ger::Output::String  Log::ger::Output::Array  Log::ger::Output::Null  perl -e1 (baseline) 
  Log::ger::Output::File              50.0/s                      --                         -25%                      -35%                      -35%                              -44%                           -50%                               -50%                        -50%                      -50%                      -52%                     -52%                    -62%                 -64% 
  Log::ger::Output::Composite         66.7/s                     33%                           --                      -13%                      -13%                              -26%                           -33%                               -33%                        -33%                      -34%                      -36%                     -36%                    -50%                 -52% 
  Log::ger::Output::Syslog            76.9/s                     53%                          15%                        --                        0%                              -15%                           -23%                               -23%                        -23%                      -23%                      -26%                     -26%                    -42%                 -45% 
  Log::ger::Output::Screen            76.9/s                     53%                          15%                        0%                        --                              -15%                           -23%                               -23%                        -23%                      -23%                      -26%                     -26%                    -42%                 -45% 
  Log::ger::Output::DirWriteRotate    90.9/s                     81%                          36%                       18%                       18%                                --                            -9%                                -9%                         -9%                       -9%                      -13%                     -13%                    -31%                 -35% 
  Log::ger::Output::ArrayRotate      100.0/s                    100%                          50%                       30%                       30%                               10%                             --                                 0%                          0%                       -1%                       -4%                      -5%                    -25%                 -29% 
  Log::ger::Output::FileWriteRotate  100.0/s                    100%                          50%                       30%                       30%                               10%                             0%                                 --                          0%                       -1%                       -4%                      -5%                    -25%                 -29% 
  Log::ger::Output::Callback         100.0/s                    100%                          50%                       30%                       30%                               10%                             0%                                 0%                          --                       -1%                       -4%                      -5%                    -25%                 -29% 
  Log::ger::Output::LogAny           101.0/s                    102%                          51%                       31%                       31%                               11%                             1%                                 1%                          1%                        --                       -3%                      -4%                    -24%                 -28% 
  Log::ger::Output::String           104.5/s                    108%                          56%                       35%                       35%                               14%                             4%                                 4%                          4%                        3%                        --                       0%                    -21%                 -25% 
  Log::ger::Output::Array            105.3/s                    110%                          57%                       36%                       36%                               15%                             5%                                 5%                          5%                        4%                        0%                       --                    -21%                 -25% 
  Log::ger::Output::Null             133.3/s                    166%                         100%                       73%                       73%                               46%                            33%                                33%                         33%                       32%                       27%                      26%                      --                  -5% 
  perl -e1 (baseline)                140.8/s                    181%                         111%                       83%                       83%                               54%                            40%                                40%                         40%                       39%                       34%                      33%                      5%                   -- 
 
 Legends:
   Log::ger::Output::Array: mod_overhead_time=2.4 participant=Log::ger::Output::Array
   Log::ger::Output::ArrayRotate: mod_overhead_time=2.9 participant=Log::ger::Output::ArrayRotate
   Log::ger::Output::Callback: mod_overhead_time=2.9 participant=Log::ger::Output::Callback
   Log::ger::Output::Composite: mod_overhead_time=7.9 participant=Log::ger::Output::Composite
   Log::ger::Output::DirWriteRotate: mod_overhead_time=3.9 participant=Log::ger::Output::DirWriteRotate
   Log::ger::Output::File: mod_overhead_time=12.9 participant=Log::ger::Output::File
   Log::ger::Output::FileWriteRotate: mod_overhead_time=2.9 participant=Log::ger::Output::FileWriteRotate
   Log::ger::Output::LogAny: mod_overhead_time=2.8 participant=Log::ger::Output::LogAny
   Log::ger::Output::Null: mod_overhead_time=0.4 participant=Log::ger::Output::Null
   Log::ger::Output::Screen: mod_overhead_time=5.9 participant=Log::ger::Output::Screen
   Log::ger::Output::String: mod_overhead_time=2.47 participant=Log::ger::Output::String
   Log::ger::Output::Syslog: mod_overhead_time=5.9 participant=Log::ger::Output::Syslog
   perl -e1 (baseline): mod_overhead_time=0 participant=perl -e1 (baseline)

To display as an interactive HTML table on a browser, you can add option C<--format html+datatables>.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-ScenarioBundle-Log-ger>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-ScenarioBundle-Log-ger>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024, 2023, 2021, 2020, 2018, 2017 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-ScenarioBundle-Log-ger>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
