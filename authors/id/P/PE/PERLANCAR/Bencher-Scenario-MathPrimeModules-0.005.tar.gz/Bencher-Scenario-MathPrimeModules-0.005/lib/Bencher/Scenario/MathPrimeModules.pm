package Bencher::Scenario::MathPrimeModules;

use 5.010001;
use strict;
use warnings;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2025-01-06'; # DATE
our $DIST = 'Bencher-Scenario-MathPrimeModules'; # DIST
our $VERSION = '0.005'; # VERSION

our $scenario = {
    summary => 'Benchmark modules that find prime numbers',
    modules => {
    },
    participants => [
        {
            module => 'Acme::Math::Prime::Regexp',
            code_template => 'Acme::Math::Prime::Regexp::_empty_cache(); Acme::Math::Prime::Regexp::primes(<num>)',
            result_is_list => 1,
            tags => ['slow'],
        },

        {
            module => 'Acme::PERLANCAR::Prime',
            code_template => 'Acme::PERLANCAR::Prime::_empty_cache(); Acme::PERLANCAR::Prime::primes(<num>)',
            result_is_list => 1,
        },

        {
            fcall_template => 'Math::Prime::Util::erat_primes(2,<num>)',
        },

        {
            module => 'Math::Prime::FastSieve',
            function => 'primes',
            code_template => 'Math::Prime::FastSieve->import(); Inline->init(); my $sieve = Math::Prime::FastSieve::Sieve->new(<num>); $sieve->primes(<num>)',
        },

        {
            fcall_template => 'Math::Prime::XS::primes(<num>)',
            result_is_list => 1,
        },
    ],

    precision => 6,

    datasets => [
        # just for testing correctness
        {args=>{num=>100}, result=>[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97]},

        {
            args=>{num=>1000_000},
            exclude_participant_tags => ['slow'],
        },
    ],
};

1;
# ABSTRACT: Benchmark modules that find prime numbers

__END__

=pod

=encoding UTF-8

=head1 NAME

Bencher::Scenario::MathPrimeModules - Benchmark modules that find prime numbers

=head1 VERSION

This document describes version 0.005 of Bencher::Scenario::MathPrimeModules (from Perl distribution Bencher-Scenario-MathPrimeModules), released on 2025-01-06.

=head1 SYNOPSIS

To run benchmark with default option:

 % bencher -m MathPrimeModules

To run module startup overhead benchmark:

 % bencher --module-startup -m MathPrimeModules

For more options (dump scenario, list/include/exclude/add participants, list/include/exclude/add datasets, etc), see L<bencher> or run C<bencher --help>.

=head1 DESCRIPTION

Packaging a benchmark script as a Bencher scenario makes it convenient to include/exclude/add participants/datasets (either via CLI or Perl code), send the result to a central repository, among others . See L<Bencher> and L<bencher> (CLI) for more details.

=head1 BENCHMARKED MODULES

Version numbers shown below are the versions used when running the sample benchmark.

L<Acme::Math::Prime::Regexp> 0.001

L<Acme::PERLANCAR::Prime> 0.001

L<Math::Prime::FastSieve> 0.19

L<Math::Prime::Util> 0.73

L<Math::Prime::XS> 0.27

=head1 BENCHMARK PARTICIPANTS

=over

=item * Acme::Math::Prime::Regexp (perl_code) [slow]

Code template:

 Acme::Math::Prime::Regexp::_empty_cache(); Acme::Math::Prime::Regexp::primes(<num>)



=item * Acme::PERLANCAR::Prime (perl_code)

Code template:

 Acme::PERLANCAR::Prime::_empty_cache(); Acme::PERLANCAR::Prime::primes(<num>)



=item * Math::Prime::Util::erat_primes (perl_code)

Function call template:

 Math::Prime::Util::erat_primes(2,<num>)



=item * Math::Prime::FastSieve::primes (perl_code)

Code template:

 Math::Prime::FastSieve->import(); Inline->init(); my $sieve = Math::Prime::FastSieve::Sieve->new(<num>); $sieve->primes(<num>)



=item * Math::Prime::XS::primes (perl_code)

Function call template:

 Math::Prime::XS::primes(<num>)



=back

=head1 BENCHMARK DATASETS

=over

=item * 100

=item * 1000000

=back

=head1 BENCHMARK SAMPLE RESULTS

=head2 Sample benchmark #1

Run on: perl: I<< v5.40.0 >>, CPU: I<< 12th Gen Intel(R) Core(TM) i7-1250U (10 cores) >>, OS: I<< GNU/Linux Debian version 12 >>, OS kernel: I<< Linux version 6.1.0-26-amd64 >>.

Benchmark command:

 % bencher -m MathPrimeModules --exclude-dataset-names 100

Result formatted as table:

 #table1#
 +--------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | participant                    | rate (/s) | time (ms) | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +--------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+
 | Acme::PERLANCAR::Prime         |       0.8 |    1000   |                 0.00% |             37029.50% |   0.015   |       6 |
 | Math::Prime::XS::primes        |     160   |       6.3 |             18478.53% |                99.85% | 3.6e-05   |       7 |
 | Math::Prime::FastSieve::primes |     220   |       4.5 |             26262.16% |                40.84% | 1.7e-05   |       6 |
 | Math::Prime::Util::erat_primes |     300   |       3   |             37029.50% |                 0.00% |   0.00014 |       8 |
 +--------------------------------+-----------+-----------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

            Rate    AP:P  MPX:p  MPF:p  MPU:e_p 
  AP:P     0.8/s      --   -99%   -99%     -99% 
  MPX:p    160/s  15773%     --   -28%     -52% 
  MPF:p    220/s  22122%    39%     --     -33% 
  MPU:e_p  300/s  33233%   110%    50%       -- 
 
 Legends:
   AP:P: participant=Acme::PERLANCAR::Prime
   MPF:p: participant=Math::Prime::FastSieve::primes
   MPU:e_p: participant=Math::Prime::Util::erat_primes
   MPX:p: participant=Math::Prime::XS::primes

=head2 Sample benchmark #2

Benchmark command (benchmarking module startup overhead):

 % bencher -m MathPrimeModules --module-startup

Result formatted as table:

 #table2#
 +---------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | participant               | time (ms) | mod_overhead_time | pct_faster_vs_slowest | pct_slower_vs_fastest |  errors   | samples |
 +---------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+
 | Math::Prime::FastSieve    |        40 |                36 |                 0.00% |               928.64% |   0.00047 |       7 |
 | Math::Prime::Util         |        19 |                15 |               121.10% |               365.24% |   0.00013 |       7 |
 | Math::Prime::XS           |        17 |                13 |               136.30% |               335.30% |   8e-05   |       6 |
 | Acme::PERLANCAR::Prime    |        13 |                 9 |               221.14% |               220.30% |   6e-05   |       6 |
 | Acme::Math::Prime::Regexp |        10 |                 6 |               244.45% |               198.63% |   0.00013 |       6 |
 | perl -e1 (baseline)       |         4 |                 0 |               928.64% |                 0.00% | 1.8e-05   |       6 |
 +---------------------------+-----------+-------------------+-----------------------+-----------------------+-----------+---------+


The above result formatted in L<Benchmark.pm|Benchmark> style:

                          Rate  MP:F  MP:U  MP:X  AP:P  AMP:R  perl -e1 (baseline) 
  MP:F                  25.0/s    --  -52%  -57%  -67%   -75%                 -90% 
  MP:U                  52.6/s  110%    --  -10%  -31%   -47%                 -78% 
  MP:X                  58.8/s  135%   11%    --  -23%   -41%                 -76% 
  AP:P                  76.9/s  207%   46%   30%    --   -23%                 -69% 
  AMP:R                100.0/s  300%   89%   70%   30%     --                 -60% 
  perl -e1 (baseline)  250.0/s  900%  375%  325%  225%   150%                   -- 
 
 Legends:
   AMP:R: mod_overhead_time=6 participant=Acme::Math::Prime::Regexp
   AP:P: mod_overhead_time=9 participant=Acme::PERLANCAR::Prime
   MP:F: mod_overhead_time=36 participant=Math::Prime::FastSieve
   MP:U: mod_overhead_time=15 participant=Math::Prime::Util
   MP:X: mod_overhead_time=13 participant=Math::Prime::XS
   perl -e1 (baseline): mod_overhead_time=0 participant=perl -e1 (baseline)

To display as an interactive HTML table on a browser, you can add option C<--format html+datatables>.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Bencher-Scenario-MathPrimeModules>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Bencher-Scenario-MathPrimeModules>.

=head1 SEE ALSO

L<http://blogs.perl.org/users/dana_jacobsen/2014/08/a-comparison-of-memory-use-for-primality-modules.html>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2025 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Bencher-Scenario-MathPrimeModules>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
