package Sah::SchemaBundle::CPANMeta;

use strict;

1;
# ABSTRACT: Sah schemas for CPAN Meta specification

__END__

=pod

=encoding UTF-8

=head1 NAME

Sah::SchemaBundle::CPANMeta - Sah schemas for CPAN Meta specification

=head1 VERSION

This document describes version 0.004 of Sah::SchemaBundle::CPANMeta (from Perl distribution Sah-SchemaBundle-CPANMeta), released on 2024-06-08.

=head1 SAH SCHEMAS

The following schemas are included in this distribution:

=over

=item * L<cpan::meta20|Sah::Schema::cpan::meta20>

CPAN Meta specification 2.0.

=item * L<cpan::meta20::license|Sah::Schema::cpan::meta20::license>

License.

=item * L<cpan::meta20::no_index|Sah::Schema::cpan::meta20::no_index>

=item * L<cpan::meta20::optional_feature|Sah::Schema::cpan::meta20::optional_feature>

Additional information about an optional feature.

=item * L<cpan::meta20::optional_feature_prereqs|Sah::Schema::cpan::meta20::optional_feature_prereqs>

Prereqs hash for optional feature.

Just like a normal prereqs, except it must not include C<configure> phase.


=item * L<cpan::meta20::prereq|Sah::Schema::cpan::meta20::prereq>

Prereq hash.

=item * L<cpan::meta20::prereqs|Sah::Schema::cpan::meta20::prereqs>

Prereqs hash.

=item * L<cpan::meta20::release_status|Sah::Schema::cpan::meta20::release_status>

Release status.

=item * L<cpan::meta20::resource|Sah::Schema::cpan::meta20::resource>

=item * L<cpan::meta20::version|Sah::Schema::cpan::meta20::version>

Version number.

=item * L<cpan::meta20::version_range|Sah::Schema::cpan::meta20::version_range>

Version number range.

=back

=head1 SYNOPSIS

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Sah-SchemaBundle-CPANMeta>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Sah-SchemaBundle-CPANMeta>.

=head1 SEE ALSO

L<Sah::SchemaBundle::CPAN>

L<CPAN::Meta>, L<CPAN::Meta::Validator>

L<Sah> - schema specification

L<Data::Sah> - Perl implementation of Sah

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTORS

=for stopwords Steven Haryanto

=over 4

=item *

Steven Haryanto <stevenharyanto@gmail.com>

=item *

Steven Haryanto <steven@masterweb.net>

=back

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024, 2017, 2016 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Sah-SchemaBundle-CPANMeta>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
