package Sah::Schema::cpan::meta20;

use 5.010001;
use strict;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2024-06-08'; # DATE
our $DIST = 'Sah-SchemaBundle-CPANMeta'; # DIST
our $VERSION = '0.004'; # VERSION

our $schema = ['hash', {
    summary  => 'CPAN Meta specification 2.0',
    req_keys => [qw/abstract author dynamic_config generated_by license meta-spec name release_status version/],
    re_keys  => {

        # sorted alphabetically

        '^[Xx]_' => ['any'],

        '^abstract$' => ['str', {req=>1}],

        '^author$' => ['array', {
            req     => 1,
            min_len => 1,
            of      => ['str', {
                req => 1,

                match             => '^\S.* <.+@.+>$',
                "match.err_level" => "warn",
                "match.err_msg"   => "preferred format is author-name <email-address>",
            }],
        }],

        '^build_requires$' => ['cpan::meta20::prereq', {
            forbidden             => 1,
            "forbidden.err_level" => "warn",
            "forbidden.err_msg"   => "build_requires is deprecated in spec 2 and has been replaced by prereqs",
        }],

        '^configure_requires$' => ['cpan::meta20::prereq', {
            forbidden             => 1,
            "forbidden.err_level" => "warn",
            "forbidden.err_msg"   => "configure_requires is deprecated in spec 2 and has been replaced by prereqs",
        }],

        '^conflicts$' => ['cpan::meta20::prereq', {
            forbidden             => 1,
            "forbidden.err_level" => "warn",
            "forbidden.err_msg"   => "conflicts is deprecated in spec 2 and has been replaced by prereqs",
        }],

        '^description$' => ['str', {req=>1}],

        '^distribution_type$' => ['str', {
            req    => 1,
            in     => ['module', 'script'],

            forbidden             => 1,
            "forbidden.err_level" => 'warn',
            "forbidden.err_msg"   => 'distribution_type is deprecated in spec 2 since it is meaningless for many distributions which are hybrid or modules and scripts',
        }],

        '^dynamic_config$' => ['bool', {req=>1}],

        '^generated_by$' => ['str', {req=>1}],

        '^keywords$' => ['array', {req=>1, of => ['str', {req=>1, match=>'^\S+$'}]}],

        '^license$' => ['array', {req=>1, of => ['cpan::meta20::license', {req=>1}]}],

        '^license_uri$' => ['str', {
            forbidden             => 1,
            "forbidden.err_level" => 'warn',
            "forbidden.err_msg"   => 'license_uri is deprecated in 1.2 and has been replaced by license in resources',
        }],

        '^meta-spec$' => ['hash', {
            req => 1,
            req_keys => [qw/version/],
            keys => {
              version => ['float', {req=>1, is=>2}],
              url     => ['str', {req=>1}],
          },
        }],

        '^name$' => ['perl::distname', {req=>1}],

        '^no_index$' => ['cpan::meta20::no_index', {req=>1}],

        '^optional_features$' => ['hash', {
            req => 1,
            each_value => ['cpan::meta20::optional_feature', {req=>1}],
        }],

        '^prereqs$' => ['cpan::meta20::prereqs', {req=>1}],

        '^private$' => ['cpan::meta20::no_index', {
            forbidden             => 1,
            "forbidden.err_level" => 'warn',
            "forbidden.err_msg"   => "private is deprecated in spec 1.2 and has been renamed to no_index",
        }],

        '^provides$' => ['hash', {
            req => 1,
            each_key => ['perl::modname', {req=>1}],
            each_value => ['hash', {
                req => 1,
                req_keys => [qw/file version/],
                keys => {
                    file => ['str', {req=>1}],
                    version => ['cpan::meta20::version', {req=>1}],
                },
            }],
        }],

        '^recommends$' => ['cpan::meta20::prereq', {
            forbidden             => 1,
            "forbidden.err_level" => "warn",
            "forbidden.err_msg"   => "recommends is deprecated in spec 2 and has been replaced by prereqs",
        }],

        '^release_status$' => ['cpan::meta20::release_status', {req=>1}],

        '^requires$' => ['cpan::meta20::prereq', {
            forbidden             => 1,
            "forbidden.err_level" => "warn",
            "forbidden.err_msg"   => "requires is deprecated in spec 2 and has been replaced by prereqs",
        }],

        '^resources$' => ['hash', {
            req => 1,
            allowed_keys => [qw/homepage license bugtracker repository/],
            each_value => ['cpan::meta20::resource'],
        }],

        '^version$' => ['cpan::meta20::version', {req=>1}],

    }, # re_keys

    # XXX if version contains underscore, release_status must not be stable
}];

1;
# ABSTRACT: CPAN Meta specification 2.0

__END__

=pod

=encoding UTF-8

=head1 NAME

Sah::Schema::cpan::meta20 - CPAN Meta specification 2.0

=head1 VERSION

This document describes version 0.004 of Sah::Schema::cpan::meta20 (from Perl distribution Sah-SchemaBundle-CPANMeta), released on 2024-06-08.

=head1 SAH SCHEMA DEFINITION

 [
   "hash",
   {
     re_keys  => {
                   "^[Xx]_"                => ["any"],
                   "^abstract\$"           => ["str", { req => 1 }],
                   "^author\$"             => [
                                                "array",
                                                {
                                                  req => 1,
                                                  min_len => 1,
                                                  of => [
                                                    "str",
                                                    {
                                                      "req" => 1,
                                                      "match" => "^\\S.* <.+\@.+>\$",
                                                      "match.err_level" => "warn",
                                                      "match.err_msg" => "preferred format is author-name <email-address>",
                                                    },
                                                  ],
                                                },
                                              ],
                   "^build_requires\$"     => [
                                                "cpan::meta20::prereq",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "build_requires is deprecated in spec 2 and has been replaced by prereqs",
                                                },
                                              ],
                   "^configure_requires\$" => [
                                                "cpan::meta20::prereq",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "configure_requires is deprecated in spec 2 and has been replaced by prereqs",
                                                },
                                              ],
                   "^conflicts\$"          => [
                                                "cpan::meta20::prereq",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "conflicts is deprecated in spec 2 and has been replaced by prereqs",
                                                },
                                              ],
                   "^description\$"        => ["str", { req => 1 }],
                   "^distribution_type\$"  => [
                                                "str",
                                                {
                                                  "req" => 1,
                                                  "forbidden" => 1,
                                                  "in" => ["module", "script"],
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "distribution_type is deprecated in spec 2 since it is meaningless for many distributions which are hybrid or modules and scripts",
                                                },
                                              ],
                   "^dynamic_config\$"     => ["bool", { req => 1 }],
                   "^generated_by\$"       => ["str", { req => 1 }],
                   "^keywords\$"           => [
                                                "array",
                                                { req => 1, of => ["str", { req => 1, match => "^\\S+\$" }] },
                                              ],
                   "^license\$"            => [
                                                "array",
                                                { req => 1, of => ["cpan::meta20::license", { req => 1 }] },
                                              ],
                   "^license_uri\$"        => [
                                                "str",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "license_uri is deprecated in 1.2 and has been replaced by license in resources",
                                                },
                                              ],
                   "^meta-spec\$"          => [
                                                "hash",
                                                {
                                                  req => 1,
                                                  keys => {
                                                    url => ["str", { req => 1 }],
                                                    version => ["float", { req => 1, is => 2 }],
                                                  },
                                                  req_keys => ["version"],
                                                },
                                              ],
                   "^name\$"               => ["perl::distname", { req => 1 }],
                   "^no_index\$"           => ["cpan::meta20::no_index", { req => 1 }],
                   "^optional_features\$"  => [
                                                "hash",
                                                {
                                                  req => 1,
                                                  each_value => ["cpan::meta20::optional_feature", { req => 1 }],
                                                },
                                              ],
                   "^prereqs\$"            => ["cpan::meta20::prereqs", { req => 1 }],
                   "^private\$"            => [
                                                "cpan::meta20::no_index",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "private is deprecated in spec 1.2 and has been renamed to no_index",
                                                },
                                              ],
                   "^provides\$"           => [
                                                "hash",
                                                {
                                                  req => 1,
                                                  each_key => ["perl::modname", { req => 1 }],
                                                  each_value => [
                                                    "hash",
                                                    {
                                                      req => 1,
                                                      keys => {
                                                        file => ["str", { req => 1 }],
                                                        version => ["cpan::meta20::version", { req => 1 }],
                                                      },
                                                      req_keys => ["file", "version"],
                                                    },
                                                  ],
                                                },
                                              ],
                   "^recommends\$"         => [
                                                "cpan::meta20::prereq",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "recommends is deprecated in spec 2 and has been replaced by prereqs",
                                                },
                                              ],
                   "^release_status\$"     => ["cpan::meta20::release_status", { req => 1 }],
                   "^requires\$"           => [
                                                "cpan::meta20::prereq",
                                                {
                                                  "forbidden" => 1,
                                                  "forbidden.err_level" => "warn",
                                                  "forbidden.err_msg" => "requires is deprecated in spec 2 and has been replaced by prereqs",
                                                },
                                              ],
                   "^resources\$"          => [
                                                "hash",
                                                {
                                                  req => 1,
                                                  allowed_keys => ["homepage", "license", "bugtracker", "repository"],
                                                  each_value => ["cpan::meta20::resource"],
                                                },
                                              ],
                   "^version\$"            => ["cpan::meta20::version", { req => 1 }],
                 },
     req_keys => [
                   "abstract",
                   "author",
                   "dynamic_config",
                   "generated_by",
                   "license",
                   "meta-spec",
                   "name",
                   "release_status",
                   "version",
                 ],
   },
 ]

Base type: L<hash|Data::Sah::Type::hash>

=head1 SYNOPSIS

=head2 Using with Data::Sah

To check data against this schema (requires L<Data::Sah>):

 use Data::Sah qw(gen_validator);
 my $validator = gen_validator("cpan::meta20*");
 say $validator->($data) ? "valid" : "INVALID!";

The above validator returns a boolean result (true if data is valid, false if
otherwise). To return an error message string instead (empty string if data is
valid, a non-empty error message otherwise):

 my $validator = gen_validator("cpan::meta20", {return_type=>'str_errmsg'});
 my $errmsg = $validator->($data);

Often a schema has coercion rule or default value rules, so after validation the
validated value will be different from the original. To return the validated
(set-as-default, coerced, prefiltered) value:

 my $validator = gen_validator("cpan::meta20", {return_type=>'str_errmsg+val'});
 my $res = $validator->($data); # [$errmsg, $validated_val]

Data::Sah can also create validator that returns a hash of detailed error
message. Data::Sah can even create validator that targets other language, like
JavaScript, from the same schema. Other things Data::Sah can do: show source
code for validator, generate a validator code with debug comments and/or log
statements, generate human text from schema. See its documentation for more
details.

=head2 Using with Params::Sah

To validate function parameters against this schema (requires L<Params::Sah>):

 use Params::Sah qw(gen_validator);

 sub myfunc {
     my @args = @_;
     state $validator = gen_validator("cpan::meta20*");
     $validator->(\@args);
     ...
 }

=head2 Using with Perinci::CmdLine::Lite

To specify schema in L<Rinci> function metadata and use the metadata with
L<Perinci::CmdLine> (L<Perinci::CmdLine::Lite>) to create a CLI:

 # in lib/MyApp.pm
 package
   MyApp;
 our %SPEC;
 $SPEC{myfunc} = {
     v => 1.1,
     summary => 'Routine to do blah ...',
     args => {
         arg1 => {
             summary => 'The blah blah argument',
             schema => ['cpan::meta20*'],
         },
         ...
     },
 };
 sub myfunc {
     my %args = @_;
     ...
 }
 1;

 # in myapp.pl
 package
   main;
 use Perinci::CmdLine::Any;
 Perinci::CmdLine::Any->new(url=>'/MyApp/myfunc')->run;

 # in command-line
 % ./myapp.pl --help
 myapp - Routine to do blah ...
 ...

 % ./myapp.pl --version

 % ./myapp.pl --arg1 ...

=head2 Using on the CLI with validate-with-sah

To validate some data on the CLI, you can use L<validate-with-sah> utility.
Specify the schema as the first argument (encoded in Perl syntax) and the data
to validate as the second argument (encoded in Perl syntax):

 % validate-with-sah '"cpan::meta20*"' '"data..."'

C<validate-with-sah> has several options for, e.g. validating multiple data,
showing the generated validator code (Perl/JavaScript/etc), or loading
schema/data from file. See its manpage for more details.


=head2 Using with Type::Tiny

To create a type constraint and type library from a schema (requires
L<Type::Tiny> as well as L<Type::FromSah>):

 package My::Types {
     use Type::Library -base;
     use Type::FromSah qw( sah2type );

     __PACKAGE__->add_type(
         sah2type('cpan::meta20*', name=>'CpanMeta20')
     );
 }

 use My::Types qw(CpanMeta20);
 CpanMeta20->assert_valid($data);

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Sah-SchemaBundle-CPANMeta>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Sah-SchemaBundle-CPANMeta>.

=head1 SEE ALSO

L<CPAN::Meta>, L<CPAN::Meta::Validator>

L<validate-cpan-meta-with-sah> from L<App::ValidateCPANMetaWithSah>

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2024, 2017, 2016 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Sah-SchemaBundle-CPANMeta>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
