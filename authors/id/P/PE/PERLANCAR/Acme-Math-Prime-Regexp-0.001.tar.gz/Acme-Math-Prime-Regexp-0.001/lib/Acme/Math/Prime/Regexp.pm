package Acme::Math::Prime::Regexp;

use 5.010001;
use strict;
use warnings;

use Exporter qw(import);

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2025-01-06'; # DATE
our $DIST = 'Acme-Math-Prime-Regexp'; # DIST
our $VERSION = '0.001'; # VERSION

our @EXPORT_OK = qw(primes);

my @primes = (2);

sub _empty_cache {
    @primes = (2);
}

sub is_prime {
    my $num = shift;
    my $str = "1" x $num;
    $str =~ /^1?$|^(11+?)\1+$/ ? 0:1;
}

sub primes {
    my ($base, $num);

    if (@_ > 1) {
        ($base, $num) = @_;
    } else {
        $base = 1;
        $num = $_[0];
    }

    my @res;
    my $i = $base;
    $i = 2 if $i < 2;

    # first, fill with precomputed primes
    my $k = -1;
    for my $j (0..$#primes) {
        my $p = $primes[$j];
        if ($p >= $i && $p <= $num) {
            push @res, $p;
            $i = $p + 1;
            $k = $j;
        }
    }

    while ($i <= $num) {
        if (is_prime($i)) {
            push @primes, $i;
            push @res, $i;
        }
        $i++;
        $i++ if $i % 2 == 0; # quick skip even numbers
    }
    @res;
}

1;
# ABSTRACT: Return prime numbers

__END__

=pod

=encoding UTF-8

=head1 NAME

Acme::Math::Prime::Regexp - Return prime numbers

=head1 VERSION

This document describes version 0.001 of Acme::Math::Prime::Regexp (from Perl distribution Acme-Math-Prime-Regexp), released on 2025-01-06.

=head1 DESCRIPTION

This distribution is created for testing only. It uses Abigail's regexp pattern
to test for primality [1], which obviously will not be competitive with other
proper primality tests.

[1] https://www.masteringperl.org/2013/06/how-abigails-prime-number-checker-works/

=head1 FUNCTIONS

=head2 is_prime

Usage:

 is_prime($num) => bool

Check if a number is a prime.

=head2 primes

Usage:

 primes([ $base, ] $num) => list

Return prime numbers (from C<$base> if specified) that are less than or equal to
C<$num>.

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/Acme-Math-Prime-Regexp>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-Acme-Math-Prime-Regexp>.

=head1 SEE ALSO

Some actual math prime testing modules: L<Math::Prime::Util>,
L<Math::Prime::XS>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2025 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=Acme-Math-Prime-Regexp>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
