package URI::Info::Plugin::SearchQuery::baidu;

use 5.010001;
use strict;
use warnings;

our $AUTHORITY = 'cpan:PERLANCAR'; # AUTHORITY
our $DATE = '2023-06-21'; # DATE
our $DIST = 'URI-Info'; # DIST
our $VERSION = '0.004'; # VERSION

use parent 'URI::Info::PluginBase';

sub meta {
    return {
        summary => 'Extract search query from baidu URL',
        conf => {
        },

        host => [
            'baidu.com',
            'www.baidu.com',

            'image.baidu.com',
            'tieba.baidu.com',
            'wenku.baidu.com',
            'zhidao.baidu.com',
        ],

        examples => [
        ],
    };
}

sub get_info {
    my ($self, $stash) = @_;
    my $url = $stash->{url};
    my $res = $stash->{res};

    my $host = $url->host;
    my $fpath = $url->full_path;

    if ($host eq 'b2b.baidu.com' && $fpath =~ m!\A/s\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'shopping';
        $res->{search_query} = $url->query_param('q');
    } elsif ($host eq 'image.baidu.com' && $fpath =~ m!\A/(search/index|i)\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'image';
        $res->{search_query} = $url->query_param('word');
    } elsif ($host eq 'map.baidu.com' && $fpath =~ m!\A/search/!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'map';
        ($res->{search_query}) = $url->path =~ m!\A/search/([^/]+)/!;
    } elsif ($host eq 'tieba.baidu.com' && $fpath =~ m!\A/f\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'forum';
        $res->{search_query} = $url->query_param('kw');
    } elsif ($host eq 'wenku.baidu.com' && $fpath =~ m!\A/search\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'books';
        $res->{search_query} = $url->query_param('word');
    } elsif ($host eq 'zhidao.baidu.com' && $fpath =~ m!\A/q\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'wiki';
        $res->{search_query} = $url->query_param('word');
    } elsif ($fpath =~ m!\A/sf/vsearch\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} = 'video';
        $res->{search_query} = $url->query_param('word');
    } elsif ($fpath =~ m!\A/s\?!) {
        $res->{is_search} = 1;
        $res->{search_source} = 'baidu';
        $res->{search_type} =
            $url->query_param('tn') eq 'news' ? 'news' :
            'web';
        $res->{search_query} =
            $url->query_param('wd') //
            $url->query_param('word');
    }
    [200]; # 200=OK, 201=OK & skip the rest of the plugins, 500=error
}

1;
# ABSTRACT:

__END__

=pod

=encoding UTF-8

=head1 NAME

URI::Info::Plugin::SearchQuery::baidu

=head1 VERSION

This document describes version 0.004 of URI::Info::Plugin::SearchQuery::baidu (from Perl distribution URI-Info), released on 2023-06-21.

=for Pod::Coverage .+

=head1 HOMEPAGE

Please visit the project's homepage at L<https://metacpan.org/release/URI-Info>.

=head1 SOURCE

Source repository is at L<https://github.com/perlancar/perl-URI-Info>.

=head1 AUTHOR

perlancar <perlancar@cpan.org>

=head1 CONTRIBUTING


To contribute, you can send patches by email/via RT, or send pull requests on
GitHub.

Most of the time, you don't need to build the distribution yourself. You can
simply modify the code, then test via:

 % prove -l

If you want to build the distribution (e.g. to try to install it locally on your
system), you can install L<Dist::Zilla>,
L<Dist::Zilla::PluginBundle::Author::PERLANCAR>,
L<Pod::Weaver::PluginBundle::Author::PERLANCAR>, and sometimes one or two other
Dist::Zilla- and/or Pod::Weaver plugins. Any additional steps required beyond
that are considered a bug and can be reported to me.

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2023, 2021 by perlancar <perlancar@cpan.org>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=head1 BUGS

Please report any bugs or feature requests on the bugtracker website L<https://rt.cpan.org/Public/Dist/Display.html?Name=URI-Info>

When submitting a bug or request, please include a test-file or a
patch to an existing test-file that illustrates the bug or desired
feature.

=cut
